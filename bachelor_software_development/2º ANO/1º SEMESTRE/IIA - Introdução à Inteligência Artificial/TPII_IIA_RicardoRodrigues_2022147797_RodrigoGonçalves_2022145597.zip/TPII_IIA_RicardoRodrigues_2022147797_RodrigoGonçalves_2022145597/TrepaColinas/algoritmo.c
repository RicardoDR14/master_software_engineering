
#include <stdio.h>
#include <stdlib.h>
#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"

// Gera um vizinho
// Parametros: solucao actual, vizinho 1, vizinho 2, numero de vertices
//swap two vertices
void gera_vizinho(int a[], int b[], int n)
{
    int i, p1, p2, p3, p4;

    // Copia a solu��o atual para a solu��o vizinha
    for(i = 0; i < n; i++)
        b[i] = a[i];
    // Encontra aleatoriamente a posi��o de um v�rtice com valor 0
    do
        p1 = random_l_h(0, n-1);
    while(b[p1] != 0);
    // Encontra aleatoriamente a posi��o de um v�rtice com valor 1
    do
        p2 = random_l_h(0, n-1);
    while(b[p2] != 1);
    // Troca os valores dos v�rtices das posi��es encontradas
    b[p1] = 1;
    b[p2] = 0;
    /*//-----------geravizinhos2----------------//
    // Encontra aleatoriamente a posi��o de um v�rtice, que n�o seja igual a p2, com valor 0
    do
        p3 = random_l_h(0, n-1);
    while(b[p3] != 0 || p3 == p2);
    // Encontra aleatoriamente a posi��o de um v�rtice, que n�o seja igual a p1, com valor 1
    do
        p4 = random_l_h(0, n-1);
    while(b[p4] != 1 || p4 == p1);
    // Troca os valores dos v�rtices das posi��es encontradas
    b[p3] = 1;
    b[p4] = 0;*/
}

// Trepa colinas first-choice
// Parametros: solucao, matriz de adjacencias, numero de vertices e numero de iteracoes
// Devolve o custo da melhor solucao encontrada

int trepa_colinas(int sol[], int *mat, int vert, int num_iter)
{
    int *nova_sol, custo, custo_viz, i;

    // Aloca espa�o em mem�ria para guardar a nova solu��o
    nova_sol = malloc(sizeof(int)*vert);
    // Caso n�o consiga fazer a aloca��o, envia aviso e termina o programa
    if (nova_sol == NULL)
    {
        printf("Erro na alocacao de memoria");
        exit(1);
    }
    // Avalia solu��o inicial

    custo = calcula_fit(sol, mat, vert);
    for(i = 0; i < num_iter; i++)
    {
        // Gera solu��o vizinha
        gera_vizinho(sol, nova_sol, vert);
        custo_viz = calcula_fit(nova_sol, mat, vert);
        // Fica com a solu��o vizinha se o custo diminuir (problema de minimiza��o) em rela��o � solu��o atual (<=)
        if (custo_viz <= custo)
        {
            substitui(sol, nova_sol, vert);
            custo = custo_viz;
        }
    }
    // Liberta a mem�ria usada para guardar a nova solu��o
    free(nova_sol);
    // Devolve o custo da melhor solu��o encontrada
    return custo;
}

int trepa_colinas_prob(int sol[], int *mat, int vert, int num_iter, float input_prob)
{
    int *nova_sol, custo, custo_viz, i;
    float prob;

    nova_sol = malloc(sizeof(int)*vert);
    if(nova_sol == NULL)
    {
        printf("Erro na alocacao de memoria");
        exit(1);
    }
    // Avalia solucao inicial
    custo = calcula_fit(sol, mat, vert);
    for(i=0; i<num_iter; i++)
    {
        // Gera vizinho
        gera_vizinho(sol, nova_sol, vert);
        // Avalia vizinho
        custo_viz = calcula_fit(nova_sol, mat, vert);

        prob = rand_01();//trepacolinasprobabilistico
        // Aceita vizinho se o custo diminuir (problema de minimizacao)
        if(custo_viz <= custo || prob < input_prob)
        {
            substitui(sol, nova_sol, vert);
            custo = custo_viz;
        }
    }
    free(nova_sol);
    return custo;
}



