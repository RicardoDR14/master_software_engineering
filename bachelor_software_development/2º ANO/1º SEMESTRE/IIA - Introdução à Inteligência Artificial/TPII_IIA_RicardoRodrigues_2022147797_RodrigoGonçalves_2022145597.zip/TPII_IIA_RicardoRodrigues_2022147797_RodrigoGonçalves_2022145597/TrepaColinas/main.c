#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "algoritmo.h"
#include "utils.h"

#define DEFAULT_RUNS 30

void imprime_solucao_binario(int sol[], int vert, int *grafo) {
    int i, num_arestas = 0;
    for (i = 0; i < vert; i++) {
        printf("%d ", sol[i]);
        if (sol[i] == 1) {
            for (int j = 0; j < vert; j++) {
                if (grafo[i * vert + j] == 1 && sol[j] == 1) {
                    num_arestas++;
                }
            }
        }
    }
    printf("\nNumero de Arestas: %d\n", num_arestas);
}
int main(int argc, char *argv[])
{
    char nome_fich[100];
    int vert, num_iter = 500000,input_prob=0.0005, k, kk, runs, custo, best_custo;
    int *grafo, *sol, *best;
    float mbf = 0.0;

    // L� os argumentos de entrada
    if (argc == 3)
    {
        runs = atoi(argv[2]);
        strcpy(nome_fich, argv[1]);
    }
    else
    {
        // Se o n�mero de execu��es do processo n�o for colocado nos argumentos de entrada, define-o com um valor por defeito
        if (argc == 2)
        {
            runs = DEFAULT_RUNS;
            strcpy(nome_fich, argv[1]);
        }
            // Se o nome do ficheiro de informa��es n�o for colocado nos argumentos de entrada, pede-o novamente
        else
        {
            runs = DEFAULT_RUNS;
            printf("Nome do Ficheiro: ");
            gets(nome_fich);
        }
    }
    // Se o n�mero de execu��es do processo for menor ou igual a 0, termina o programa
    if (runs <= 0)
        return 0;
    // Inicializa a gera��o dos n�meros aleat�rios
    init_rand();
    // Preenche matriz de adjac�ncias, o n�mero de v�rtices a usar e o n�mero de itera��es a fazer com o trepa colinas
    grafo = init_dados(nome_fich, &vert, &kk);
    // Aloca espa�o em mem�ria para guardar uma solu��o
    sol = malloc(sizeof(int) * vert);
    // Aloca espa�o em mem�ria para guardar a melhor solu��o
    best = malloc(sizeof(int) * vert);
    // Caso n�o consiga fazer as aloca��es, envia aviso e termina o programa
    if (sol == NULL || best == NULL)
    {
        printf("Erro na alocacao de memoria");
        exit(1);
    }

    // L� o valor de k do arquivo
    printf("k: %d\n", kk);

    // Mostra informa��es sobre o grafo
    printf("Numero de Vertices: %d\n", vert);

    // Executa o algoritmo para encontrar a melhor solu��o
    for (k = 0; k < runs; k++)
    {
        // Gera a solucao inicial
        gera_sol_inicial(sol, vert, kk);

        // Mostra a solucao inicial
        printf("\nRepeticao %d:\n", k);
        printf("Valor de k: %d\n", kk);
        printf("Numero de Vertices: %d\n", vert);
        for (int i = 0; i < vert; i++)
        {
            printf("%d ", sol[i]);
        }
        printf("\n");

        // Executa o algoritmo do trepa colinas
        //custo = trepa_colinas(sol, grafo, vert, num_iter);
        custo = trepa_colinas_prob(sol, grafo, vert, num_iter,input_prob);

        // Mostra a solu��o encontrada na repeti��o k e o seu custo
        printf("Custo final: %2d\n", custo);

        // Acumula o custo das solu��es encontradas
        mbf += custo;

        // Guarda a melhor solu��o encontrada
        if (k == 0 || best_custo > custo)
        {
            best_custo = custo;
            substitui(best, sol, vert);
        }
    }

    // Calcula e mostra a m�dia dos custos de todas as melhores solu��es encontradas
    printf("\n\nMBF: %.6f\n", (float)mbf / runs);

    // Mostra a melhor solu��o encontrada e o seu respectivo custo
    printf("\nMelhor solucao encontrada\n");
    printf("Valor de k: %d\n", kk);
    printf("Numero de Vertices: %d\n", vert);
    printf("Custo final: %2d\n", best_custo);

    // Mostra a melhor solu��o encontrada em bin�rio
    printf("\nMelhor solucao encontrada em binario:");
    imprime_solucao_binario(best, vert, grafo);

    // Liberta a mem�ria usada
    free(grafo);
    free(sol);
    free(best);

    return 0;
}
