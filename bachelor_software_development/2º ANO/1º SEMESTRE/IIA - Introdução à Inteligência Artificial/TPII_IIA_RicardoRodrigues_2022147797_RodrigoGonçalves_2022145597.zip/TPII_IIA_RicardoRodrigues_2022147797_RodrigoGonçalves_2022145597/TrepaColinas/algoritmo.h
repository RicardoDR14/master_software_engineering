int trepa_colinas(int sol[], int *mat, int vert, int num_iter);
void gera_vizinho(int a[], int b[], int n);
int trepa_colinas_prob(int sol[], int *mat, int vert, int num_iter, float input_prob);