#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "utils.h"
#include <string.h>

// Leitura do ficheiro de input
// Recebe: nome do ficheiro, numero de vertices (ptr), numero de iteracoes (ptr)
// Devolve a matriz de adjacencias
int* init_dados(char *nome, int *n, int *kk)
{

    FILE    *f;
    int     *p;
    int     a=0,i,k,j,v;


    f=fopen(nome, "r");

    if (!f)
    {
        printf("Erro no acesso ao ficheiro dos dados\n");
        exit(1);
    }

    fscanf(f, "k %d ", kk);
    fscanf(f, "p edge %d %d\n", n, &a);

    p = malloc(sizeof(int)*(*n)*(*n));

    if (!p)
    {
        printf("Erro na alocacao de memoria\n");
        exit(1);
    }

    for (i=0; i<*n; i++)
        for (j=0; j<*n; j++)
            *(p+(*n)*i+j)=0;

    for (i=0; i<a; i++)
    {
        fscanf(f, "e %d %d %d\n", &j, &k, &v);
        *(p+(*n)*(j-1)+k-1)=v;
        *(p+(*n)*(k-1)+j-1)=v;
    }

    fclose(f);

    return p;

}

// Gera a solucao inicial
// Parametros: numero de vertices
void gera_sol_inicial(int *sol, int v, int kk){
    int i, x;

    for (i = 0; i < v; i++)
        sol[i] = 0;
    for (i = 0; i < kk; i++)
    {
        do
            x = random_l_h(0, v-1);
        while (sol[x] != 0);
        sol[x] = 1;
    }
}


// Escreve solucao
// Parametros: solucao e numero de vertices
void escreve_sol(int *sol, int vert, int kk){
    int i;

    printf("Valor de k: %d\n", kk);
    printf("Numero de Vertices: %d\n", vert);
    printf("Numero de Arestas: "); // Voc� pode contar o n�mero de arestas na solu��o se necess�rio

    for (i = 0; i < vert; i++)
    {
        printf("%d ", sol[i]);
    }

    printf("\n");
}

// copia vector b para a (tamanho n)
void substitui(int a[], int b[], int n)
{
    int i;
    for(i=0; i<n; i++)
        a[i]=b[i];
}

// Inicializa o gerador de numeros aleatorios
void init_rand()
{
    srand((unsigned)time(NULL));
}

// Devolve valor inteiro aleatorio entre min e max
int random_l_h(int min, int max)
{
    return min + rand() % (max - min + 1);
}

// Gera um valor inteiro aleat�rio entre 0 e 1
// Par�metros de sa�da: Valor aleat�rio entre 0 e 1
float rand_01()
{
    return ((float)rand()) / RAND_MAX;
}
