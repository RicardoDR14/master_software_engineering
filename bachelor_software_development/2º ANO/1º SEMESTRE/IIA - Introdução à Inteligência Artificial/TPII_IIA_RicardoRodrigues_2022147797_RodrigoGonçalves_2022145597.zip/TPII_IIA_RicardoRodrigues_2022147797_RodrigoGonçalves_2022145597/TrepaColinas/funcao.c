int calcula_fit(int a[], int *mat, int vert){
    int total = 0;
    int i,x, j;

    for (i = 0; i < vert; i++){

        x=0;
        if (a[i] == 1)
        {

            for (j = 0; j < vert; j++)
                if (a[j] == 1 && *(mat+i*vert+j) != 0){
                    total=total+*(mat+i*vert+j);
                    x++;
                }
            if(x==0){
                return 9999;
            }

        }
    }
    return total/2;//
}