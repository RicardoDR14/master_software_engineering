int* init_dados(char *nome, int *n, int *iter);
void gera_sol_inicial(int *sol, int v, int kk);
void escreve_sol(int *sol, int vert, int kk);
void substitui(int a[], int b[], int n);
void init_rand(void);
int random_l_h(int min, int max);
float rand_01(void);
