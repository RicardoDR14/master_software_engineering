void genetic_operators(pchrom parents, struct info d, pchrom offspring);
void mutation(pchrom offspring, struct info d);
void crossover(pchrom parents, struct info d, pchrom offspring);
void tournament(pchrom pop, struct info d, pchrom parents);
void crossover2(pchrom parents, struct info d, pchrom offspring);

