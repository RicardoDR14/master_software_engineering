#include "algoritmo.h"
#include "funcao.h"
#include "utils.h"
#include "stdlib.h"
#include "stdio.h"

int valida(int a[], int *mat, int vert)
{
    int x = 0, conta = 0, i, j;

    for (i=0; i<vert; i++)
    {
        x=0;
        if (a[i] == 1)
        {
            for (j=0; j<vert;j++)
                if (a[j] == 1)
                {
                    if (*(mat+vert*i+j) != 0)
                        x++;
                }
            if (x == 0)
                conta++;
        }
    }
    return conta;
}

int calcula_fit(int a[], int *mat, int vert)
{
	int custo=0, i, j, val;

	for (i=0; i<vert; i++)
	{
        if (a[i] == 1)
          for (j=i+1; j<vert;j++)
            if (a[j] == 1 && *(mat+vert*i+j)!=0)
                  custo = custo + *(mat+vert*i+j);
	}
    val = valida(a,mat,vert);
    if (val == 0)
        return custo;
    else
        return val * 1000;
}

int conta_uns(int * sol, int vert)
{
    int i, c=0;

    for(i=0;i < vert;i++)
       if(sol[i] == 1) c++;
    return c;
}

void repara_uns (int sol[], int vert, int k)
{
    int conta = 0, pos;

    conta = conta_uns(sol, vert);
    if(conta > k)
    {
        while(conta_uns(sol, vert) != k)
        {
            do
                pos = random_l_h(0,vert-1);
            while (sol[pos] != 1);
            sol[pos] = 0;
        }
    }
    if(conta < k)
    {
        while(conta_uns(sol, vert) != k)
        {
            do
                pos = random_l_h(0,vert-1);
            while (sol[pos] != 0);
            sol[pos] = 1;
        }
    }
}

void evaluate(pchrom pop, struct info d, int *mat)
{
    int i;
    for (i=0; i<d.popsize; i++)
    {
        repara_uns(pop[i].p,d.numGenes,d.k); //coloca numero de 1's com valor = K
        pop[i].fitness = calcula_fit(pop[i].p, mat, d.numGenes);
    }
}
