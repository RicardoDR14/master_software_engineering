int calcula_fit(int a[], int *mat, int vert);
void evaluate(pchrom pop, struct info d, int *mat);
int valida(int a[], int *mat, int vert);
