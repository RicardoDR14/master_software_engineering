#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "algoritmo.h"
#include "utils.h"

void init_rand(void)
{
    srand((unsigned)time(NULL));
}

int* init_dados(char *nome, int *n, int *kk)
{
	FILE    *f;
	int     *p;
    int     a=0, i,k, j,v;

	f=fopen(nome, "r");
	if (!f)
	{
		printf("Erro no acesso ao ficheiro dos dados\n");
		exit(1);
	}
    fscanf(f, "k %d ", kk);
    fscanf(f, "p edge %d %d\n", n, &a);
	p = malloc(sizeof(int)*(*n)*(*n));
	if (!p)
	{
	    printf("Erro na alocacao de memoria\n");
	    exit(1);
	}
	for (i=0; i<*n; i++)
        for (j=0; j<*n; j++)
            *(p+(*n)*i+j)=0;
	for (i=0; i<a; i++)
	{
        fscanf(f, "e %d %d %d\n", &j, &k, &v);
        *(p+(*n)*(j-1)+k-1)=v;
        *(p+(*n)*(k-1)+j-1)=v;
    }
	fclose(f);
	return p;
}

int random_l_h(int min, int max)
{
    return min + rand() % (max-min+1);
}

void gera_sol_inicial(int *sol, int k, int v)
{
	int i, pos1;

	for (i=0; i<v; i++)
        sol[i]=0;
    for (i=0; i<k; i++)
    {
        do
            pos1 = random_l_h(0,v-1);
        while (sol[pos1] != 0);
        sol[pos1] = 1;
    }
}

void escreve_sol(int *sol, int vert)
{
	int i;

	for (i=0; i<vert; i++)
        printf("%2d", sol[i]);
}

void substitui(int a[], int b[], int n)
{
    int i;

    for(i=0; i<n; i++)
        a[i] = b[i];
}

// Simula o lanÁamento de uma moeda, retornando o valor 0 ou 1
int flip(void)
{
    if ((((float)rand()) / RAND_MAX) < 0.5)
        return 0;
    else
        return 1;
}

// Devolve um valor real aleatorio do intervalo [0, 1]
float rand_01(void)
{
	return ((float)rand())/RAND_MAX;
}

void print_matriz(int *m, int v){
    int i, k=1;

    for (i=0; i<v*v; i++)
    {
        printf("%d ", *(m+i));
        if (i+1 == (k*v))
        {
            printf("\n");
            k++;
        }
    }
}

// Criacao da populacao inicial. O vector e alocado dinamicamente
// Par‚metro de entrada: Estrutura com par‚metros do problema
// Par‚metro de saÌda: Preenche da estrutura da populaÁ„o apenas o vector bin·rio com os elementos que est„o dentro ou fora da mochila
pchrom init_pop(struct info d)
{
    int     i;
    pchrom  indiv;

    indiv = malloc(sizeof(chrom)*d.popsize);
    if (indiv==NULL)
    {
        printf("Erro na alocacao de memoria\n");
        exit(1);
    }
    for (i=0; i<d.popsize; i++)
        gera_sol_inicial(indiv[i].p, d.k, d.numGenes);
    return indiv;
}

// Actualiza a melhor soluÁ„o encontrada
// Par‚metro de entrada: populacao actual (pop), estrutura com par‚metros (d) e a melhor solucao encontrada atÈ a geraÁ„oo imediatamente anterior (best)
// Par‚metro de saÌda: a melhor solucao encontrada atÈ a geraÁ„o actual
chrom get_best(pchrom pop, struct info d, chrom best)
{
    int i;

    for (i=0; i<d.popsize; i++)
    {
        if (best.fitness > pop[i].fitness)
            best=pop[i];
    }
    return best;
}

// Escreve uma soluÁ„o na consola
// Par‚metro de entrada: populacao actual (pop) e estrutura com par‚metros (d)
void write_best(chrom x, struct info d)
{
    int i;

    printf("\nBest individual: %d\n", x.fitness);
    for (i=0; i<d.numGenes; i++)
        printf("%d", x.p[i]);
    putchar('\n');
}
