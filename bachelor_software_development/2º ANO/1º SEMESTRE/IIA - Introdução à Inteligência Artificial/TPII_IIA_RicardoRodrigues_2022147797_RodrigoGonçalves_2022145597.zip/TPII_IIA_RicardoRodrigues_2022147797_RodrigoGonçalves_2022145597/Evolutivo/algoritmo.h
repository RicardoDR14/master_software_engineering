#define MAX 500
// EStrutura para armazenar parametros
struct info
{
    int     popsize;
    float   pm;
    float   pr;
    int     tsize;
    int     k;
    int     numGenes;
    int     numGenerations;
};

// Individuo (soluÁ„o)
typedef struct individual chrom, *pchrom;

struct individual
{
    int   p[MAX];
    int   fitness;
};

int trepa_colinas(int sol[], int *mat, int vert, int num_iter);
void tournament(pchrom pop, struct info d, pchrom parents);
void genetic_operators(pchrom parents, struct info d, pchrom offspring);
void crossover(pchrom parents, struct info d, pchrom offspring);
void mutation(pchrom offspring,struct info d);
