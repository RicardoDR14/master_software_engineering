#include "algoritmo.h"
#include "operadores.h"
#include "utils.h"

void tournament(pchrom pop, struct info d, pchrom parents)
{
    int i, x1, x2;

    for(i=0; i<d.popsize;i++)
    {
        x1 = random_l_h(0, d.popsize-1);
        do
            x2 = random_l_h(0, d.popsize-1);
        while(x1==x2);
        if(pop[x1].fitness < pop[x2].fitness)
            parents[i]=pop[x1];
        else
            parents[i]=pop[x2];
    }
}

void genetic_operators(pchrom parents, struct info d, pchrom offspring)
{
    //crossover(parents, d, offspring);
    mutation(offspring, d);
    crossover2( parents, d, offspring);
}

void crossover(pchrom parents, struct info d, pchrom offspring)
{
    int i, j, point;

    for (i=0; i<d.popsize; i+=2)
    {
        if (rand_01() < d.pr)
        {
            point = random_l_h(0, d.numGenes-1);
            for (j=0; j<point; j++)
            {
                offspring[i].p[j] = parents[i].p[j];
                offspring[i+1].p[j] = parents[i+1].p[j];
            }
            for (j=point; j<d.numGenes; j++)
            {
                offspring[i].p[j]= parents[i+1].p[j];
                offspring[i+1].p[j] = parents[i].p[j];
            }
        }
        else
        {
            offspring[i] = parents[i];
            offspring[i+1] = parents[i+1];
        }
    }
}

void crossover2(pchrom parents, struct info d, pchrom offspring){

    int i, j, p1,p2,x;

    for (i=0; i<d.popsize; i+=2){//percorre a populacao de pais de 2 em 2(s�o 2 pais)
        if (rand_01() < d.pr)//pr -> PROBABILIDADE DE RECOMBINA��O
        {
            p1 = random_l_h(0, d.numGenes-1);
            p2 = random_l_h(0, d.numGenes-1);
            while(p2 == p1){//2 pontos diferentes
                p2 = random_l_h(0, d.numGenes-1);
            }

            if(p1 > p2){
                x = p1;
                p2 = p1;
                p2 = x;
            }
            for (j=0; j<p1; j++)//igual aos pais
            {
                offspring[i].p[j] = parents[i].p[j];
                offspring[i+1].p[j] = parents[i+1].p[j];
            }
            for (j=p1; j<d.numGenes; j++)//troca
            {
                offspring[i].p[j]= parents[i+1].p[j];
                offspring[i+1].p[j] = parents[i].p[j];
            }
            for (int k = p2; k < d.numGenes; ++k) {//igual aos pais
                offspring[i].p[k] = parents[i].p[k];
                offspring[i+1].p[k] = parents[i+1].p[k];
            }
        }
        else
        {
            offspring[i] = parents[i];
            offspring[i+1] = parents[i+1];
        }
    }
}


void mutation(pchrom offspring, struct info d)
{
    int i, j;

    for (i=0; i<d.popsize; i++)
        for (j=0; j<d.numGenes; j++)
            if (rand_01() < d.pm)
                offspring[i].p[j] = !(offspring[i].p[j]);
}
