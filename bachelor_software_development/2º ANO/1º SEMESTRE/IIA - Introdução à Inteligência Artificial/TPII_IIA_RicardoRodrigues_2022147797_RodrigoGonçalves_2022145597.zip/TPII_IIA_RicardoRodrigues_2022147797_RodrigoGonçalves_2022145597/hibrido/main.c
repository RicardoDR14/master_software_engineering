#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "algoritmo.h"
#include "operadores.h"
#include "utils.h"
#include "funcao.h"

#define DEFAULT_RUNS   10
#define DEFAULT_ITERS   20000

int main(void)
{
    char    nome_fich[100];
    int     vert, k, kk, runs, custo, best_custo = 0, alg, gen_actual;
    int     *grafo, *sol, *best;
	float   mbf = 0.0;
    struct  info EA_param;
    pchrom  pop = NULL, parents = NULL;
    chrom   best_run, best_ever;

    runs = DEFAULT_RUNS;
    printf("Nome do Ficheiro: ");
    gets(nome_fich);
	if(runs <= 0)
		return 0;
	init_rand();
    grafo = init_dados(nome_fich, &vert, &kk);
    EA_param.numGenerations = 2500;
    EA_param.numGenes = vert;
    EA_param.pm = 0.001;
    EA_param.pr = 0.7;
    EA_param.popsize = 100;
    EA_param.tsize = 2;
    EA_param.k = kk;
    for(k=0; k<runs; k++)
    {
        printf("\nRepeticao %d",k+1);
        pop = init_pop(EA_param);
        evaluate(pop, EA_param, grafo);
        gen_actual = 1;
        best_run = pop[0];
        best_run = get_best(pop, EA_param, best_run);
        parents = malloc(sizeof(chrom)*EA_param.popsize);
        if (parents==NULL)
        {
            printf("Erro na alocacao de memoria\n");
            exit(1);
        }
        while (gen_actual <= EA_param.numGenerations)
        {
            tournament(pop, EA_param, parents);
            genetic_operators(parents, EA_param, pop);
            evaluate(pop, EA_param, grafo);
            best_run = get_best(pop, EA_param, best_run);
            gen_actual++;
        }
        for (int j = 0; j < EA_param.popsize; ++j) {
            pop[j].fitness = trepa_colinas(pop[j].p, grafo, vert, 100);
        }
        best_run = get_best(pop, EA_param, best_run);
        write_best(best_run, EA_param);
        mbf += best_run.fitness;
        if (k==0 || best_run.fitness < best_ever.fitness)
            best_ever = best_run;
        free(parents);
        free(pop);
    }
    printf("\n\nMBF: %f\n", mbf/k);
    printf("\nMelhor solucao encontrada");
    write_best(best_ever, EA_param);
    return 0;
}
