globals [ veneno comida mensagem]

breed[leoes leao]
breed[hienas hiena]

turtles-own [energia agrupamento]
patches-own [tempo_crescer]
leoes-own [descanso adescansar]

to setup
  clear-all
  reset-ticks
  ;;iniciar o ambiente
   setup_brown
   setup_red
   setup_blue

  ;;iniciar agentes (leoes e hienas)
  setup_leoes
  setup_hienas

end

;;funçoes para o ambiente
to setup_brown
  ask patches
  [
    if random 101 < perc_comida_p
    [
      set pcolor brown
      set comida comida_energia / 2
      set tempo_crescer 0
    ]
  ]
end
to setup_red
  ask patches
  [
    if pcolor != brown
    [
      if random 101 < perc_comida_g
      [
        set pcolor red
        set comida comida_energia
      ]
    ]
    set tempo_crescer 0
  ]
end
to setup_blue
    let n_azuis 0
    while [n_azuis < celulas_azuis][
      let random_patch one-of patches
      ask random_patch[
        if pcolor != brown and pcolor != red
        [
          set pcolor blue
          set n_azuis n_azuis + 1
        set tempo_crescer 0
        ]
      ]
    ]

end

;;funcoes para os agentes
to setup_leoes
  create-leoes n_leoes
  [
    set shape "face happy"
    setxy random-xcor random-ycor
    set color yellow
    set heading 0
    set energia energia_animais
    set descanso 0
    set adescansar 0
  ]
end
to setup_hienas
  create-hienas n_hienas
  [
    set shape "bug"
    setxy random-xcor random-ycor
    set color green
    set heading 0
    set energia energia_animais
    set agrupamento 1
  ]
end

to go
  if count turtles = 0
  [
    stop
  ]
  ask leoes
  [
    move_leoes
    set energia energia - 1
    (ifelse energia <= energia_lim_leoes
      [comer]
      [matar_hienas])
    if reproducao_animais [reproduzir_leoes]
    restart_comida
    morrer
  ]
  ask hienas
  [
    move_hienas
    set energia energia - 1
    comer
    if agrupamento > 1 [matar_leoes]
    if reproducao_animais [reproduzir_hienas]
    restart_comida
    morrer
  ]
  tick

end

to move_leoes
  ask leoes
  [
    let patch_frente patch-ahead 1
    let patch_direita patch-right-and-ahead 90 1
    let patch_esquerda patch-left-and-ahead 90 1
    let n_frente count hienas in-radius 1 with [patch-here = patch_frente]
    let n_esquerda count hienas in-radius 1 with [patch-here = patch_esquerda]
    let n_direita count hienas in-radius 1 with [patch-here = patch_direita]
    let n_redor count hienas-on neighbors
    let r random 101
    let cor_atual [pcolor] of patch-here


    if percecao_leoes = "Apenasfrente"
    [
      (ifelse descanso <= 0 and adescansar = 0[

      (ifelse
        r < 33 [fd 1]
        r < 67 [rt 90]
        [lt 90])

      (ifelse
        n_frente = 0
      [
        fd 1
      ]
        n_frente = 1
      [
        set energia energia - 2
        ifelse random 101 < 50[lt 90][rt 90]
        fd 1
      ]
        n_frente >= 2
      [
        matar_hienas
        set energia energia - 3
        fd -1
        ifelse random 101 < 50[lt 90][rt 90]
        fd 1
      ]
        (cor_atual = blue)
      [
        if descanso <= 0 and adescansar = 0
          [
            set descanso tempo_descanso
            set adescansar 1
          ]
    ])]
      [set descanso descanso - 1])

    if descanso <= 0 and adescansar = 1
    [
      set adescansar 0
      fd 1
    ]
    ]


    if percecao_leoes = "Esquerdafrentedireita"
    [
    (ifelse descanso <= 0 and adescansar = 0[

      (ifelse
        r < 33 [fd 1]
        r < 67 [rt 90]
        [lt 90])

      (ifelse
        n_esquerda >= 2
      [
        set energia energia - 2
        lt 90
      ]
        n_direita >= 2
      [
        set energia energia - 2
        rt 90
      ]
        (n_frente >= 2 or n_esquerda >= 1) and (n_direita >= 1 and n_frente = 0)
      [
        set energia energia - 3
        fd -1
      ]
        (n_esquerda >= 1 and n_frente >= 2 and n_direita = 0)
      [
        set energia energia - 5
        fd -1
        rt 90
        fd 1
      ]
        (n_direita >= 1 and n_frente >= 2 and n_esquerda = 0)
      [
        set energia energia - 5
        fd -1
        lt 90
        fd 1
      ]
        (n_direita >= 1 and n_esquerda >= 1 and n_frente >= 1)
      [
        set energia energia - 4
        fd -2
      ]
        (cor_atual = blue)
      [
        if descanso <= 0 and adescansar = 0
          [
            set descanso tempo_descanso
            set adescansar 1
          ]
    ])]
      [set descanso descanso - 1])

    if descanso <= 0 and adescansar = 1
    [
      set adescansar 0
      fd 1
    ]
    ]


    if percecao_leoes = "Redorcompleto"
    [
    (ifelse descanso <= 0 and adescansar = 0[

      (ifelse
        r < 33 [fd 1]
        r < 67 [rt 90]
        [lt 90])

      (ifelse
        n_redor = 0
      [
        fd 1
      ]
        n_redor = 1
      [
        set energia energia - 2
        ifelse random 101 < 50 [lt 90][rt 90]
        fd 1
      ]
        n_redor >= 2
      [
        matar_hienas
        set energia energia - 3
        fd -1
        ifelse random 101 < 50 [lt 90][rt 90]
        fd 1
      ]
        (cor_atual = blue)
      [
        if descanso <= 0 and adescansar = 0
          [
            set descanso tempo_descanso
            set adescansar 1
          ]
    ])]
      [set descanso descanso - 1])

    if descanso <= 0 and adescansar = 1
    [
      set adescansar 0
      fd 1
    ]
    ]
  ]
end


to move_hienas
  ask hienas
  [
    let patch_frente patch-ahead 1
    let patch_direita patch-right-and-ahead 90 1
    let patch_esquerda patch-left-and-ahead 90 1
    let n_frente count hienas in-radius 1 with [patch-here = patch_frente]
    let n_esquerda count hienas in-radius 1 with [patch-here = patch_esquerda]
    let n_direita count hienas in-radius 1 with [patch-here = patch_direita]
    let hienas_vizinhas hienas in-radius 1
    let cor_atual [pcolor] of patch-here

    let r random 101
    (ifelse
     r < 33 [fd 1]
     r < 67 [rt 90]
            [lt 90])

    (ifelse count hienas_vizinhas > 1
    [
      set color pink
      let grupo hienas_vizinhas
      let grupo-direcao random 360
      ask grupo
      [
        set agrupamento count grupo
        set heading grupo-direcao
        fd 1
      ]
    ])
  ]
end

to restart_comida
  if pcolor = black
  [
    ifelse tempo_crescer <= 0
    [
      (ifelse random 101 < perc_comida_p
      [
          set pcolor brown
          set comida comida_energia / 2
      ]
       random 101 < perc_comida_g
      [
          set pcolor red
          set comida comida_energia
      ])

      set tempo_crescer tempo_crescimento_comida
    ]
    [set tempo_crescer tempo_crescer - 1 ]
  ]
end

to comer
    (ifelse pcolor = red
    [
      set energia energia + comida
      if energia > 100 [set energia 100]
      set pcolor brown
      set comida comida_energia / 2
    ]
      pcolor = brown
    [
      set energia energia + comida
      if energia > 100 [set energia 100]
      set pcolor black
      set comida 0
    ])
end

to matar_hienas
  let presa one-of hienas-here
  if presa != nobody
  [
    ask presa [die]
    set energia energia + (comida_energia / 2)
    if energia > 100[set energia 100]
    set energia energia - dano_batalha
  ]
end

to matar_leoes
  let presa one-of leoes-here
  if presa != nobody
  [
    ask presa [die]
    set energia energia + comida_energia
    if energia > 100 [set energia 100]
    set energia energia - (dano_batalha / agrupamento)
  ]
end

to reproduzir_leoes
 if random-float 100 < taxa_reproducao_leoes
  [
    set energia (energia / 2)
    hatch 1 [ rt random-float 360 fd 1 ]
  ]
end

to reproduzir_hienas
  if random-float 100 < taxa_reproducao_hienas
  [
    set energia (energia / 2)
    hatch 1 [ rt random-float 360 fd 1 ]
  ]
end

to morrer
  if energia <= 0
  [
    die
  ]
end
@#$#@#$#@
GRAPHICS-WINDOW
44
10
593
560
-1
-1
17.452
1
10
1
1
1
0
1
1
1
-15
15
-15
15
0
0
1
ticks
30.0

BUTTON
918
479
1041
512
NIL
Setup
NIL
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

SLIDER
612
248
731
281
n_leoes
n_leoes
1
100
50.0
1
1
NIL
HORIZONTAL

BUTTON
1072
479
1196
512
NIL
Go
T
1
T
OBSERVER
NIL
NIL
NIL
NIL
1

SLIDER
604
50
733
83
perc_comida_p
perc_comida_p
0
20
20.0
1
1
NIL
HORIZONTAL

SLIDER
744
51
873
84
perc_comida_g
perc_comida_g
0
10
10.0
1
1
NIL
HORIZONTAL

SLIDER
604
95
734
128
celulas_azuis
celulas_azuis
0
5
5.0
1
1
NIL
HORIZONTAL

SLIDER
612
295
731
328
n_hienas
n_hienas
1
100
50.0
1
1
NIL
HORIZONTAL

SLIDER
612
344
731
377
energia_animais
energia_animais
0
100
75.0
1
1
NIL
HORIZONTAL

SLIDER
756
248
880
281
energia_lim_leoes
energia_lim_leoes
0
100
46.0
1
1
NIL
HORIZONTAL

SLIDER
743
95
873
128
comida_energia
comida_energia
1
100
50.0
1
1
NIL
HORIZONTAL

SLIDER
604
139
874
172
tempo_crescimento_comida
tempo_crescimento_comida
0
5
0.6
0.1
1
NIL
HORIZONTAL

SLIDER
755
345
880
378
dano_batalha
dano_batalha
0
50
20.0
0.1
1
NIL
HORIZONTAL

SLIDER
755
295
880
328
tempo_descanso
tempo_descanso
0
200
99.0
1
1
NIL
HORIZONTAL

TEXTBOX
606
24
756
42
Funcionalidades do Ambiente
10
0.0
1

TEXTBOX
606
213
756
231
Funcionalidades dos Animais
10
0.0
1

PLOT
952
67
1152
217
Nº Leões
NIL
NIL
0.0
100.0
0.0
100.0
true
false
"" ""
PENS
"default" 1.0 0 -6459832 true "" "plot count leoes"

PLOT
952
262
1152
412
Nº hienas
NIL
NIL
0.0
100.0
0.0
100.0
true
false
"" ""
PENS
"default" 1.0 0 -16375013 true "" "plot count hienas"

TEXTBOX
609
406
759
424
Funções adicionais
10
0.0
1

CHOOSER
758
491
897
536
percecao_leoes
percecao_leoes
"Apenasfrente" "Esquerdafrentedireita" "Redorcompleto"
1

SWITCH
757
447
898
480
Reproducao_animais
Reproducao_animais
1
1
-1000

SLIDER
615
502
754
535
taxa_reproducao_leoes
taxa_reproducao_leoes
1
50
50.0
1
1
NIL
HORIZONTAL

SLIDER
615
447
756
480
taxa_reproducao_hienas
taxa_reproducao_hienas
0
50
50.0
1
1
NIL
HORIZONTAL

@#$#@#$#@
## WHAT IS IT?

This section could give a general understanding of what the model is trying to show or explain.

## HOW IT WORKS

This section could explain what rules the agents use to create the overall behavior of the model.

## HOW TO USE IT

This section could explain how to use the model, including a description of each of the items in the interface tab.

## THINGS TO NOTICE

This section could give some ideas of things for the user to notice while running the model.

## THINGS TO TRY

This section could give some ideas of things for the user to try to do (move sliders, switches, etc.) with the model.

## EXTENDING THE MODEL

This section could give some ideas of things to add or change in the procedures tab to make the model more complicated, detailed, accurate, etc.

## NETLOGO FEATURES

This section could point out any especially interesting or unusual features of NetLogo that the model makes use of, particularly in the Procedures tab.  It might also point out places where workarounds were needed because of missing features.

## RELATED MODELS

This section could give the names of models in the NetLogo Models Library or elsewhere which are of related interest.

## CREDITS AND REFERENCES

This section could contain a reference to the model's URL on the web if it has one, as well as any other necessary credits or references.
@#$#@#$#@
default
true
0
Polygon -7500403 true true 150 5 40 250 150 205 260 250

airplane
true
0
Polygon -7500403 true true 150 0 135 15 120 60 120 105 15 165 15 195 120 180 135 240 105 270 120 285 150 270 180 285 210 270 165 240 180 180 285 195 285 165 180 105 180 60 165 15

arrow
true
0
Polygon -7500403 true true 150 0 0 150 105 150 105 293 195 293 195 150 300 150

box
false
0
Polygon -7500403 true true 150 285 285 225 285 75 150 135
Polygon -7500403 true true 150 135 15 75 150 15 285 75
Polygon -7500403 true true 15 75 15 225 150 285 150 135
Line -16777216 false 150 285 150 135
Line -16777216 false 150 135 15 75
Line -16777216 false 150 135 285 75

bug
true
0
Circle -7500403 true true 96 182 108
Circle -7500403 true true 110 127 80
Circle -7500403 true true 110 75 80
Line -7500403 true 150 100 80 30
Line -7500403 true 150 100 220 30

butterfly
true
0
Polygon -7500403 true true 150 165 209 199 225 225 225 255 195 270 165 255 150 240
Polygon -7500403 true true 150 165 89 198 75 225 75 255 105 270 135 255 150 240
Polygon -7500403 true true 139 148 100 105 55 90 25 90 10 105 10 135 25 180 40 195 85 194 139 163
Polygon -7500403 true true 162 150 200 105 245 90 275 90 290 105 290 135 275 180 260 195 215 195 162 165
Polygon -16777216 true false 150 255 135 225 120 150 135 120 150 105 165 120 180 150 165 225
Circle -16777216 true false 135 90 30
Line -16777216 false 150 105 195 60
Line -16777216 false 150 105 105 60

car
false
0
Polygon -7500403 true true 300 180 279 164 261 144 240 135 226 132 213 106 203 84 185 63 159 50 135 50 75 60 0 150 0 165 0 225 300 225 300 180
Circle -16777216 true false 180 180 90
Circle -16777216 true false 30 180 90
Polygon -16777216 true false 162 80 132 78 134 135 209 135 194 105 189 96 180 89
Circle -7500403 true true 47 195 58
Circle -7500403 true true 195 195 58

circle
false
0
Circle -7500403 true true 0 0 300

circle 2
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240

cow
false
0
Polygon -7500403 true true 200 193 197 249 179 249 177 196 166 187 140 189 93 191 78 179 72 211 49 209 48 181 37 149 25 120 25 89 45 72 103 84 179 75 198 76 252 64 272 81 293 103 285 121 255 121 242 118 224 167
Polygon -7500403 true true 73 210 86 251 62 249 48 208
Polygon -7500403 true true 25 114 16 195 9 204 23 213 25 200 39 123

cylinder
false
0
Circle -7500403 true true 0 0 300

dot
false
0
Circle -7500403 true true 90 90 120

face happy
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 255 90 239 62 213 47 191 67 179 90 203 109 218 150 225 192 218 210 203 227 181 251 194 236 217 212 240

face neutral
false
0
Circle -7500403 true true 8 7 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Rectangle -16777216 true false 60 195 240 225

face sad
false
0
Circle -7500403 true true 8 8 285
Circle -16777216 true false 60 75 60
Circle -16777216 true false 180 75 60
Polygon -16777216 true false 150 168 90 184 62 210 47 232 67 244 90 220 109 205 150 198 192 205 210 220 227 242 251 229 236 206 212 183

fish
false
0
Polygon -1 true false 44 131 21 87 15 86 0 120 15 150 0 180 13 214 20 212 45 166
Polygon -1 true false 135 195 119 235 95 218 76 210 46 204 60 165
Polygon -1 true false 75 45 83 77 71 103 86 114 166 78 135 60
Polygon -7500403 true true 30 136 151 77 226 81 280 119 292 146 292 160 287 170 270 195 195 210 151 212 30 166
Circle -16777216 true false 215 106 30

flag
false
0
Rectangle -7500403 true true 60 15 75 300
Polygon -7500403 true true 90 150 270 90 90 30
Line -7500403 true 75 135 90 135
Line -7500403 true 75 45 90 45

flower
false
0
Polygon -10899396 true false 135 120 165 165 180 210 180 240 150 300 165 300 195 240 195 195 165 135
Circle -7500403 true true 85 132 38
Circle -7500403 true true 130 147 38
Circle -7500403 true true 192 85 38
Circle -7500403 true true 85 40 38
Circle -7500403 true true 177 40 38
Circle -7500403 true true 177 132 38
Circle -7500403 true true 70 85 38
Circle -7500403 true true 130 25 38
Circle -7500403 true true 96 51 108
Circle -16777216 true false 113 68 74
Polygon -10899396 true false 189 233 219 188 249 173 279 188 234 218
Polygon -10899396 true false 180 255 150 210 105 210 75 240 135 240

house
false
0
Rectangle -7500403 true true 45 120 255 285
Rectangle -16777216 true false 120 210 180 285
Polygon -7500403 true true 15 120 150 15 285 120
Line -16777216 false 30 120 270 120

leaf
false
0
Polygon -7500403 true true 150 210 135 195 120 210 60 210 30 195 60 180 60 165 15 135 30 120 15 105 40 104 45 90 60 90 90 105 105 120 120 120 105 60 120 60 135 30 150 15 165 30 180 60 195 60 180 120 195 120 210 105 240 90 255 90 263 104 285 105 270 120 285 135 240 165 240 180 270 195 240 210 180 210 165 195
Polygon -7500403 true true 135 195 135 240 120 255 105 255 105 285 135 285 165 240 165 195

line
true
0
Line -7500403 true 150 0 150 300

line half
true
0
Line -7500403 true 150 0 150 150

pentagon
false
0
Polygon -7500403 true true 150 15 15 120 60 285 240 285 285 120

person
false
0
Circle -7500403 true true 110 5 80
Polygon -7500403 true true 105 90 120 195 90 285 105 300 135 300 150 225 165 300 195 300 210 285 180 195 195 90
Rectangle -7500403 true true 127 79 172 94
Polygon -7500403 true true 195 90 240 150 225 180 165 105
Polygon -7500403 true true 105 90 60 150 75 180 135 105

plant
false
0
Rectangle -7500403 true true 135 90 165 300
Polygon -7500403 true true 135 255 90 210 45 195 75 255 135 285
Polygon -7500403 true true 165 255 210 210 255 195 225 255 165 285
Polygon -7500403 true true 135 180 90 135 45 120 75 180 135 210
Polygon -7500403 true true 165 180 165 210 225 180 255 120 210 135
Polygon -7500403 true true 135 105 90 60 45 45 75 105 135 135
Polygon -7500403 true true 165 105 165 135 225 105 255 45 210 60
Polygon -7500403 true true 135 90 120 45 150 15 180 45 165 90

sheep
false
0
Rectangle -7500403 true true 151 225 180 285
Rectangle -7500403 true true 47 225 75 285
Rectangle -7500403 true true 15 75 210 225
Circle -7500403 true true 135 75 150
Circle -16777216 true false 165 76 116

square
false
0
Rectangle -7500403 true true 30 30 270 270

square 2
false
0
Rectangle -7500403 true true 30 30 270 270
Rectangle -16777216 true false 60 60 240 240

star
false
0
Polygon -7500403 true true 151 1 185 108 298 108 207 175 242 282 151 216 59 282 94 175 3 108 116 108

target
false
0
Circle -7500403 true true 0 0 300
Circle -16777216 true false 30 30 240
Circle -7500403 true true 60 60 180
Circle -16777216 true false 90 90 120
Circle -7500403 true true 120 120 60

tree
false
0
Circle -7500403 true true 118 3 94
Rectangle -6459832 true false 120 195 180 300
Circle -7500403 true true 65 21 108
Circle -7500403 true true 116 41 127
Circle -7500403 true true 45 90 120
Circle -7500403 true true 104 74 152

triangle
false
0
Polygon -7500403 true true 150 30 15 255 285 255

triangle 2
false
0
Polygon -7500403 true true 150 30 15 255 285 255
Polygon -16777216 true false 151 99 225 223 75 224

truck
false
0
Rectangle -7500403 true true 4 45 195 187
Polygon -7500403 true true 296 193 296 150 259 134 244 104 208 104 207 194
Rectangle -1 true false 195 60 195 105
Polygon -16777216 true false 238 112 252 141 219 141 218 112
Circle -16777216 true false 234 174 42
Rectangle -7500403 true true 181 185 214 194
Circle -16777216 true false 144 174 42
Circle -16777216 true false 24 174 42
Circle -7500403 false true 24 174 42
Circle -7500403 false true 144 174 42
Circle -7500403 false true 234 174 42

turtle
true
0
Polygon -10899396 true false 215 204 240 233 246 254 228 266 215 252 193 210
Polygon -10899396 true false 195 90 225 75 245 75 260 89 269 108 261 124 240 105 225 105 210 105
Polygon -10899396 true false 105 90 75 75 55 75 40 89 31 108 39 124 60 105 75 105 90 105
Polygon -10899396 true false 132 85 134 64 107 51 108 17 150 2 192 18 192 52 169 65 172 87
Polygon -10899396 true false 85 204 60 233 54 254 72 266 85 252 107 210
Polygon -7500403 true true 119 75 179 75 209 101 224 135 220 225 175 261 128 261 81 224 74 135 88 99

wheel
false
0
Circle -7500403 true true 3 3 294
Circle -16777216 true false 30 30 240
Line -7500403 true 150 285 150 15
Line -7500403 true 15 150 285 150
Circle -7500403 true true 120 120 60
Line -7500403 true 216 40 79 269
Line -7500403 true 40 84 269 221
Line -7500403 true 40 216 269 79
Line -7500403 true 84 40 221 269

x
false
0
Polygon -7500403 true true 270 75 225 30 30 225 75 270
Polygon -7500403 true true 30 75 75 30 270 225 225 270
@#$#@#$#@
NetLogo 6.3.0
@#$#@#$#@
@#$#@#$#@
@#$#@#$#@
<experiments>
  <experiment name="impacto perceçãoleões" repetitions="10" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="500"/>
    <metric>count leoes</metric>
    <metric>count hienas</metric>
    <enumeratedValueSet variable="percecao_leoes">
      <value value="&quot;Apenasfrente&quot;"/>
      <value value="&quot;Esquerdafrentedireita&quot;"/>
      <value value="&quot;Redorcompleto&quot;"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="impacto reprodução" repetitions="10" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="500"/>
    <exitCondition>(count hienas &gt;= 500 or
count leoes &gt;= 500)</exitCondition>
    <metric>count leoes</metric>
    <metric>count hienas</metric>
    <enumeratedValueSet variable="Reproducao_animais">
      <value value="true"/>
      <value value="false"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="taxa_reproducao_hienas">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
      <value value="50"/>
    </enumeratedValueSet>
    <enumeratedValueSet variable="taxa_reproducao_leoes">
      <value value="10"/>
      <value value="20"/>
      <value value="30"/>
      <value value="40"/>
      <value value="50"/>
    </enumeratedValueSet>
  </experiment>
  <experiment name="impacto energiaanimais" repetitions="10" runMetricsEveryStep="true">
    <setup>setup</setup>
    <go>go</go>
    <timeLimit steps="500"/>
    <metric>count leoes</metric>
    <metric>count hienas</metric>
    <enumeratedValueSet variable="energia_animais">
      <value value="25"/>
      <value value="50"/>
      <value value="75"/>
      <value value="100"/>
    </enumeratedValueSet>
  </experiment>
</experiments>
@#$#@#$#@
@#$#@#$#@
default
0.0
-0.2 0 0.0 1.0
0.0 1 1.0 0.0
0.2 0 0.0 1.0
link direction
true
0
Line -7500403 true 150 150 90 180
Line -7500403 true 150 150 210 180
@#$#@#$#@
0
@#$#@#$#@
