#ifndef TRABALHOPRATICOCODIGO_HABITACAO_H
#define TRABALHOPRATICOCODIGO_HABITACAO_H

#include "zona.h"
#include <utility>
#include <vector>
#include <iostream>

using namespace std;

class Habitacao {

public:
    Habitacao(int linhas, int colunas);
    ~Habitacao();
    int adicionarZona(int linha_i, int col_i, int n_zonas);
    int removerZona(int zona_id, int n_zonas);
    int getNZonas()const;
    string listarZonas() const;
    void incZonas();
    void decZonas();
    int getInstantes() const;
    void incrementaInstantes(int n);
    Zona* procuraZona(int id);

private:
    vector <Zona*> zonas;
    int n_lin, n_col;
    int n_zonas;
    int instantes;
};

#endif //TRABALHOPRATICOCODIGO_HABITACAO_H
