#include "habitacao.h"

using namespace std;

Habitacao::Habitacao(int linhas, int colunas) :n_lin(linhas),n_col(colunas), n_zonas(0), instantes(0){}

Habitacao::~Habitacao(){}

int Habitacao::adicionarZona(int linha_i, int col_i, int n_zonas) {
    incZonas();
    ++n_zonas;
    zonas.push_back(new Zona(n_zonas,linha_i,col_i));
    return 1;
}

int Habitacao::removerZona(int zona_id, int n_zonas) {
    if(n_zonas==0)
        return -1;
    auto i = procuraZona(zona_id);
    if (i == nullptr)
        return 0;
    //zonas.erase(i);
    decZonas();
    return 1;
}

string Habitacao::listarZonas() const {
        string res;
        for (const Zona* z: zonas)
            res += z->zonaNumComp() + "\n";
        return res;
}

Zona* Habitacao::procuraZona(int id) {
    for (auto z:zonas) {
        if (z->getId()==id)
            return z;
    }
    return nullptr;
}

void Habitacao::incrementaInstantes(int n) {
    instantes+=n;
}

void Habitacao::incZonas() {
    n_zonas++;
}

void Habitacao::decZonas() {
    n_zonas--;
}

int Habitacao::getNZonas() const {return n_zonas;}

int Habitacao::getInstantes() const {return instantes;}
