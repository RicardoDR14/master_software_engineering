
#ifndef TRABALHOPRATICOCODIGO_MODELO_H
#define TRABALHOPRATICOCODIGO_MODELO_H
#include "Terminal.h"
#include <vector>
#include <string>
#include "iteracao.h"

using namespace std;
using namespace term;

class Modelo {
public:
    Modelo();
    void run();
    static void escrever_tamanho(Terminal &t);
private:
    Terminal &terminal;
    Window JanelaGrafica;
    Window JanelaMensagens;
    Window JanelaComandos;
    vector<Window> zonas;
    Iteracao iteracao;
};


#endif //TRABALHOPRATICOCODIGO_MODELO_H
