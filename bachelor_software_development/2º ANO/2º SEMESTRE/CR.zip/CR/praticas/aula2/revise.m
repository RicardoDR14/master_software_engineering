function [journey, new_case] = revise(retrieved_cases, new_case, new_price)
    
    retrieved_codes = retrieved_cases{:,1};
    code = str2double('-');
        
    while isnan(code) || fix(code) ~= code || ismember(code, retrieved_codes) == 0
        fprintf('From the retrieved cases, which is the one that better matches your journey?\n');
        code = str2double(input('Journey Code: ','s'));
    end
    
    journey = fix(code);

    %REVISE HOLIDAY_TYPE
    lista = {'Active', 'Bathing', 'City', 'Education', 'Language', 'Recreation', 'Skiing', 'Wandering'};
    fprintf('\nUpdate holiday type? (y/n)\n');
    option = input('Option: ', 's');
    if option == 'y' || option == 'Y'
        value = input('Novo valor: ','s');
        while ~ismember(lista, value)
            value = input ('Novo valor: ','s');
        end
        new_case.holiday_type = value;
    end

    %REVISE PRICE
    if new_price>0
        fprintf('\nUpdate your journey price to estimate ? (y/n)\n');
        option = input('Option: ', 's');
        if option == 'y' || option == 'Y'
            new_case.price = new_price;
        end

    else
        fprintf('\nUpdate your price? (y/n)\n');
        option = input('Option: ', 's');
        if option == 'y' || option == 'Y'
            value = str2double('-');
            while isnan(value)
                value = str2double(input('Novo valor: ','s'));
            end
            new_case.price = value;
        end
    end


    %REVISE NUMBER OF PERSONS
    fprintf('\nUpdate number of persons? (y/n)\n');
    option = input('Option: ', 's');
    if option == 'y' || option == 'Y'
        value = str2double('-');
        while isnan(value)
            value = str2double(input('Novo valor: ','s'));
        end
        new_case.number_persons = value;
    end
end