function start()
% Funcao rn3b: cria, treina e testa uma RN feedforward
% usando as funcoes da NNTool

% Limpar
clear all;
close all;


% Carregar dados START
data = readtable('Start.csv');

% Extrair os estágios e IDs dos pacientes
stroke = data.stroke;
ids = data.id;

% Obter o número de estágios e pacientes
num_strokes = 2; % 0 ou 1
num_pacientes = numel(ids);

% Inicializar a matriz com zeros
matriz = zeros(num_strokes, num_pacientes);

% Preencher a matriz conforme os stoke dos pacientes
for i = 1:num_pacientes
    % verifica se o stroke está a 1 ou 0
    % se for 0 preenche a primeira linha da matriz
    % se for 1 preenche a segunda
    if (stroke(i))
        matriz(2, i) = 1;
    else
        matriz(1, i) = 1;
    end
end

% Converter a tabela para matriz
data = table2array(data);

% Dividir dados em entrada (p) e alvos (t)
p = data(:, 1:end-1)';
t = matriz;

% Verificar dimensões de p e t
fprintf('Dimensões de p: %d x %d\n', size(p, 1), size(p, 2));
fprintf('Dimensões de t: %d x %d\n', size(t, 1), size(t, 2));

% Criar RN chamada net
net = feedforwardnet(10); % Uma camada oculta com 10 neurônios

% Ajustar a semente aleatória
rng(1); % Define a semente aleatória para 1

% Ajustar parâmetros
% FUNCAO DE TREINO 
net.trainFcn = 'trainlm'; % Treinamento com o algoritmo Levenberg-Marquardt

% NUMERO DE EPOCAS DE TREINO
net.trainParam.epochs = 50;

% TODOS OS EXEMPLOS DE INPUT SAO USADOS NO TREINO
net.divideFcn = '';                 


% Treinar a rede
tic; % Iniciar temporizador
net = train(net,p,t);
training_time = toc; % Tempo de treinamento

% Visualizar a rede
view(net);

% Simular a rede e guardar o resultado na variável y
y = sim(net,p);

% Mostrar resultado
y = (y >= 0.5);
disp('Saída da RN:');
disp(y);
disp('Saída desejada:');
disp(t);

% Calcular métricas de desempenho
num_acertos = 0;
for i = 1:size(y, 2)
    if isequal(y(:, i), t(:, i))
        num_acertos = num_acertos + 1;
    end
end

accuracy = (num_acertos / size(y, 2)) * 100;
error = mse(net, t, y);

% Exibir métricas de desempenho
fprintf('Precisao total: %.2f%%\n', accuracy);
fprintf('Erro: %.4f\n', error);
fprintf('Tempo de execucao: %.4f segundos\n', training_time);

end