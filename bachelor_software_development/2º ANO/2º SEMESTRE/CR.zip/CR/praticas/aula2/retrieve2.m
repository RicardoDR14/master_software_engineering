function [retrieved_indexes, similarities, new_case] = retrieve2(case_library, new_case, threshold)
    
    weighting_factors = [0 1 2 4 5 1 2 3 4 4 0];

    retrieved_indexes = [];
    similarities = [];
    lista = {'id','gender','age','hypertension','heart_disease','ever_married','Residence_type','avg_glucose_level','bmi','smoking_status','stroke'};

    % to_remove = [];
    % for i = 1 : length(lista)
    %     if ~isfield(new_case,lista{i})
    %         to_remove = [to_remove i];
    %     end
    % end
    % 
    % weighting_factors(to_remove) = 0;


    for i=1:size(case_library,1)%vai percorrer os 610 , a primeira query ta fixa e vai ser comparada com cada caso
        
        distances = zeros(1,11);

        if isfield(new_case,'id')
            distances(1,1) = isEqual(new_case.id,case_library{i,'id'});
        end  

        if isfield(new_case,'gender')
            distances(1,2) = isEqual(new_case.gender,case_library{i,'gender'});
        end  

        if isfield(new_case,'age')
            distances(1,3) = isEqual(new_case.age,case_library{i,'age'});
        end

        if isfield(new_case,'hypertension')
            distances(1,4) = isEqual(new_case.hypertension,case_library{i,'hypertension'});
        end

        if isfield(new_case,'heart_disease')
            distances(1,5) = isEqual(new_case.heart_disease,case_library{i,'heart_disease'});
        end

        if isfield(new_case,'ever_married')
            distances(1,6) = isEqual(new_case.ever_married,case_library{i,'ever_married'}) ;

        end

        if isfield(new_case,'Residence_type')
            distances(1,7) = isEqual(new_case.Residence_type,case_library{i,'Residence_type'}) ;
        end

        if isfield(new_case,'avg_glucose_level')
            distances(1,8) = isEqual(new_case.avg_glucose_level,case_library{i,'avg_glucose_level'}) ;
        end

        if isfield(new_case,'bmi')
            distances(1,9) = isEqual(new_case.bmi,case_library{i,'bmi'}) ;
        end

        if isfield(new_case,'smoking_status')
            distances(1,10) = isEqual(new_case.smoking_status,case_library{i,'smoking_status'}) ;
        end

        if isfield(new_case,'stroke')
            distances(1,11) = isEqual(new_case.stroke,case_library{i,'stroke'});
        end
        
        DG = (distances * weighting_factors')/sum(weighting_factors);
        final_similarity = 1-DG;
        
        if final_similarity >= threshold
            retrieved_indexes = [retrieved_indexes i];
            similarities = [similarities final_similarity];
        end
        
        fprintf('Case %d out of %d has a similarity of %.2f%%...\n', i, size(case_library,1), final_similarity*100);
    end
end

function [res] = isEqual(val1, val2)

    if (strcmp(val1,val2))
        res = 1;
    else
        res = 0;
    end
end