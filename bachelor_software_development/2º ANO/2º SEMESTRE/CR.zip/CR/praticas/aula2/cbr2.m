function [] = cbr2()

    similarity_threshold = 0.95;

    case_library = readtable('Train.csv');
    %disp(case_library);
    
    % New case data
    %new_case.id = '';
    new_case.gender = 'Female';
    new_case.age = 69;
    new_case.hypertension = 0;
    new_case.heart_disease = 0;
    new_case.ever_married = 'No';
    new_case.Residence_type = 'Urban';
    new_case.avg_glucose_level = 94.39;
    new_case.bmi = 22.8;
    new_case.smoking_status = 'never smoked';
    new_case.stroke = 'NA';
    
    fprintf('\nStarting retrieve phase...\n\n');
    [retrieved_indexes, similarities, new_case] = retrieve2(case_library, new_case, similarity_threshold);
    retrieved_cases = case_library(retrieved_indexes, :);
    retrieved_cases.Similarity = similarities';
    retrieved_cases = sortrows(retrieved_cases,'Similarity',"descend");
    fprintf('\nRetrieve phase completed...\n\n');
    
    disp(retrieved_cases);
    
    % if isfield(new_case, 'price')&&isfield(new_case, 'number_persons')&&isfield(new_case, 'duration')
    %     fprintf('\nStarting reuse phase...\n\n');
    %     new_price = reuse(retrieved_cases, new_case);
    %     fprintf('\n\nReuse phase completed...\n');
    % else
    %     new_price = -1;
    % end
    % 
    % fprintf('\nStarting revise phase...\n\n');
    % [journey, new_case] = revise(retrieved_cases, new_case, new_price);
    % final_index = find(case_library{:,1} == journey);
    % fprintf('\nRevise phase completed...\n');
    % 
    % fprintf('\nStarting retain phase...\n\n');
    % case_library = retain(case_library, new_case, final_index);
    % fprintf('\nRetain phase completed...\n\n');
    % 
    % disp(case_library(size(case_library,1), :));

end