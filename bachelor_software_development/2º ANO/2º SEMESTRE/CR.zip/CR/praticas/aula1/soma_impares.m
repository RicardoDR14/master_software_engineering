function [soma] = soma_impares(matriz)
    numeros = mod(matriz, 2)==1;
    soma = sum(matriz(numeros));
end