function [pares] = filtra_matriz(m)
 %   pares = [];
 %   for i = 1:numel(m)
 %       if mod(m(i),2) == 0
 %           pares = [pares m(i)];  
 %       end
 %   end
    indices = find(mod(m,2) == 0);
    pares = m(indices);
end