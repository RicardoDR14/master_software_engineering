function [matriz] = gera_matriz(a,b,x)
    matriz = randi(x,a,b);
end