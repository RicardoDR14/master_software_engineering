function [num] =  contapositvos_matriz(v)
  numeros = find(v > 0);
  num = numel(numeros);
end