function [maior , indice] = maiores_matriz(v)
    maior = max(v);
    indice = find(v==maior);
end