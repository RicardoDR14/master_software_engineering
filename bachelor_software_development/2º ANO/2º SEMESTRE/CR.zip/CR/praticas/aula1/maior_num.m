function [maior] = maior_num()
    num = input('Introduza um valor: ');
    numeros = [num];
    while num ~= 0
        num = input('Introduza um valor: ');
        numeros = [numeros num];
%        if num > maior
%            maior = num;
%        end
    end
    maior = max(numeros);
end