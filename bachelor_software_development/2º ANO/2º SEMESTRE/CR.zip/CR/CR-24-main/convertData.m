function convertData
    clc;
    file_path = "Dataset/Train.csv";
    [data] = readtable(file_path);
     disp(data.Properties.VariableNames);
    for i = 1:size(data,1)
        value = data.smoking_status{i};
        disp(value)
        if strcmp(value, "never smoked")
            data.smoking_status{i} = '0';
        elseif strcmp(value, 'formerly smoked')
            data.smoking_status{i} = '1';
        elseif strcmp(value, 'smokes')
            data.smoking_status{i} = '2';
        elseif strcmp(value, 'Unknown')
            data.smoking_status{i} = '3';
        end

    end
    disp("Acabou")
    writetable(data, file_path);
end
