function [accuracy_global,accuracy_test,error_global,elapsed_time,tr] = TRAIN(nomeRede,camadas, neuronios,iteracoes,activationFn, outputActivationFn,trainFn,trainRatio,validationRatio,testRatio,gravarRede)

% clear all;
% close all;
network_settings = repmat(neuronios,1,camadas);

% Carrega o dataset
dataset_path = "Dataset/Train.csv";
data = readmatrix(dataset_path);

inputs = data(:,2:end-1)';
targets = data(:,end)';

accuracy_global=[];
accuracy_test=[];
error_global = [];

tic;
for rep=1:iteracoes

net3 = feedforwardnet([network_settings]);

% COMPLETAR A RESTANTE CONFIGURACAO
if camadas == 1
    net3.layers{1:end-1}.transferFcn = activationFn;
else
    for i = 1:camadas
        net3.layers{i}.transferFcn = activationFn; % Para camadas intermediárias
    end
end

net3.layers{end}.transferFcn = outputActivationFn; 

net3.trainFcn = trainFn;

net3.divideFcn = 'dividerand';
net3.divideParam.trainRatio = trainRatio; 
net3.divideParam.valRatio   = validationRatio;
net3.divideParam.testRatio  = testRatio;

% TREINAR
[net3,tr] = train(net3, inputs, targets);

% SIMULAR
out = sim(net3, inputs);
out = (out >= 0.5);

error = mse(net3,out, targets);
error_global = [error_global error];

%Calcula a percentagem de classificacoes corretas no total dos exemplos
r=sum(out==targets);
accuracy= 100*r/size(targets,2);
accuracy_global = [accuracy_global accuracy];

% SIMULAR A REDE APENAS NO CONJUNTO DE TESTE
TInput = inputs(:, tr.testInd);
TTargets = targets(:, tr.testInd);

out = sim(net3, TInput);
out = (out >= 0.5);

%Calcula a precisão do teste

r=sum(out==TTargets);
accuracy= 100*r/size(TTargets,2);
accuracy_test = [accuracy_test accuracy];

end

elapsed_time = toc;

fprintf('Accuracy global %f\n', mean(accuracy_global))
fprintf("Accuracy teste %f\n", mean(accuracy_test))
fprintf("Erro global %f\n", mean(error_global))
fprintf("Tempo %f\n", elapsed_time)

% Salvar a rede
if gravarRede
    save(nomeRede, "net3");
end

disp(tr);
end