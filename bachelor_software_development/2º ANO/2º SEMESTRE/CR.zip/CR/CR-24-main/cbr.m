function [] = cbr()

    similarity_threshold = 0.9;
    
    dataset_path = "Dataset/Train.csv";

    data = readtable(dataset_path);
    
    uncompleted_cases_indices = getUncompletedCases(data)
    disp(data(uncompleted_cases_indices(1),:))
    for i = 1:size(uncompleted_cases_indices,1)
        new_case.gender = data.gender(uncompleted_cases_indices(i));
        new_case.age = data.age(uncompleted_cases_indices(i));        
        new_case.hypertension = data.hypertension(uncompleted_cases_indices(i));
        new_case.heart_disease = data.heart_disease(uncompleted_cases_indices(i));
        new_case.ever_married = data.ever_married(uncompleted_cases_indices(i));
        new_case.Residence_type = data.Residence_type(uncompleted_cases_indices(i));
        new_case.avg_glucose_level = data.avg_glucose_level(uncompleted_cases_indices(i));
        new_case.bmi = data.bmi(uncompleted_cases_indices(i));
        new_case.smoking_status = data.smoking_status(uncompleted_cases_indices(i));

        fprintf('\nStarting retrieve phase for case %d...\n\n',i);

        [retrieved_indexes, similarities, new_case] = retrieve(data, new_case, similarity_threshold);

        retrieved_cases = data(retrieved_indexes, :);

        retrieved_cases.Similarity = similarities';

        %Tem de ser o segundo, porque o primeiro vai ser sempre o próprio
        %caso
        best_retrieved_case = retrieved_cases(2, :);

        fprintf("\n Caso: %d\n", i);
        disp(new_case);
        fprintf("\n Caso mais similar para o caso %i\n",i)
        disp(best_retrieved_case);


        new_case.stroke = best_retrieved_case.stroke;
        fprintf('\nRetrieve phase completed for case %d...\n\n',i);

        %Atualizar os dados em memória
        data(uncompleted_cases_indices(i),:).stroke = new_case.stroke;
    end
    disp(data)
    writetable(data,dataset_path);
end

function [indices] = getUncompletedCases(data)
    indices = [];
    for i = 1:size(data,1)
        if isnan(data.stroke(i))
            indices = [indices; i];
        end
    end
end