function [accuracy_global] = TEST(net)
% Carrega o dataset
dataset_path = "Dataset/Test.csv";
data = readmatrix(dataset_path);

inputs = data(:,2:end-1)';
targets = data(:,end)';

% load('neural_network_1.mat'); % Carregar rede 1
% load('neural_network_2.mat'); % Carregar rede 2
% load('neural_network_3.mat'); % Carregar rede 3

% for i = 1:3
    % Simular a rede neural no conjunto de teste
out = sim(net, inputs);

% Calcular a precisão no conjunto de teste
out = (out >= 0.5);

r=sum(out==targets);
accuracy_global= 100*r/size(targets,2);

% Exibir a precisão para esta rede neural
fprintf('Precisão da Rede no Conjunto de Teste: %.2f%%\n', accuracy_global);
% end

end