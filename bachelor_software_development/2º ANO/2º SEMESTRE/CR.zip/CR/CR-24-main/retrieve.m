function [retrieved_indexes, similarities, new_case] = retrieve(case_library, new_case, threshold)
    
    weighting_factors = [2 4 1 3 1 1 5 4 4]; % Exemplo de pesos para os atributos presentes nos seus dados

    retrieved_indexes = [];
    similarities = [];
    
    for i=1:size(case_library,1)
        
        distances = zeros(1,9);
        
        % Calcular as distâncias para cada atributo
        
        distances(1) = calculate_linear_distance(case_library{i,'gender'}, new_case.gender);
        distances(2) = calculate_euclidean_distance(case_library{i,'age'} / 100, new_case.age / 100);
        distances(3) = calculate_linear_distance(case_library{i,'hypertension'}, new_case.hypertension);
        distances(4) = calculate_linear_distance(case_library{i,'heart_disease'}, new_case.heart_disease);
        distances(5) = calculate_linear_distance(case_library{i,'ever_married'}, new_case.ever_married);
        distances(6) = calculate_linear_distance(case_library{i,'Residence_type'}, new_case.Residence_type);
        distances(7) = calculate_euclidean_distance(case_library{i,'avg_glucose_level'} / 300, new_case.avg_glucose_level / 300);
        distances(8) = calculate_euclidean_distance(case_library{i,'bmi'} / 100, new_case.bmi / 100);
        
        % Calcular a similaridade global
        
        DG = (distances * weighting_factors') / sum(weighting_factors);
        final_similarity = 1 - DG;
        
        % Verificar se a similaridade atinge o limiar
        
        if final_similarity >= threshold
            retrieved_indexes = [retrieved_indexes i];
            similarities = [similarities final_similarity];
        end
        
        %fprintf('Case %d out of %d has a similarity of %.2f%%...\n', i, size(case_library,1), final_similarity * 100);
    end
     % Ordenar os casos recuperados com base na similaridade (do maior para o menor)
    [similarities, order] = sort(similarities, 'descend');
    retrieved_indexes = retrieved_indexes(order);
    
    % Selecionar apenas os casos com similaridade acima do limiar
    above_threshold = similarities >= threshold;
    retrieved_indexes = retrieved_indexes(above_threshold);
    similarities = similarities(above_threshold);
end

% Funções de cálculo de distância e similaridade aqui...

function [res] = calculate_linear_distance(val1, val2)

    res = abs(val1 - val2);
end

function [res] = calculate_euclidean_distance(val1, val2)

    res = sqrt ((val1 - val2)^2);
end