function plot_perform(axes,tr)
    plot(axes, tr.epoch, tr.perf, 'b-', tr.epoch, tr.vperf, 'r--', tr.epoch, tr.tperf, 'g:');
    xlabel(axes,'Épocas');
    ylabel(axes,'Desempenho');
    legend(axes,'Treino', 'Validação', 'Teste');
end