function [accuracy_global,error_global,elapsed_time,tr] = START(camadas, neuronios,iteracoes,activationFn, outputActivationFn,trainFn)
    %clear all;
    %close all;

    network_settings = repmat(neuronios,1,camadas);

    dataset_path = "Dataset/Start.csv";
    data = readmatrix(dataset_path, 'Delimiter',';','DecimalSeparator','.');
    
    inputs = data(:,2:end-1)';
    targets = data(:,end)';
    
    accuracy_global = [];
    error_global =  [];

    tic;
    for rep=1:iteracoes
    
        net = feedforwardnet(network_settings);
        
        %CONFIGURACAO DA REDE
        
        if camadas == 1
            net.layers{1:end-1}.transferFcn = activationFn;
        else
            for i = 1:camadas
                net.layers{i}.transferFcn = activationFn; % Para camadas intermediárias
            end
        end
        
        net.layers{end}.transferFcn = outputActivationFn;

        net.trainFcn = trainFn;
        net.divideFcn = '';

        % TREINAR
        [net,tr] = train(net, inputs, targets);
        
        % SIMULAR
        out = sim(net, inputs);
        out = (out >= 0.5);

        % ERRO
        error = mse(net,out, targets);
        error_global = [error_global error];
        
        % CALCULAR ACCURACY GLOBAL
        r=sum(out==targets);
        accuracy= 100*r/size(targets,2);
        accuracy_global = [accuracy_global accuracy];
    end

    elapsed_time = toc;

    fprintf('Accuracy global: %f\n', mean(accuracy_global))
    fprintf('Erro global: %f\n',mean(error_global))
    fprintf("Tempo de execução: %f\n", elapsed_time)
end
