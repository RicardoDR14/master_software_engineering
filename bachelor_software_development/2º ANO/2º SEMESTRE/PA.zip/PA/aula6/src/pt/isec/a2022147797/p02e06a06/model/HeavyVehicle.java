package pt.isec.a2022147797.p02e06a06.model;

import java.util.Comparator;

public class HeavyVehicle extends Vehicle implements IPassengers, IMaxLoad{

    private int passangerLimit, cargoLimit;

    public HeavyVehicle(String license, int year, int pLimit, int cLimit) {
        super(license, year);
        this.passangerLimit = pLimit;
        this.cargoLimit = cLimit;
    }

    public int getPassangerLimit() {
        return passangerLimit;
    }

    public int getCargoLimit() {
        return cargoLimit;
    }

    @Override
    public String toString() {
        return String.format("HeavyVehicle - " + super.toString()+
                ", PassangerLimit=" + passangerLimit +
                ", CargoLimit=" + cargoLimit +
                ';');
    }

    @Override
    public int getMaxWeight() {
        return cargoLimit;
    }

    @Override
    public int getNumberPassengers() {
        return passangerLimit;
    }
}
