package pt.isec.a2022147797.p02e06a06;
import pt.isec.a2022147797.p02e06a06.model.*;


public class Main {
    public static void main(String[] args) {
        Fleet frota = new Fleet("frota");

        LightVehicle lv = new LightVehicle("00-aa-00", 2000, 5);
        HeavyVehicle hv = new HeavyVehicle("11-bb-11",2001,7,700);
        HeavyGoodsVehicles hgv = new HeavyGoodsVehicles("22-cc-22", 2022,8000);

        frota.addVehicle(lv);
        frota.addVehicle(hv);
        frota.addVehicle(hgv);

        System.out.println(frota.listVehicles());

        frota.removeVehicle(lv.getLicensePlate());

        System.out.println(frota.listVehicles());
    }
}