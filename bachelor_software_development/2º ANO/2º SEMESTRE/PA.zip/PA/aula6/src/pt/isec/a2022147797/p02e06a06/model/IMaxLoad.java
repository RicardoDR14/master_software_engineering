package pt.isec.a2022147797.p02e06a06.model;

import java.util.Comparator;

public interface IMaxLoad {
    int getMaxWeight();
}

class MaxLoadReverseComparator implements Comparator<IMaxLoad> {

    @Override
    public int compare(IMaxLoad o1, IMaxLoad o2) {
        return o1.getMaxWeight() - o2.getMaxWeight();
    }
}
