package pt.isec.a2022147797.p02e06a06.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class HeavyGoodsVehicles extends Vehicle implements IMaxLoad{

    private int cargoLimit;

    public HeavyGoodsVehicles(String license, int year, int cLimit) {
        super(license, year);
        this.cargoLimit = cLimit;
    }

    @Override
    public String toString() {
        return String.format("HeavyGoodsVehicles - " + super.toString()+
                ", CargoLimit=" + cargoLimit +
                ';');
    }

    @Override
    public int getMaxWeight() {
        return cargoLimit;
    }
}
