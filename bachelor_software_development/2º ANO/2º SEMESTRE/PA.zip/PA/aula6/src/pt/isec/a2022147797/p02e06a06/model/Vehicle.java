package pt.isec.a2022147797.p02e06a06.model;

public class Vehicle{

    private String licensePlate;
    private int year;

    protected Vehicle(String license, int year) {
        this.licensePlate = license.toUpperCase();
        this.year = year;
    }

    public String getLicensePlate() {
        return licensePlate;
    }

    public int getYear() {
        return year;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Vehicle vehicle)) return false;
        return licensePlate.equals(vehicle.licensePlate);
    }

    @Override
    public int hashCode() {
        return licensePlate != null ? licensePlate.hashCode() : 0;
    }

    @Override
    public String toString() {
        return String.format("licensePlate='" + licensePlate + '\'' +
                ", year=" + year );
    }
}