package pt.isec.a2022147797.p02e06a06.model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class Fleet {
    private String name;
    private Set<Vehicle> setVehicles;

    public Fleet(String nome) {
        this.name = nome;
        setVehicles = new HashSet<Vehicle>();
    }

    public boolean addVehicle(Vehicle vehicle) {
        return setVehicles.add(vehicle);
    }

    public boolean removeVehicle(String license) {
        return setVehicles.remove(new Vehicle(license, 0));
    }

    public String listVehicles() {
        if (setVehicles.isEmpty()) return "frota vazia....\n";
        StringBuilder output = new StringBuilder();
        output.append(String.format("Frota %s:\n", name));
        for (Vehicle v : setVehicles)
            output.append(String.format(" - %s\n", v));
        return output.toString();
    }

    public String listVehiclesSortedNrPassangers() {
        if (setVehicles.isEmpty()) return "frota vazia....\n";
        StringBuilder output = new StringBuilder();
        output.append(String.format("Frota %s:\n", name));

        List<IPassengers> orderList = new ArrayList<>();
        for (Vehicle v : setVehicles)
            if (v instanceof IPassengers)
                orderList.add((IPassengers) v);

        orderList.sort(((o1, o2) -> o1.getNumberPassengers() - o2.getNumberPassengers()));

        for (IPassengers v : orderList)
            output.append(String.format(" - %s\n", v));
        return output.toString();
    }

    public String listVehiclesSortedMaxLoad() {
        if (setVehicles.isEmpty()) return "frota vazia....\n";
        StringBuilder output = new StringBuilder();
        output.append(String.format("Frota %s:\n", name));

        List<IMaxLoad> orderList = new ArrayList<>();
        for (Vehicle v : setVehicles)
            if (v instanceof IPassengers)
                orderList.add((IMaxLoad) v);

        orderList.sort(((o1, o2) -> o1.getMaxWeight() - o2.getMaxWeight()));

        for (IMaxLoad v : orderList)
            output.append(String.format(" - %s\n", v));
        return output.toString();
    }
}
