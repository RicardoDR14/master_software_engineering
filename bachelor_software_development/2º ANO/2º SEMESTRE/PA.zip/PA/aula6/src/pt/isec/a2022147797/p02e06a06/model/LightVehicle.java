package pt.isec.a2022147797.p02e06a06.model;

import java.util.Comparator;

public class LightVehicle extends Vehicle implements IPassengers {

    private int passengerLimit;

    public LightVehicle(String license, int year, int pLimit) {
        super(license, year);
        this.passengerLimit = pLimit;
    }

    @Override
    public String toString() {
        return String.format("LightVehicle - " + super.toString()+
                ", PassangerLimit = '" + passengerLimit +
                ';');
    }

    @Override
    public int getNumberPassengers() {
        return passengerLimit;
    }
}
