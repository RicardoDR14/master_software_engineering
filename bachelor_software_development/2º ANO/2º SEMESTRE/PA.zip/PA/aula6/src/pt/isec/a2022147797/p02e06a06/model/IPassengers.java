package pt.isec.a2022147797.p02e06a06.model;

import java.util.Comparator;

public interface IPassengers {
    int getNumberPassengers();
}

class NumberOfPassangersComparator implements Comparator<IPassengers>{
    @Override
    public int compare(IPassengers o1, IPassengers o2) {
        return o1.getNumberPassengers() - o2.getNumberPassengers();
    }
}
