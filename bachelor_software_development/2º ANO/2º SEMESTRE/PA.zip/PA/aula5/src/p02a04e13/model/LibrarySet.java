package p02a04e13.model;

import java.util.*;

public class LibrarySet extends Library {

    private Set<Book> books;

    public LibrarySet(String name) {
        super(name);
        this.books = new HashSet<>();
    }

    @Override
    public int addBook(Book book) {
        if(!books.add(book))
            return -1;
        return book.getId();
    }

    @Override
    protected Collection<Book> getBooks(){
        return books;
    }
}
