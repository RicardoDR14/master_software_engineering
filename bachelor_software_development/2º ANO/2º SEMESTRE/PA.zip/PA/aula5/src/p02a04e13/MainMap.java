package p02a04e13;

import p02a04e13.model.ILibrary;
import p02a04e13.model.LibraryMap;
import p02a04e13.ui.LibraryUI;

public class MainMap {
    public static void main(String[] args) throws CloneNotSupportedException {
        ILibrary library = new LibraryMap("DEIS-ISEC-List");
        LibraryUI ui = new LibraryUI(library);
        ui.start();
    }
}
