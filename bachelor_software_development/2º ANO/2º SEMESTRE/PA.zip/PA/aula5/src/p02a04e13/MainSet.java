package p02a04e13;

import p02a04e13.model.ILibrary;
import p02a04e13.model.LibrarySet;
import p02a04e13.ui.LibraryUI;

public class MainSet {
    public static void main(String[] args) throws CloneNotSupportedException {
        ILibrary library = new LibrarySet("DEIS-ISEC-List");
        LibraryUI ui = new LibraryUI(library);
        ui.start();
    }
}
