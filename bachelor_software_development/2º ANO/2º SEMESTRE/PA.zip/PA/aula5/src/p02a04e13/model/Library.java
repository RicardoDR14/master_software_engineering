package p02a04e13.model;

import java.util.*;

public abstract class Library implements ILibrary {

    private String name;

    public Library(String name) {
        this.name = name;
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    protected abstract int addBook(Book book);
//    @Override
//    public int addBook(String title, List<String> authors) {
//        return addBook(new Book(title, authors));
//    }


    @Override
    public int addOldBook(String title, List<String> authors, int nrCopies) {
        return addBook(new OldBook(title, authors, nrCopies));
    }

    @Override
    public int addRecentBook(String title, List<String> authors, String isbn, double price) {
        return addBook(new RecentBook(title, authors, isbn, price));
    }

    protected abstract Collection<Book> getBooks();

    @Override
    public Book findBook(int id) throws CloneNotSupportedException {
        Collection<Book> books = getBooks();
        for (Book book : books)
            if (book.getId() == id)
                return book.clone();
        return null;
    }

    @Override
    public Book findBook(String title) throws CloneNotSupportedException {
        Collection<Book> books = getBooks();
        for (Book book : books)
            if (book.getTitle().equalsIgnoreCase(title))
                return book.clone();
        return null;
    }

    @Override
    public boolean removeBook(String title) {
        Collection<Book> books = getBooks();
        return books.remove(new Book(title, List.of()));
    }

    @Override
    public boolean removeBook(int id) {
        Collection<Book> books = getBooks();
        for (Book book : books)
            if (book.getId() == id)
                return books.remove(book);
        return false;
    }

    @Override
    public String toString() {
        Collection<Book> books = getBooks();
        StringBuilder output = new StringBuilder();
        output.append(String.format("Library %s:\n", name));
        for (Book book : books)
            output.append(String.format(" - %s\n", book));
        return output.toString();
    }

    @Override
    public String toStringSorted() {
        Collection<Book> books = getBooks();
        List<Book> tempBook = new ArrayList<>(books);
        //Collections.sort(tempBook);
        //Collections.sort(tempBook,new BookComparator());
        //Collections.sort(tempBook,new BookComparatorIgnoreCase());
        //tempBook.sort(new BookComparator());
        tempBook.sort((o1,o2)-> o1.getTitle().compareTo(o2.getTitle()));

        StringBuilder output = new StringBuilder();
        output.append(String.format("Library %s:\n", name));
        for (Book book : tempBook)
            output.append(String.format(" - %s\n", book));
        return output.toString();
    }

}

class BookComparator implements Comparator<Book>{
    @Override
    public int compare(Book o1, Book o2){
        return o1.getTitle().compareTo(o2.getTitle());
    }
}

class BookComparatorIgnoreCase implements Comparator<Book>{
    @Override
    public int compare(Book o1, Book o2){
        return o1.getTitle().compareToIgnoreCase(o2.getTitle());
    }
}