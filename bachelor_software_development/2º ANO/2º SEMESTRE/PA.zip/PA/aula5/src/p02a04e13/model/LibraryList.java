package p02a04e13.model;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class LibraryList extends Library {

    private List<Book> books;

    public LibraryList(String name) {
        super(name);
        this.books = new ArrayList<>();
    }

    @Override
    public int addBook(Book book) {
        if (books.contains(book))
            return -1;
        books.add(book);
        return book.getId();
    }

    @Override
    protected Collection<Book> getBooks() {
        return books;
    }
}
