package p02a04e13;

import p02a04e13.model.ILibrary;
import p02a04e13.model.LibraryList;
import p02a04e13.ui.LibraryUI;

public class MainList {
    public static void main(String[] args) throws CloneNotSupportedException {
        ILibrary library = new LibraryList("DEIS-ISEC-List");
        LibraryUI ui = new LibraryUI(library);
        ui.start();
    }
}

