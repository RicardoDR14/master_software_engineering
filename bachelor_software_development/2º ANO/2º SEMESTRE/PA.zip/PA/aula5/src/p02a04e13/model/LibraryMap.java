package p02a04e13.model;

import java.util.*;

public class LibraryMap extends Library {

    private Map<Integer, Book> books;

    public LibraryMap(String name) {
        super(name);
        this.books = new HashMap<>();
    }

    @Override
    public int addBook(Book book) {
        if (books.values().contains(book))
            return -1;
        books.put(book.getId(), book);
        return book.getId();
    }

    @Override
    public Book findBook(int id) throws CloneNotSupportedException {
        Book book = books.get(id);
        return book == null ? null : book.clone();
    }

    @Override
    public boolean removeBook(String title) {
        for (Book book : books.values())
            if (book.getTitle().equalsIgnoreCase(title))
                return books.remove(book.getId()) != null;
        return false;
    }

    @Override
    public boolean removeBook(int id) {
        return books.remove(id) != null;
    }

    @Override
    protected Collection<Book> getBooks() {
        return books.values();
    }
}
