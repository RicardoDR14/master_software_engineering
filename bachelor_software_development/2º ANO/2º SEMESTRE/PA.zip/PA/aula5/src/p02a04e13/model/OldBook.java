package p02a04e13.model;


import java.util.List;

public class OldBook extends Book{

    private int nrCopies;

    public OldBook(String title, List<String> authors, int nrCopies) {
        super(title, authors);
        this.nrCopies = nrCopies;
    }

    public int getNrCopies() {
        return nrCopies;
    }

    public void setNrCopies(int nrCopies) {
        this.nrCopies = nrCopies;
    }

    @Override
    public String toString() {
        return String.format("{OldBook - " + super.toString() + ", nrCopies=" + nrCopies + '}');
    }
}
