package p02a04e13.model;

import java.util.List;

public class RecentBook extends Book{

    private String ISBN;
    private double price;

    public RecentBook(String title, List<String> authors, String isbn, double price) {
        super(title, authors);
        this.ISBN = isbn;
        this.price=price;
    }

    public String getISBN() {
        return ISBN;
    }

    public void setISBN(String ISBN) {
        this.ISBN = ISBN;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return String.format("{ RecentBook - " + super.toString()+
                "ISBN='" + ISBN + '\'' +
                ", price=" + price +
                '}');
    }
}
