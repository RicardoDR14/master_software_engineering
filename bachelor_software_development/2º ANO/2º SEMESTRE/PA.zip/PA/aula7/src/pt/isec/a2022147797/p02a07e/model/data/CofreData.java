package pt.isec.a2022147797.p02a07e.model.data;

public class CofreData {
    private static final String CODE_PIN = "1234";
    private static final String CODE_PUK = "653262";
    private static final int MAX_TENT = 3;

    private int tentativas;
    private double saldo;
    private boolean aberta;

    public CofreData(){
        tentativas = 0;
        saldo = 0;
        aberta = false;
    }

    public boolean isPortaAberta() {
        return aberta;
    }

    public boolean isBloqueado() {
        return tentativas>=MAX_TENT;
    }

    public int getTentativasFalhadas() {
        return tentativas;
    }

    public double getSaldo() {
        if (!aberta/*||isBloqueado()*/) return -1;
        return saldo;
    }

    public boolean deposita(double qt){
        if (!aberta/*||isBloqueado()*/||qt<=0.0)return false;
        saldo+=qt;
        return true;
    }

    public boolean levantar( double qt) {
        if (!aberta/*||isBloqueado()*/||qt>saldo)return false;
        saldo-=qt;
        return true;
    }

    public boolean abrir(String codigo) {
        if (codigo == null||aberta/*||isBloqueado()*/) return false;
        if (CODE_PIN.equals(codigo)){
            aberta = true;
            tentativas = 0;
            return true;
        }
        tentativas++;
        return false;
    }

    public boolean fechar(){
        if (!aberta/*||isBloqueado()*/)return false;
        aberta = false;
        return true;
    }

    public boolean desbloquear(String codigo) {
        if (codigo == null/*||isBloqueado()*/) return false;
        if (CODE_PIN.equals(codigo)){
            tentativas = 0;
            return true;
        }
        return true;
    }
}
