package pt.isec.a2022147797.p02a07e.model.fsm.states;

import pt.isec.a2022147797.p02a07e.model.data.CofreData;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreContext;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreState;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreStateAdapter;

public class CofreAbertoState extends CofreStateAdapter {
    public CofreAbertoState(CofreContext context, CofreData data) {
        super(context, data);
    }

    @Override
    public boolean fechar() {
        boolean res = data.fechar();
        if (res) changeState(CofreState.FECHADO);
        return res;
    }

    @Override
    public boolean depositar(double qt) {
        return data.deposita(qt);
    }

    @Override
    public boolean levantar(double qt) {
        return data.levantar(qt);
    }

    @Override
    public double consultar() {
        return data.getSaldo();
    }

    @Override
    public CofreState getState() {
        return CofreState.ABERTO;
    }
}
