package pt.isec.a2022147797.p02a07e.model.fsm.states;

import pt.isec.a2022147797.p02a07e.model.data.CofreData;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreContext;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreState;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreStateAdapter;

public class CofreBloqueadoState extends CofreStateAdapter {
    public CofreBloqueadoState(CofreContext context, CofreData data) {
        super(context, data);
    }

    @Override
    public boolean desbloquear(String codigo) {
        boolean res = data.desbloquear(codigo);
        if (res)
            changeState(CofreState.FECHADO);
        return res;
    }

    @Override
    public CofreState getState() {
        return CofreState.BLOQUEADO;
    }
}
