package pt.isec.a2022147797.p02a07e.model.fsm.states;

import pt.isec.a2022147797.p02a07e.model.fsm.CofreState;

public interface ICofreState{
    boolean abrir(String codigo);
    boolean fechar();
    boolean desbloquear(String codigo);
    
    boolean depositar(double qt);
    boolean levantar(double qt);
    
    double consultar();
    
    CofreState getState();
}
