package pt.isec.a2022147797.p02a07e.model.fsm.states;

import pt.isec.a2022147797.p02a07e.model.data.CofreData;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreContext;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreState;
import pt.isec.a2022147797.p02a07e.model.fsm.CofreStateAdapter;
import pt.isec.a2022147797.p02a07e.model.fsm.states.CofreAbertoState;
import pt.isec.a2022147797.p02a07e.model.fsm.states.CofreBloqueadoState;

public class CofreFechadoState extends CofreStateAdapter {
    public CofreFechadoState(CofreContext context, CofreData data) {
        super(context, data);
    }

    @Override
    public boolean abrir(String codigo) {
        boolean res = data.abrir(codigo);
        if(res){
            changeState(CofreState.ABERTO);
            return true;
        }
        if (data.isBloqueado())
            changeState(CofreState.FECHADO);
        //else
        //    changeState(new CofreFechadoState(context,data));

        return false;
    }

    @Override
    public CofreState getState() {
        return CofreState.FECHADO;
    }
}
