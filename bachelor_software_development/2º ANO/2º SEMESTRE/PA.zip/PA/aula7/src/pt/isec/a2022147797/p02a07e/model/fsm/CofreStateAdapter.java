package pt.isec.a2022147797.p02a07e.model.fsm;

import pt.isec.a2022147797.p02a07e.model.data.CofreData;
import pt.isec.a2022147797.p02a07e.model.fsm.states.ICofreState;

public abstract class CofreStateAdapter implements ICofreState {

    protected CofreContext context;
    protected CofreData data;

    protected CofreStateAdapter(CofreContext context, CofreData data){
        this.context = context;
        this.data = data;
    }

//    protected void changeState(ICofreState newState){
//        context.changeState(newState);
//    }

    protected void changeState(CofreState newState){
        context.changeState(
                //CofreStateFactory.getInstance(newState,context,data)
                //CofreState.getInstance(newState,context,data);
                newState.getInstance(context,data)
        );
    }

    @Override
    public boolean abrir(String codigo) {
        return false;
    }

    @Override
    public boolean fechar() {
        return false;
    }

    @Override
    public boolean desbloquear(String codigo) {
        return false;
    }

    @Override
    public boolean depositar(double qt) {
        return false;
    }

    @Override
    public boolean levantar(double qt) {
        return false;
    }

    @Override
    public double consultar() {
        return -1;
    }
}
