package pt.isec.a2022147797.p02a07e.ui;

import pt.isec.a2022147797.p02a07e.model.fsm.CofreContext;

public class CofreUI {

    private final CofreContext fsm;

    public CofreUI(CofreContext fsm){
        this.fsm = fsm;
    }

    public void start() {
        int res;
        do {
            System.out.println("\n\n***** SIMULADOR DO COFRE *****\n");
            System.out.println("Estado atual: "+fsm.getState());
            System.out.println("Tentativas falhadas: "+fsm.getTentativasFalhadas());
            System.out.println();
            res = PAInput.chooseOption("Ações",
                    "Abrir cofre",
                    "Fechar cofre",
                    "Desbloquear cofre",
                    "Depositar dinheiro",
                    "Levantar dinheiro",
                    "Consultar dinheiro",
                    "Sair");
            switch (res) {
                case 1 -> fsm.abrir(PAInput.readString("Código: ",false));
                case 2 -> fsm.fechar();
                case 3 -> fsm.desbloquear(PAInput.readString("PUK: ",false));
                case 4 -> fsm.depositar(PAInput.readNumber("Valor: "));
                case 5 -> fsm.levantar(PAInput.readNumber(
                        String.format("Valor [máx. %.2f ]: ",fsm.consultar())));
                case 6 -> System.out.printf("Saldo: %.2f",fsm.consultar());
            }
        } while(res != 7);
    }
}
