package pt.isec.a2022147797.p02a07e.model.fsm;

import pt.isec.a2022147797.p02a07e.model.data.CofreData;
import pt.isec.a2022147797.p02a07e.model.fsm.states.CofreFechadoState;
import pt.isec.a2022147797.p02a07e.model.fsm.states.ICofreState;

public class CofreContext {
    ICofreState atual;
    CofreData data;

    public CofreContext(){
        data = new CofreData();
        atual = CofreState.FECHADO.getInstance(this,data);
    }

    public CofreContext(CofreData data){//dependency injection
        this.data = data;
        atual = new CofreFechadoState(this,data);
    }

    //package-private
    void changeState(ICofreState newState) {
        atual = newState;
    }


    public CofreState getState(){
        return atual.getState();
    }

    //transitions
    public boolean abrir(String codigo) {
        return atual.abrir(codigo);
    }

    public boolean fechar() {
        return atual.fechar();
    }

    public boolean desbloquear(String codigo) {
        return atual.desbloquear(codigo);
    }

    public boolean depositar(double qt) {
        return atual.depositar(qt);
    }

    public boolean levantar(double qt) {
        return atual.levantar(qt);
    }

    //getters contextuais
    public double consultar() {
        return atual.consultar();
    }

    //getters globais
    public int getTentativasFalhadas(){
        return data.getTentativasFalhadas();
    }

    public boolean isPortaAberta(){
        return data.isPortaAberta();
    }

    public boolean isCofreBloqueado(){
        return data.isBloqueado();
    }
}
