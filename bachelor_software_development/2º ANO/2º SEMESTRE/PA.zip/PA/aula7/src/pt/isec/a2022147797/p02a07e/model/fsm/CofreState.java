package pt.isec.a2022147797.p02a07e.model.fsm;

import pt.isec.a2022147797.p02a07e.model.data.CofreData;
import pt.isec.a2022147797.p02a07e.model.fsm.states.CofreAbertoState;
import pt.isec.a2022147797.p02a07e.model.fsm.states.CofreBloqueadoState;
import pt.isec.a2022147797.p02a07e.model.fsm.states.CofreFechadoState;
import pt.isec.a2022147797.p02a07e.model.fsm.states.ICofreState;

public enum CofreState {
    ABERTO, BLOQUEADO, FECHADO;

    public static ICofreState getInstance(CofreState type, CofreContext context, CofreData data) {
        return switch (type) {
            case ABERTO -> new CofreAbertoState(context, data);
            case BLOQUEADO -> new CofreBloqueadoState(context, data);
            case FECHADO -> new CofreFechadoState(context, data);
        };
    }

    //ABERTO.getInstance(.....)
    public ICofreState getInstance(CofreContext context, CofreData data) {
        return switch (this) {
            case ABERTO -> new CofreAbertoState(context, data);
            case BLOQUEADO -> new CofreBloqueadoState(context, data);
            case FECHADO -> new CofreFechadoState(context, data);
        };
    }


}
class CofreStateFactory{
    private CofreStateFactory(){}

    public static ICofreState getInstance(CofreState type, CofreContext context, CofreData data) {
        return switch (type) {
            case ABERTO -> new CofreAbertoState(context, data);
            case BLOQUEADO -> new CofreBloqueadoState(context, data);
            case FECHADO -> new CofreFechadoState(context, data);
        };
    }
}
