package pt.isec.a2022147797.p02a07e;

import pt.isec.a2022147797.p02a07e.model.fsm.CofreContext;
import pt.isec.a2022147797.p02a07e.ui.CofreUI;

public class Main {
    public static void main(String[] args) {
        CofreContext fsm = new CofreContext();
        CofreUI ui = new CofreUI(fsm);
        ui.start();
    }
}
