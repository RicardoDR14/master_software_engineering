package pt.isec.pa.exerc29.ui.gui;

import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Ellipse;
import javafx.scene.shape.Line;
import javafx.scene.shape.Rectangle;
import pt.isec.pa.exerc29.model.ModelManager;
import pt.isec.pa.exerc29.utils.AppLog;

public class RootPane extends BorderPane {
    private static final String OPT_LINE = "Line";
    private static final String OPT_RECTANGLE = "Rectangle";
    private static final String OPT_ELLIPSE = "Ellipse";

    ModelManager model;
    Pane centralPane;
    ToggleGroup tgr;
    ToggleButton btnLine, btnRectangle, btnEllipse;

    public RootPane(ModelManager model) {
        this.model = model;

        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {
        HBox hbox = new HBox();
        tgr = new ToggleGroup();
        btnLine = new ToggleButton(OPT_LINE);
        btnLine.setToggleGroup(tgr);
        btnLine.setPrefWidth(Integer.MAX_VALUE);
        btnRectangle = new ToggleButton(OPT_RECTANGLE);
        btnRectangle.setToggleGroup(tgr);
        btnRectangle.setPrefWidth(Integer.MAX_VALUE);
        btnEllipse = new ToggleButton(OPT_ELLIPSE);
        btnEllipse.setToggleGroup(tgr);
        btnEllipse.setPrefWidth(Integer.MAX_VALUE);
        tgr.selectToggle(btnLine);
        hbox.getChildren().addAll(btnLine, btnRectangle, btnEllipse);
        this.setTop(hbox);
        centralPane = new Pane();
        setCenter(centralPane);
    }

    private void registerHandlers() {
        btnLine.setOnAction(evt -> update());
        btnRectangle.setOnAction(evt -> update());
        btnEllipse.setOnAction(evt -> update());
        centralPane.setOnMouseClicked(evt -> {
            AppLog.getInstance().add(
                    String.format("x:%.2f y:%.2f Shift:%b Ctrl:%b Alt:%b",
                            evt.getX(),evt.getY(),evt.isShiftDown(), evt.isControlDown(),evt.isAltDown()
                    )
            );
        });
        centralPane.setOnMousePressed(evt -> {
            model.setP1(evt.getX(),evt.getY());
            model.setP2(evt.getX(),evt.getY());
            model.defineColor();
            update();
        });

    }

    private void update() {
        centralPane.getChildren().clear();
        var line = new Line(50,50,200,100);
        var rect = new Rectangle(250,50,100,50);
        var elip = new Ellipse(225,175,75,50);
        line.setStroke(Color.INDIGO);
        rect.setStroke(Color.INDIGO);
        elip.setStroke(Color.INDIGO);
        if (btnLine.isSelected()) {
            rect.setFill(null);
            elip.setFill(null);
        } else if (btnRectangle.isSelected()) {
            rect.setFill(Color.ORANGE);
            elip.setFill(Color.ORANGE);
        } else if (btnEllipse.isSelected()) {
            rect.setFill(Color.color(Math.random(), Math.random(), Math.random()));
            elip.setFill(Color.color(Math.random(), Math.random(), Math.random()));
        }
        centralPane.getChildren().addAll(line,rect,elip);
    }
}
