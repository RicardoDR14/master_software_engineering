package pt.isec.pa.exerc29.model;

import pt.isec.pa.exerc29.model.data.Figure;

public class ModelManager {
    Figure figure;

    public ModelManager() {
        figure = new Figure();
    }

    /* TODO */

    public void defineColor() {
        figure.defineColor();
    }

    public void defineColor(double r, double g, double b) {
        figure.defineColor(r,g,b);
    }

    public double getX1() {
        return figure.getX1();
    }

    public void setX1(double x1) {
        figure.setX1(x1);
    }

    public double getY1() {
        return figure.getY1();
    }

    public void setY1(double y1) {
        figure.setY1(y1);
    }

    public double getX2() {
        return figure.getX2();
    }

    public void setX2(double x2) {
        figure.setX2(x2);
    }

    public double getY2() {
        return figure.getY2();
    }

    public void setY2(double y2) {
        figure.setY2(y2);
    }

    public void setP1(double x, double y){
        figure.setX1(x);
        figure.setY1(y);
    }

    public void setP2(double x, double y){
        figure.setX2(x);
        figure.setY2(y);
    }

    public double getR() {
        return figure.getR();
    }

    public void setR(double r) {
        figure.setR(r);
    }

    public double getG() {
        return figure.getG();
    }

    public void setG(double g) {
        figure.setG(g);
    }

    public double getB() {
        return figure.getB();
    }

    public void setB(double b) {
        figure.setB(b);
    }

    public boolean isFill() {
        return figure.isFill();
    }

    public void setFill(boolean fill) {
        figure.setFill(fill);
    }


}
