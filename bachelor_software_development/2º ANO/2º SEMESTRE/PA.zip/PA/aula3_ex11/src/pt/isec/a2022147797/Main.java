package pt.isec.a2022147797;

import pt.isec.a2022147797.ui.ReportUI;

public class Main {
    public static void main(String[] args) {
        ReportUI ui = new ReportUI();
        ui.menu();
    }
}
