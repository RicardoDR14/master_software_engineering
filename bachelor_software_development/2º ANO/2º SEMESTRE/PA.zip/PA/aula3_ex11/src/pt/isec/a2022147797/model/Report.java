package pt.isec.a2022147797.model;

import java.util.Arrays;
import java.util.Scanner;
import java.util.StringTokenizer;

public class Report {
    private  static  final int INC_AUTHORS = 5;
    String title;
    String [] authors;
    int qtAuthors;
    StringBuilder text;

    public Report(String title) {
        this.title = title;
        this.text = new StringBuilder();
        this.authors = new String[5];
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getText() {
        return text.toString();
    }

    public void addText(String newText){
        text.append(newText);
    }

    public boolean addAuthor(String author){
        //if (qtAuthors >= authors.length)
        //    return false;

        for (int i = 0; i < qtAuthors; i++) {
            if (authors[i].equalsIgnoreCase(author))
                return false;
        }

        if (qtAuthors>=authors.length){
            String [] newAuthors= new String[authors.length+INC_AUTHORS];
            System.arraycopy(authors,0,newAuthors,0,authors.length);
            authors=newAuthors;

            //authors= Arrays.copyOf(authors,authors.length+INC_AUTHORS);
        }

        authors[qtAuthors++]=author;
        return true;
    }
    public void removeAuthor(String author) {
    }

    public int getNumberOfWords() {
        /*
        int counter = 0;
        Scanner stext = new Scanner(text.toString());
        stext.useDelimiter("[\\s,.!?]+");
        while(stext.hasNext()){
            counter++;
            stext.next();
        }
        return counter;
        */

        /*
        String[]words=text.toString().split("[\\s,.!?]+");
        return words.length;
        */

        StringTokenizer st = new StringTokenizer(text.toString()," \t\n\r,.!?");
        return st.countTokens();
    }

    public void capitalizeSentences() {
        boolean changeNext =true;
        for (int i = 0; i < text.length(); i++) {
            char c = text.charAt(i);
            if (changeNext && Character.isLetter(c)){
                text.setCharAt(i,Character.toUpperCase(c));
                changeNext = false;
            }
            else if (".!?".indexOf(c)>=0)
                changeNext =true;
        }
    }

    public int getNumberOfOccurrences(String word) {
        int counter = 0;
        StringTokenizer st = new StringTokenizer(text.toString()," \t\n\r,.!?");
        while (st.hasMoreTokens()){
            if (word.equalsIgnoreCase(st.nextToken()))
                counter++;
        }
        return counter;
    }
}
