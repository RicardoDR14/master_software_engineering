package pt.isec.ans.ex1;
public class Example1 {
public static void main(String args[]) {
System.out.println("Java@DEIS-ISEC");
}
}