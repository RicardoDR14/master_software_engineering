package pt.isec.a2022147797.p02a02e07;

import java.util.Arrays;

public class Matriz {
    private float values[][];

    public Matriz(int nlins, int ncols) {
        values = new float[nlins][ncols];
    }

    public Matriz(Matriz other) {
        //values= other.values;
        /*
        values = new float[other.values.length][other.values[0].length];
        for (int l = 0; l < other.values.length; l++)
            for (int c = 0; c < other.values[l].length; c++)
                values[l][c] = other.values[l][c];
        */
        /*
        values = new float[other.values.length][];
        for (int l = 0; l < other.values.length; l++){
            values[l]= new float[other.values[l].length];
            System.arraycopy(other.values[l],0,values[l],0,other.values[l].length);
        }
        */
        values = new float[other.values.length][];
        for (int l = 0; l < other.values.length; l++){
            values[l] = Arrays.copyOf(other.values[l],other.values[l].length);
        }
    }

    public float get(int nl, int nc) {
        return values[nl][nc];
    }

    public boolean set(int nl, int nc, float v) {
        if (nl < 0 || nl >= values.length || nc < 0 || nc >= values[nl].length)
            return false;
        values[nl][nc] = v;
        return true;
    }

    public void show() {
        for (int l = 0; l < values.length; l++) {
            for (int c = 0; c < values[l].length; c++)
                System.out.printf("%8.2f", values[l][c]);
            System.out.println();
        }
    }

    public void gera() {
        for (int l = 0; l < values.length; l++)
            for (int c = 0; c < values[l].length; c++)
                set(l, c, (float) (Math.random() * 100));
    }

    public boolean add(Matriz other){
        if (values.length != other.values.length || values[0].length != other.values[0].length)
            return false;
        for (int l = 0; l < values.length; l++) {
            for (int c = 0; c < values[l].length; c++)
                values[l][c] += other.values[l][c];
        }
        return true;
    }

    public static Matriz add(Matriz m1, Matriz m2){
        Matriz newm = new Matriz(m1);
        if(!newm.add(m2))
            return null;
        return newm;
    }
}
