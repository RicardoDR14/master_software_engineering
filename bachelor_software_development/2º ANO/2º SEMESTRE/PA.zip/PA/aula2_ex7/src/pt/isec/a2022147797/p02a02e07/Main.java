package pt.isec.a2022147797.p02a02e07;

public class Main {
    public static void main(String[] args) {
        Matriz m1 = new Matriz(4,3);
        m1.gera();

        System.out.println("M1-----------------------");
        m1.show();

        Matriz m2 = new Matriz(m1);
        m2.set(1,1,9);
        System.out.println("M2-----------------------");
        m2.show();

        m1.add(m2);

        System.out.println("M1-----------------------");
        m1.show();

        Matriz m3 = Matriz.add(m1, m2);
        System.out.println("M3-----------------------");
        m3.show();
    }
}
