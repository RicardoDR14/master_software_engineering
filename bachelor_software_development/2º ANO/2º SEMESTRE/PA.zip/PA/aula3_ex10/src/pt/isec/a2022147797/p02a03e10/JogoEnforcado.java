package pt.isec.a2022147797.p02a03e10;

import pt.isec.a2022147797.p02a03e10.iu.JogoEnforcadoIU;
import pt.isec.a2022147797.p02a03e10.modelo.JogoEnforcadoModelo;

public class JogoEnforcado {
    public static void main(String[] args) {
        JogoEnforcadoModelo jogo = new JogoEnforcadoModelo();
        JogoEnforcadoIU jogoIU = new JogoEnforcadoIU(jogo);
        jogoIU.jogar();
    }
}
