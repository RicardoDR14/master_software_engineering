package pt.isec.a2022147797.p02a03e10.modelo;

public class JogoModeloDIcionario {
    private static final String [] palavras = {"AMANHA", "ARQUIMEDES",
            "LEAO", "TIGRE", "ZEBRA", "PLACA",
            "CASTANHO", "LARANJA", "ERVILHA", "DONINHA", "ORANGOTANGO",
            "DISCIPLINA", "PROGRAMAÇÃO", "BATATA", "PALHAÇO", "CEREBRO",
            "ATUM", "PORTUGAL", "SELVAGEM", "ANIMAL", "IRRACIONAL",
            "MATEMATICA", "DISCRETO", "EFICIENTE", "EFICAZ",
            "MARAVILHA", "SINOPSE", "DISPOSITIVO", "LINEAR", "LIMAO",
            "LAMPADA","ORELHA", "BUFALO", "SAPATO", "LAGOSTA", "ARRISCADO",
            "ARRANHADO", "CARNIVAL", "AUDAZ", "LANÇADO", "SIMPLES",
            "COMPLEXO", "GRAMPEADOR", "MONITOR", "TECLADO", "CHAVE",
            "RELOGIO", "JANELA", "CORDA", "VIOLA", "VIOLAO",
            "PONTEIRO", "ARGUIDO", "SABIO", "ERRADO", "INSTITUTO",
            "SUPERIOR", "ENGENHARIA", "DEPARTAMENTO", "INFORMATICA",
            "SISTEMA", "CHAMADA", "PRESIDENTE", "FEVEREIRO", "AUMENTO",
            "SALARIO", "DINHEIRO", "IMEDIATO", "FLAMINGO", "RINOCERONTE",
            "HIPPOPOTAMO", "BACALHAU", "PORGIE", "SARDINHA", "CARACOL",
            "INSETO", "VOADOR", "LARANJA", "ESPALHAMENTO", "EXTINTO",
            "EXTERNO","AMBIGUO"};

    private JogoModeloDIcionario(){

    }

    public static int getNrPalavra(){
        return palavras.length;
    }

    public static String getPalavra(int idx){
        if (idx<0 || idx >= palavras.length)
            return null;
        return palavras[idx];
    }
}
