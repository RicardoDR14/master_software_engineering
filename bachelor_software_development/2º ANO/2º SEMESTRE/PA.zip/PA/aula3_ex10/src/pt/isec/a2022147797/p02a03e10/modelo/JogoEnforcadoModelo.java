package pt.isec.a2022147797.p02a03e10.modelo;

public class JogoEnforcadoModelo {
    private static final int MAX_ERROS = 7;
    private static final String ESCONDIDO = ".";

    private String palavra;//palavra a sortear
    private StringBuffer situacao;//situacao atual na descoberta. EX: CASA => ....
    private StringBuilder usadas;//letras usadas até ao momento
    private int tentativas, nracertos;

    public JogoEnforcadoModelo() {
        iniciar();
    }

    private void iniciar() {
        int i = (int) (Math.random() * JogoModeloDIcionario.getNrPalavra());
        palavra = JogoModeloDIcionario.getPalavra(i).toUpperCase();
        situacao = new StringBuffer(ESCONDIDO.repeat(palavra.length()));
        usadas = new StringBuilder();
        tentativas = nracertos = 0;
    }

    public static int getMaxErros() {
        return MAX_ERROS;
    }

    public boolean concluido() {
        return acertou() || getNrErros() >= MAX_ERROS;
    }

    public String getSituacao() {
        return situacao.toString();
    }

    public int getNrTentativas() {
        return tentativas;
    }

    public int getNrErros() {
        return tentativas - nracertos;
    }

    public String getLetrasUsadas() {
        return usadas.toString();
    }

    public boolean aposta(String opcao) {
        if (concluido() || opcao.isBlank())
            return false;
        tentativas++;
        if (opcao.length() > 1) {//aposta palavra
            if (palavra.equalsIgnoreCase(opcao)) {
                situacao = new StringBuffer(palavra);
                nracertos++;
                return true;
            }
            return false;
        }
        char c = Character.toUpperCase(opcao.charAt(0));
        usadas.append(c);
        boolean flag = false;
        for (int i = 0; i < palavra.length(); i++) {
            char c_orig = palavra.charAt(i);
            if (c == c_orig) {
                situacao.setCharAt(i, c);
                flag = true;
            }
        }
        if (flag)
            nracertos++;
        return flag;
    }

    public boolean acertou() {
        return palavra.equalsIgnoreCase(situacao.toString());
    }

    public String getPalavra() {
        return concluido() ? palavra : null;
    }
}
