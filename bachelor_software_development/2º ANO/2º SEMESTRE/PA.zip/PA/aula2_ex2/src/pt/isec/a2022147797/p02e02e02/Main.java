package pt.isec.a2022147797.p02e02e02;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int min = 1, max = 100;
        int nr, nrTentativas = 0, resp;
        System.out.println("Pense num nº entre um e 100...");
        do {
            nr = (min + max) / 2;
            nrTentativas++;
            System.out.println("O número em que pensou foi o " + nr + " ?");
            System.out.println("1-ACERTOU;\n2-PENSEI NUM NÚMERO MAIOR;\n" +
                    "3-PENSEI NUM NÚMERO MAIS BAIXO;\n");
            System.out.print("Resposta: ");
            resp = sc.nextInt();
            if (resp == 2)
                min = nr + 1;
            else if (resp == 3) {
                max = nr - 1;
            }
        } while (resp != 1 && min <= max);
        if (resp == 1)
            System.out.printf("O número %d foi descoberto em %d tentativas\n", nr, nrTentativas);
        else {
            System.out.println("Mentiu-me.....");
        }
    }
}
