package pt.isec.a2022147797.p02a02e04;

public class Main {
    public static void main(String[] args) {
        Tabela tab = new Tabela();
        tab.geraNum();
        tab.listar();
        tab.mostrarQtDuplicados();
    }
}
