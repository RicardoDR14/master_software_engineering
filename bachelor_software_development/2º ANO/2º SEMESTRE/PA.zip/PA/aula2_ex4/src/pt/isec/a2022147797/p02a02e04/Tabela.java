package pt.isec.a2022147797.p02a02e04;

public class Tabela {
    private static final int TAM = 20;
    private int tab[];//= new int[TAM];
    int conta, nrTentativas;

    public Tabela() {
        tab = new int[TAM];
        conta = 0;
        nrTentativas = 0;
    }

    public boolean existe(int nr) {
        for (int i = 0; i < conta; i++) {
            if (nr == tab[i])
                return true;
        }
        return false;
    }

    public boolean adiciona(int nr) {
        nrTentativas++;
        if (existe(nr))
            return false;
        tab[conta++] = nr;
        return false;
    }

    public void geraNum() {
        conta = 0;
        nrTentativas = 0;
        while (conta < TAM) {
            int nr = (int) (Math.random() * 101);
            adiciona(nr);
        }
    }

    public void listar() {
        System.out.print("[");
        for (int i = 0;i<conta;i++) {
            if (i > 0)
                System.out.print(", ");
            System.out.print(tab[i]);
        }
        System.out.println("]\n");
    }

    public void mostrarQtDuplicados() {
        if (conta == 0)
            System.out.println("Ainda não forem gerados números\n");
        else System.out.printf("Foram gerados %d números tendo existido %d repetido(s)\n", conta, nrTentativas - conta);
    }
}
