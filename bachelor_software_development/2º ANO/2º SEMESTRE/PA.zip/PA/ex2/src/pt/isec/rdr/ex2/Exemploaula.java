package pt.isec.rdr.ex2;

public class Exemploaula {
    public static void main(String[] args) {
        System.out.println();
    }
}
