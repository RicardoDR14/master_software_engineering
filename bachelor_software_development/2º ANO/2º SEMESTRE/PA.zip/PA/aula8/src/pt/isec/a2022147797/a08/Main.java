package pt.isec.a2022147797.a08;

import pt.isec.a2022147797.a08.model.fsm.MosquitoContext;
import pt.isec.a2022147797.a08.ui.MosquitoUI;

public class Main {
    public static void main(String[] args) {
        MosquitoContext mosquito = new MosquitoContext();
        MosquitoUI ui = new MosquitoUI(mosquito);
        ui.start();
    }
}
