package pt.isec.a2022147797.a08.model.fsm;

import pt.isec.a2022147797.a08.model.data.MosquitoData;
import pt.isec.a2022147797.a08.model.fsm.state.IMosquitoState;

public class MosquitoContext {
    private MosquitoData data;
    private IMosquitoState atual;

    public MosquitoContext() {
        this.data = data;
        this.atual = MosquitoState.IN_FLIGHT.getInstance(this,data);
    }

    //package-private
    void changeState(IMosquitoState newState){
        atual=newState;
    }

    //transitions
    public void move(){atual.move();}

    public boolean crush(){return atual.crush();}

    public void bite(){atual.bite();}

    public boolean takeOff(){return atual.takeOff();}

    //getters
    public MosquitoState getState() {
        return atual.getState();
    }

    public int getNumberBites(){return data.getNumberBites();}

    public int getNumberCrushAttempts(){return data.getNumberCrushAttempts();}

    public int getNumberMoves(){return data.getNumberMoves();}

}
