package pt.isec.a2022147797.a08.model.fsm.state;

import pt.isec.a2022147797.a08.model.data.MosquitoData;
import pt.isec.a2022147797.a08.model.fsm.MosquitoContext;
import pt.isec.a2022147797.a08.model.fsm.MosquitoState;
import pt.isec.a2022147797.a08.model.fsm.MosquitoStateAdapter;

public class DeadState extends MosquitoStateAdapter {
    public DeadState(MosquitoContext context, MosquitoData data) {super(context, data);
    }

    @Override
    public MosquitoState getState() {
        return MosquitoState.DEAD;
    }
}
