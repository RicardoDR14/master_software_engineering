package pt.isec.a2022147797.a08.model.fsm.state;

import pt.isec.a2022147797.a08.model.data.MosquitoData;
import pt.isec.a2022147797.a08.model.fsm.MosquitoContext;
import pt.isec.a2022147797.a08.model.fsm.MosquitoState;
import pt.isec.a2022147797.a08.model.fsm.MosquitoStateAdapter;

public class LandedState extends MosquitoStateAdapter {
    public LandedState(MosquitoContext context, MosquitoData data) {super(context, data);}

    @Override
    public MosquitoState getState() {
        return MosquitoState.LANDED;
    }

    @Override
    public boolean takeOff() {
        boolean res = data.takeOff();
        changeState(MosquitoState.IN_FLIGHT);
        return res;
    }

    @Override
    public boolean crush() {
        boolean res = data.tryToCrush();

        if (res)
            changeState(MosquitoState.DEAD);
        else
            changeState(MosquitoState.IN_FLIGHT);
        return res;
    }
}
