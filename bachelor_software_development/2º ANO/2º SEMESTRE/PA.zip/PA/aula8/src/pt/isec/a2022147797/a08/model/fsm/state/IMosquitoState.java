package pt.isec.a2022147797.a08.model.fsm.state;

import pt.isec.a2022147797.a08.model.fsm.MosquitoState;

public interface IMosquitoState {

    MosquitoState getState();

    void move();

    boolean takeOff();

    void bite();

    boolean crush();
}
