package pt.isec.a2022147797.a08.model.fsm;

import pt.isec.a2022147797.a08.model.data.MosquitoData;
import pt.isec.a2022147797.a08.model.fsm.state.*;

public enum MosquitoState {
    IN_FLIGHT,DEAD,READY_TO_BITE,LANDED;

    public IMosquitoState getInstance(MosquitoContext context, MosquitoData data){
        return switch (this) {
            case IN_FLIGHT -> new InFlightState(context, data);
            case DEAD -> new DeadState(context, data);
            case READY_TO_BITE -> new ReadyToBiteState(context, data);
            case LANDED -> new LandedState(context, data);
        };
    }
}
