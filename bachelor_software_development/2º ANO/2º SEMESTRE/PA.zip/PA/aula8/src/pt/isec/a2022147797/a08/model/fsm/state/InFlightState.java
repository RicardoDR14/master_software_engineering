package pt.isec.a2022147797.a08.model.fsm.state;

import pt.isec.a2022147797.a08.model.data.MosquitoData;
import pt.isec.a2022147797.a08.model.fsm.MosquitoContext;
import pt.isec.a2022147797.a08.model.fsm.MosquitoState;
import pt.isec.a2022147797.a08.model.fsm.MosquitoStateAdapter;

public class InFlightState extends MosquitoStateAdapter {
    public InFlightState(MosquitoContext context, MosquitoData data) {super(context, data);
    }

    @Override
    public MosquitoState getState() {
        return MosquitoState.IN_FLIGHT;
    }

    @Override
    public boolean crush() {
        boolean res = data.tryToCrush();

        if(res)
            changeState(MosquitoState.DEAD);

        return res;
    }

    @Override
    public void move() {
        data.move();
        if (data.isOnAnimal())
            changeState(MosquitoState.READY_TO_BITE);
        else if (data.isOnObject())
            changeState(MosquitoState.LANDED);
    }
}
