package pt.isec.a2022147797.a08.model.fsm;

import pt.isec.a2022147797.a08.model.data.MosquitoData;
import pt.isec.a2022147797.a08.model.fsm.state.IMosquitoState;

public abstract class MosquitoStateAdapter implements IMosquitoState {
    protected MosquitoContext context;
    protected MosquitoData data;

    protected MosquitoStateAdapter(MosquitoContext context, MosquitoData data){
        this.context = context;
        this.data = data;
    }

    protected void changeState(MosquitoState newState){
        context.changeState(
                newState.getInstance(context,data));
    }

    @Override
    public void move() {}

    @Override
    public boolean takeOff() {
        return false;
    }

    @Override
    public void bite() {}

    @Override
    public boolean crush() {
        return false;
    }
}
