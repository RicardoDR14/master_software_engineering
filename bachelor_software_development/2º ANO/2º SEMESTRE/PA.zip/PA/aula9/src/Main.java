import model.ShoppingListManager;
import model.data.ShoppingList;
import ui.ShoppingListUI;

public class Main {
    public static void main(String[] args) {
        ShoppingListManager sl = new ShoppingListManager();
        ShoppingListUI ui = new ShoppingListUI(sl);
        ui.start();
    }
}
