package model.command;

import model.data.ShoppingList;

public class AddProdutoCommand extends AbstractCommand {
    private String name;
    private double quantity;
    private double qt_old;

    public AddProdutoCommand(ShoppingList receiver, String name, double quantity) {
        super(receiver);
        this.name = name;
        this.quantity = quantity;
        qt_old = 0;
    }
    @Override
    public boolean execute() {
        if (quantity<=0)
            return false;
        qt_old = receiver.getQuantity(name);
        if (qt_old>0){
            receiver.removeProduct(name, qt_old);
            return receiver.addProduct(name, qt_old + quantity);
        }else
            qt_old = 0;
        return receiver.addProduct(name, quantity);
    }
    @Override
    public boolean undo() {
        receiver.removeProduct(name,qt_old);
        if (qt_old>0){
            receiver.removeProduct(name,qt_old - quantity);
            return true;
        }
        return receiver.addProduct(name, quantity);
    }
}
