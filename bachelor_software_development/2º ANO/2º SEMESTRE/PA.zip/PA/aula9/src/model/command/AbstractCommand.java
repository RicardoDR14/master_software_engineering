package model.command;
import model.ShoppingListManager;
import model.data.ShoppingList;

abstract class AbstractCommand implements ICommand {
    protected ShoppingList receiver;
    protected AbstractCommand(ShoppingList receiver) {
        this.receiver = receiver;
    }
}
