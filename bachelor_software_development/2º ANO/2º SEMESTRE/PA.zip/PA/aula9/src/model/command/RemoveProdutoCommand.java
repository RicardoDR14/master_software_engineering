package model.command;
import model.data.ShoppingList;

public class RemoveProdutoCommand extends AbstractCommand {
    private String name;
    private double quantity;
    private double qt_old;

    public RemoveProdutoCommand(ShoppingList receiver, String name, double quantity) {
        super(receiver);
        this.name = name;
        this.quantity = quantity;
    }
    @Override
    public boolean execute() {
        if (quantity<=0)
            return false;
        qt_old = receiver.getQuantity(name);
        if (qt_old<quantity){
            receiver.addProduct(name, qt_old);
            return receiver.removeProduct(name, qt_old + quantity);
        }else
            qt_old = 0;
        return receiver.removeProduct(name, quantity);
    }
    @Override
    public boolean undo() {
        receiver.addProduct(name,qt_old);
        if (qt_old>0){
            receiver.addProduct(name,qt_old - quantity);
            return true;
        }
        return receiver.removeProduct(name, quantity);
    }
}
