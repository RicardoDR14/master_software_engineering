package model;

import model.command.AddProdutoCommand;
import model.command.CommandManager;
import model.command.RemoveProdutoCommand;
import model.data.ShoppingList;

public class ShoppingListManager { // Facade
    ShoppingList rc;
    CommandManager cm;
    public ShoppingListManager() {
        rc = new ShoppingList();
        cm = new CommandManager();
    }
    public boolean addProduct( String name, double quantity) {
        return cm.invokeCommand(new AddProdutoCommand(rc, name, quantity));
    }
    public boolean removeProduct( String name, double quantity) {
        return cm.invokeCommand(new RemoveProdutoCommand(rc, name, quantity));
    }
    // ...
    public boolean hasUndo() { return cm.hasUndo(); }
    public boolean undo() { return cm.undo(); }
    public boolean hasRedo() { return cm.hasRedo(); }
    public boolean redo() { return cm.redo(); }
// ...


    @Override
    public String toString() {
        return String.format(" %s : %s\n",);
    }
}
