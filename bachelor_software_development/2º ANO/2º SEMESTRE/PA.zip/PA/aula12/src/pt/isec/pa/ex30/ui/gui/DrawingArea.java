package pt.isec.pa.ex30.ui.gui;

import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.paint.Color;
import pt.isec.pa.ex30.model.DrawingManager;
import pt.isec.pa.ex30.model.data.Figure;

public class DrawingArea extends Canvas {
    DrawingManager drawing;

    public DrawingArea(DrawingManager drawing) {
        super(500,500);
        this.drawing = drawing;
        registerHandlers();
        update();
    }

    private void registerHandlers() {
        drawing.addPropertyChangeListener(DrawingManager.PROP_FIGURES, evt -> update());

        this.setOnMousePressed(mouseEvent -> {
            /*drawing.setRGB(Math.random(),Math.random(),Math.random());
            if (mouseEvent.isControlDown())
                drawing.setCurrentType(Figure.FigureType.RECTANGLE);
            else if (mouseEvent.isAltDown())
                drawing.setCurrentType(Figure.FigureType.OVAL);
            else
                drawing.setCurrentType(Figure.FigureType.LINE);*/
            drawing.createFigure(mouseEvent.getX(), mouseEvent.getY());
            //update();
        });
        this.setOnMouseDragged(mouseEvent -> {
            drawing.updateCurrentFigure(mouseEvent.getX(), mouseEvent.getY());
            //update();
        });
        this.setOnMouseReleased(mouseEvent -> {
            drawing.finishCurrentFigure(mouseEvent.getX(),mouseEvent.getY());
            //update();
        });
    }

    /*private void update() {
        GraphicsContext gc = this.getGraphicsContext2D();
        gc.setFill(Color.LIGHTYELLOW);
        gc.fillRect(0,0,getWidth(),getHeight());
        gc.strokeLine(10,10,getWidth()-10,getHeight()-10);
    }*/

    private void update() {
        GraphicsContext gc = this.getGraphicsContext2D();
        clearScreen(gc);
        for(Figure figure:drawing.getList())
            drawFigure(gc,figure);
        //ALT: drawing.getList().forEach(figure -> drawFigure(gc,figure));
        drawFigure(gc,drawing.getCurrentFigure());
    }

    private void clearScreen(GraphicsContext gc) {
        gc.setFill(Color.LIGHTYELLOW);
        gc.fillRect(0,0,getWidth(),getHeight());
    }

    private void drawFigure(GraphicsContext gc, Figure figure) {
        if (figure == null) return;
        Color color = Color.color(figure.getR(),figure.getG(),figure.getB());
        gc.setFill(color);
        gc.setLineWidth(3);
        switch (figure.getType()) {
            case LINE -> {
                gc.setStroke(color);
                gc.strokeLine( figure.getX1(), figure.getY1(),
                        figure.getX2(), figure.getY2() );
            }
            case RECTANGLE -> {
// TODO: Fill rect, then stroke the rect with darker color
                gc.fillRect(figure.getX1(), figure.getY1(), figure.getWidth(), figure.getHeight());
                gc.setStroke(color.darker());
                gc.strokeRect(figure.getX1(), figure.getY1(), figure.getWidth(), figure.getHeight());
            }
            case OVAL -> {
// TODO: Fill oval, then stroke the oval with darker color.
                gc.fillOval(figure.getX1(), figure.getY1(), figure.getWidth(), figure.getHeight());
                gc.setStroke(color.darker());
                gc.strokeOval(figure.getX1(), figure.getY1(), figure.getWidth(), figure.getHeight());
            }
        }
    }

    public void updateSize(
            double newWidth,
            double newHeight
    ) {
        setWidth(newWidth);
        setHeight(newHeight);
        update();
    }
}
