package pt.isec.a2022147797.p02a04e13.model;

import java.util.ArrayList;
import java.util.List;

public class Library implements ILibrary {

    private String name;
    private List<Book> books;

    public Library(String name) {
        this.name = name;
        this.books = new ArrayList<>();
    }

    @Override
    public String getName() {
        return name;
    }

    @Override
    public void setName(String name) {
        this.name = name;
    }

    @Override
    public int addBook(String title, List<String> authors) {
        Book book = new Book(title, authors);
        if(books.contains(book))
            return -1;
        books.add(book);
        return book.getId();
    }

    @Override
    public Book findBook(String title) throws CloneNotSupportedException {
        Book tempBook = new Book(title,List.of());
        int index = books.indexOf(tempBook);
        if (index<=0)
            return books.get(index).clone();
        return null;
    }

    @Override
    public Book findBook(int id) throws CloneNotSupportedException {
        for (Book book:books)
            if (book.getId()==id)
                return book.clone();
        return null;
    }

    @Override
    public boolean removeBook(String title) {
        return books.remove(new Book(title,List.of()));
    }

    @Override
    public boolean removeBook(int id) {
        for (Book book:books)
            if (book.getId()==id)
                return books.remove(book);
        return false;
    }

    @Override
    public String toString() {
        StringBuilder output = new StringBuilder();
        output.append(String.format("Library %s:\n",name));
        for (Book book:books)
            output.append(String.format(" - %s\n",book));
        return output.toString();
    }
}
