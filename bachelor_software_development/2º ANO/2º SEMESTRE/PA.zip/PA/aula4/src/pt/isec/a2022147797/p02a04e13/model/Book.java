package pt.isec.a2022147797.p02a04e13.model;

import java.util.ArrayList;
import java.util.List;

public class Book implements Cloneable{
    private static int counterId = 0;

    public static int getNewId() {
        return ++counterId;
    }

    private int id;
    private String title;
    private List<String> authors;

    public Book(String title, List<String> authors) {
        this.id = getNewId();
        this.title = title;
        this.authors = List.copyOf(authors);
    }

    public Book(String title, String... authors) {
        /*
        this.id = getNewId();
        this.title = title;
        this.authors = List.of(authors);
        */
        /*
        this.authors = new ArrayList<>();
        for (String author:authors) {
            this.authors.add(author);
        }
        */
        this(title, List.of(authors));
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public List<String> getAuthors() {
        return List.copyOf(authors);
    }

    public void setAuthors(List<String> authors) {
        this.authors = List.copyOf(authors);
    }


    @Override
    public String toString() {
        String strAuthors = authors.toString();
        return String.format("[%d] %s - %s\n", id, title, strAuthors.substring(1, strAuthors.length() - 1));
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;

        Book other = (Book) obj;
        return title.equals(other.title);
    }

    @Override
    public int hashCode() {
        return title != null ? title.hashCode() : 0;
    }

    @Override
    protected Book clone() throws CloneNotSupportedException {
        Book newBook = (Book) super.clone();
        //newBook.id = getNewId();
        newBook.authors = List.copyOf(authors);
        return newBook;
    }
}
