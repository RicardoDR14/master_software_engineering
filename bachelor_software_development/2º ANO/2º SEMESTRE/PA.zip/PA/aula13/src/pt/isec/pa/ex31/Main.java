package pt.isec.pa.ex31;

import javafx.application.Application;
import pt.isec.pa.ex31.ui.gui.MainJFX;

public class Main {
    public static void main(String[] args) {
        Application.launch(MainJFX.class,args);
    }
}
