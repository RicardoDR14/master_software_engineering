package pt.isec.pa.ex31.model.data;

public class Line extends Figure {
    @Override
    public FigureType getType() {
        return FigureType.LINE;
    }
}
