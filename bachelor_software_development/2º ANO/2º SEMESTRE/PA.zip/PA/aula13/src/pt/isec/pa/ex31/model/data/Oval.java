package pt.isec.pa.ex31.model.data;

public class Oval extends Rectangle {
    @Override
    public FigureType getType() {
        return FigureType.OVAL;
    }
}
