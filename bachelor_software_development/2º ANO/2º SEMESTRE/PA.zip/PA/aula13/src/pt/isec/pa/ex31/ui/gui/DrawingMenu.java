package pt.isec.pa.ex31.ui.gui;

import javafx.application.Platform;
import javafx.scene.control.Menu;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.scene.control.SeparatorMenuItem;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.stage.FileChooser;
import pt.isec.pa.ex31.model.DrawingManager;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileReader;
import java.io.PrintWriter;

public class DrawingMenu extends MenuBar {
    DrawingManager drawing;
    Menu mnFile, mnNew, mnOpen, mnExit, mnSave, mnEdit;
    MenuItem mnUndo, mnRedo;

    public DrawingMenu(DrawingManager drawing) {
        this.drawing = drawing;
        createViews();
        registerHandlers();
        update();
    }

    private void createViews() {
        mnFile = new Menu("File");
        mnNew = new Menu("_New");
        mnOpen = new Menu("_Open");
        //mnOpen.setMnemonicParsing(false);
        mnOpen.setAccelerator(
                new KeyCodeCombination(
                        KeyCode.O,
                        KeyCodeCombination.CONTROL_DOWN,
                        KeyCodeCombination.ALT_DOWN)
        );
        mnSave = new Menu("_Save");
        mnExit = new Menu("E_xit");
        mnFile.getItems().addAll(mnNew, mnOpen, mnSave, new SeparatorMenuItem(), mnExit);
        mnEdit = new Menu("Edit");
        mnUndo = new MenuItem("_Undo");
        mnRedo = new MenuItem("_Redo");
        mnEdit.getItems().addAll(mnUndo, mnRedo);

        this.getMenus().addAll(mnFile, mnEdit);
    }

    private void registerHandlers() {

        mnNew.setOnAction(e -> {
            drawing.clearAll();
        });

        mnOpen.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("File open...");
            fileChooser.setInitialDirectory(new File("."));
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Drawing (*.dat)", "*.dat"),
                    new FileChooser.ExtensionFilter("All", "*.*")
            );
            File hFile = fileChooser.showOpenDialog(this.getScene().getWindow());
            if (hFile != null) {
                //drawing.load(hFile);
            }
        });

        mnSave.setOnAction(e -> {
            FileChooser fileChooser = new FileChooser();
            fileChooser.setTitle("File save...");
            fileChooser.setInitialDirectory(new File("."));
            fileChooser.getExtensionFilters().addAll(
                    new FileChooser.ExtensionFilter("Drawing (*.dat)", "*.dat"),
                    new FileChooser.ExtensionFilter("All", "*.*")
            );
            File hFile = fileChooser.showSaveDialog(this.getScene().getWindow());
            if (hFile != null) {


//              PrintWriter pw = new PrintWriter(hFile);
//              FileReader fr = new FileReader();
//              pw.close();
                //drawing.save(hFile);
            }
        });

        mnExit.setOnAction(e -> {
            Platform.exit();
        });
    }

    private void update() {
        mnUndo.setDisable(true);
        mnRedo.setDisable(true);
    }
}
