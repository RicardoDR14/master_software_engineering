package pt.isec.a2022147797.ui.gui;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;


public class RootPane extends BorderPane {
    private String m;
    private Color background = Color.rgb(255,255,255);

    int nrGreen, nrBlue, nrOther;
    Label label;
    Button btnGreen, btnBlue, btnOther;
    TextField tfColor;

    public RootPane(String modeloDados) {
        this.m = modeloDados;
        nrBlue = nrGreen = nrOther = 0;

        createViews();
        registerHandlers();
        update();
    }

    public void createViews() {
        this.setStyle("-fx-background-color: #40a0ff");
        //this.setSpacing(10);

        label = new Label(m);
        label.setPadding(new Insets(10));
        label.setPrefWidth(Integer.MAX_VALUE);
        label.setStyle("-fx-background-color: #c0c0c0; -fx-font-size: 16; -fx-font-family: 'Courier New'");
        label.setBorder(new Border(
                new BorderStroke(Color.DARKGRAY,BorderStrokeStyle.SOLID,CornerRadii.EMPTY,new BorderWidths(3))
        ));
        /*label.setBackground(new Background(new BackgroundFill(
                background, CornerRadii.EMPTY, Insets.EMPTY
        )));
        label.setPadding(new Insets(20));*/
        this.setBottom(label);

        btnGreen = new Button("Green");
        btnGreen.setMinWidth(75);
        btnBlue = new Button("Blue");
        btnBlue.setMinWidth(75);
        btnOther = new Button("Set Color");
        btnOther.setMinWidth(75);
        tfColor = new TextField();
        tfColor.setPrefWidth(Integer.MAX_VALUE);
        tfColor.setPromptText("Color name or RGB");
        HBox hbox = new HBox();
        hbox.getChildren().addAll(btnGreen, btnBlue,tfColor,btnOther);
        hbox.setSpacing(10);
        hbox.setPadding(new Insets(10));

        this.setTop(hbox);
    }

    public void registerHandlers(){
        btnGreen.setOnAction(actionEvent ->{
            background = Color.GREEN;
            nrGreen++;
            update();
        });
        btnBlue.setOnAction(actionEvent ->{
            background = Color.BLUE;
            nrBlue++;
            update();
        });
        btnOther.setOnAction(actionEvent -> {
            nrOther++;
            String strColor = tfColor.getText();
            try {
                background = Color.valueOf(strColor);
            }catch (Exception e){
                background = Color.BLACK;
                tfColor.setStyle("-fx-control-inner-background: #ff0000;");
            }
            update();
        });
        tfColor.setOnKeyPressed(keyEvent -> {
            tfColor.setStyle("-fx-control-inner-background: #ffffff;");
            if (keyEvent.getCode() == KeyCode.ENTER)
                btnOther.fire();
        });
    }

    public void update(){
        this.setBackground(new Background(new BackgroundFill(
                background, CornerRadii.EMPTY, Insets.EMPTY
        )));
        label.setText(String.format("Green: %d \t Blue: %d \t Other: %d", nrGreen,nrBlue,nrOther));
    }
}
