package pt.isec.a2022147797;

import javafx.application.Application;
import pt.isec.a2022147797.ui.gui.MainJFX;

public class Main {
    public static void main(String[] args) {
        System.out.println("Intro JFX");
        Application.launch(MainJFX.class,args);
        System.out.println("Bye Bye!!!");
    }
}

