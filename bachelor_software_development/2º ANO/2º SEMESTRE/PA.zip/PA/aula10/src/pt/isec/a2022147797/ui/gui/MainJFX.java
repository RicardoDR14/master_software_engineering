package pt.isec.a2022147797.ui.gui;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.stage.Stage;

public class MainJFX extends Application {
    String modeloDados;

    @Override
    public void init() throws Exception {
        super.init();
        System.out.println("Estou no INIT");
        modeloDados = "Minimalist";
    }

    @Override
    public void start(Stage stage) throws Exception {
            System.out.println("Estou no start");

            //Pane root = new Pane();
            //root.setStyle("-fx-background-color: #ffffe0");
        RootPane root = new RootPane(modeloDados);
            Scene scene = new Scene(root,600,400, Color.ORANGE/*Color.rgb(240,192,64)*/);
            stage.setScene(scene);

            stage.setTitle("TIIIITUUUU");
            stage.setMaxWidth(1000);
            stage.setMaxHeight(800);
            stage.setMinWidth(300);
            stage.setMinHeight(200);
            stage.show();


            /*Stage stage2 = new Stage();
            stage2.setTitle("Famailicão");
            stage2.setResizable(false);
            stage2.show();*/
    }

    @Override
    public void stop() throws Exception {
        System.out.println("Estou em Famalicão");
        super.stop();
    }
}
