#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include "comunication.h"
#include "feed.h"
#define PIPE_NAME "pipe"


typedef struct{
    int client_to_server_fd;
    int server_to_client_fd;
}Cliente;

/*void *recebeMensagensServidor(void *arg) {
    Cliente *cliente = (Cliente *)arg;
    char menssagem[MAX_MSG_LEN];

    while (1) {
        // Ler do pipe do servidor
        sleep(1);
        int n = read(cliente->server_to_client_fd, menssagem, sizeof(menssagem) - 1);
        if (n > 0) {
            menssagem[n] = '\0'; // Null-terminar a string
            printf("\nMensagem do servidor: %s\n", menssagem);
            if(strcmp(menssagem, "Você foi removido. Obrigado por participar.") == 0){
                printf("%s\n", menssagem);
                exit(0);
            }
        } 
    }
    return NULL; 
}
*/

void *executaComandos(void *arg){
    Cliente *cliente = (Cliente *) arg;
    char comando[100];
    char mensagem_para_servidor[MAX_MSG_LEN];
    char mensagem_para_cliente[MAX_MSG_LEN];

    while(1){
        printf("\nDigite o comando > ");
        fgets(comando, sizeof(comando), stdin);

        comando[strcspn(comando, "\n")] = 0;

        if (strcmp(comando, "topics") == 0) {
            snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "topics");
            write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
        
        }  else if (strncmp(comando, "msg ", 4) == 0) {
            char topic_name[50];
            int duracao;
            char message[200];

            if (sscanf(comando + 4, "%49s %d %199[^\n]", topic_name, &duracao, message) == 3) {
                if (duracao > 0) {
                    snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "msg %s %d %s", topic_name, duracao, message);
                    write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
                } else {
                    printf("ERRO: A duração deve ser um número positivo.\n");
                    continue;
                }
            } else {
                printf("Erro: Formato incorreto. Use 'msg <topico> <duracao> <mensagem>'.\n");
                continue;
            }

        } else if (strncmp(comando, "subscribe ", 10) == 0) {
            char topic_name[50];

            if (sscanf(comando + 10, "%49s", topic_name) == 1) {
                snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "subscribe %s", topic_name);
                write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
            } else {
                printf("Erro: Formato incorreto. Use 'subscribe <topico>'.\n");
                continue;
            }

        } else if (strncmp(comando, "unsubscribe ", 12) == 0) {
            char topic_name[50];

            if (sscanf(comando + 12, "%49s", topic_name) == 1) {
                snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "unsubscribe %s", topic_name);
                write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
            } else {
                printf("Erro: Formato incorreto. Use 'unsubscribe <topico>'.\n");
                continue;
            }

        } else if (strcmp(comando, "exit") == 0) {
            printf("Desconectando...\n");
            snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "exit");
            write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
            break;
        } else {
            printf("Comando invalido.\n");
            continue;
        }

        int n = read(cliente->server_to_client_fd, mensagem_para_cliente, sizeof(mensagem_para_cliente) - 1);
        mensagem_para_cliente[n] = '\0'; 
        if(n > 0 && strcmp(mensagem_para_cliente, "Voce foi removido. Obrigado por participar.") == 0 ){
            printf("%s", mensagem_para_cliente);
            exit(0);
        }else if(n > 0 && strcmp(mensagem_para_cliente, "Desconexão confirmada. Adeus!") == 0){
            printf("%s", mensagem_para_cliente);
            exit(0);
        }else if (n > 0) {
            mensagem_para_cliente[n] = '\0'; 
            printf("\nMensagem do servidor: \n%s\n\n", mensagem_para_cliente);
        }else {
            printf("\nConexão com o servidor encerrada.\n");
            exit(0);
        }
    }
    return NULL;
}

int main(int argc, char * argv[]) {

    if(argc < 2){
        perror("Uso: /feed nome_client\n");
        exit(0);
    }


    Cliente *cliente = malloc(sizeof(Cliente));
    if (cliente == NULL) {
        perror("Erro ao alocar memória para cliente");
        exit(1);
    }

    char username[50];
    strcpy(username, argv[1]);

    int fifo_fd = open(PIPE_NAME, O_WRONLY);
    if (fifo_fd == -1) {
        perror("Erro ao abrir o FIFO para escrita");
        return 1;
    }

    char connect_message[MAX_MSG_LEN];
    snprintf(connect_message,sizeof(connect_message),"CONNECT:%s", username);
    write(fifo_fd,connect_message,strlen(connect_message)+1);
    close(fifo_fd);

    char client_to_server[200], server_to_client[200];
    snprintf(client_to_server, sizeof(client_to_server), "client_to_server_%s", username);
    snprintf(server_to_client, sizeof(server_to_client), "server_to_client_%s", username);

    sleep(1);

    while (access(client_to_server, F_OK) == -1) {
        usleep(50000);  
    }
    
    //int client_to_server_fd = open(client_to_server, O_WRONLY);
    int client_to_server_fd = open(client_to_server, O_RDWR);
    cliente->client_to_server_fd = client_to_server_fd;

    if(client_to_server_fd == -1 ){
        perror("Erro ao abrir o FIFO para escrita");
        return 1;
    }
    
    while (access(server_to_client, F_OK) == -1) {
        usleep(50000);  
    }

    //int server_to_client_fd = open(server_to_client, O_RDONLY);
    int server_to_client_fd = open(server_to_client, O_RDWR);
    cliente->server_to_client_fd = server_to_client_fd;

    if(server_to_client_fd == -1){
        perror("Erro ao abrir o FIFO para leitura");
        close(cliente->client_to_server_fd);
        return 1;
    }

    printf("Utilizador %s conectado\n",username);

    char message[MAX_MSG_LEN];

    // Criar thread para receber mensagens do servidor
    //pthread_t thread_servidor;
    //pthread_create(&thread_servidor, NULL, recebeMensagensServidor, cliente);

    // Criar thread para enviar comandos
    pthread_t thread_comandos;
    pthread_create(&thread_comandos, NULL, executaComandos, cliente);

    // Aguardar que a thread de comandos termine
    pthread_join(thread_comandos, NULL);
    //pthread_join(thread_servidor, NULL);

    close(client_to_server_fd);
    close(server_to_client_fd);

    unlink(client_to_server);
    unlink(server_to_client);

    free(cliente);

    return 0;
} 
