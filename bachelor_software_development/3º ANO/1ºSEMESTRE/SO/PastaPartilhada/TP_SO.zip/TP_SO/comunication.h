#ifndef TP_SO_COMUNICATION_H
#define TP_SO_COMUNICATION_H

/*#define PIPE_NAME "pipe"
#define MAX_MSG_LEN 300
#define MAX_TOPIC_LEN 20
#define MAX_USERNAME_LEN 20

typedef struct {
    char username[MAX_USERNAME_LEN];
    char topic[MAX_TOPIC_LEN];
    char message[MAX_MSG_LEN];
    int duration;
} Message;*/

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <pthread.h>

#define MAX_CLIENTS 10            
#define MAX_MSG_LEN 256           

// Estrutura para armazenar informação de cada cliente
/*typedef struct {
    char username;                       
    int client_to_server_fd;        
    int server_to_client_fd;        
    char client_to_server[50];      
    char server_to_client[50];      
} client_info_t;

// Estrutura que guarda todos os clientes e suas conexões
typedef struct {
    client_info_t clients[MAX_CLIENTS];  
    int num_clients;                     
    pthread_mutex_t mutex;               
} server_data_t;*/

#endif //TP_SO_COMUNICATION_H
