#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include "comunication.h"
#define PIPE_NAME "pipe"

#define MAX_CLIENTS 10            
//#define MAX_MSG_LEN 300           
#define MAX_TOPICS 20 //Numero maximo de topicos
#define MAX_TOPIC_LEN 20 //Tamanho maximo de cada topico
#define MAX_PERSISTENT_MESSAGES 5 //Numero maximo de menssagens persistentes por cada topico
#define MAX_CLIENTES 10

//Estrutura para cada mensagem
typedef struct mensagem{
    char conteudo[MAX_MSG_LEN];
    int tempo_mensagem; // tempo para expirar
}mensagem_t;

//Estrutura para cada topico
typedef struct topico{
    char nome_topico[50];
    char clientes_nomes[MAX_CLIENTES][20];
    int num_clientes;
    mensagem_t mensagens[10];
    int num_mensagens;
    int locked;
}topico_t;

// Estrutura para cada cliente
typedef struct cliente{
    char username[50];                       
    int client_to_server_fd;        
    int server_to_client_fd;        
    char client_to_server[200];      
    char server_to_client[200];    
    int desconectar;
    pthread_t thread_cliente;
} client_info_t;

//Estrutura do servidor
typedef struct server{
    client_info_t clients[MAX_CLIENTS]; 
    topico_t topicos[MAX_TOPICS]; 
    int num_clients;
    int num_topics;                     
    pthread_mutex_t mutex;    
} server_data_t;

server_data_t server_data;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER; 
    
void *handle_client(void *arg){

    client_info_t *client = (client_info_t *) arg;
    char buffer[MAX_MSG_LEN];
    char resposta[MAX_MSG_LEN];

    while(!client->desconectar){
        printf("\nCliente %s: ", client->username);
        int n = read(client->client_to_server_fd, buffer, sizeof(buffer) - 1);
        if (n > 0) {
            buffer[n] = '\0';
            
            if(strcmp(buffer, "topics")== 0){
                pthread_mutex_lock(&server_data.mutex);
                printf("%s\n", buffer);
                snprintf(resposta, sizeof(resposta), "Lista de topicos: \n");
                write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                for(int i = 0; i < MAX_TOPICS; i++){
                    snprintf(resposta, sizeof(resposta), "%s\n", server_data.topicos[i].nome_topico);
                    write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                }
            }else if(strncmp(buffer, "msg", 3) == 0){
                pthread_mutex_lock(&server_data.mutex);
                char topic_name[50];
                char message[200];
                int duracao;
                printf("%s\n", buffer);
                sscanf(buffer + 3, "%s %d %[^\n]", topic_name, &duracao, message);

                for(int i = 0; i < server_data.num_topics; i++){
                    if(strcmp(topic_name, server_data.topicos[i].nome_topico) == 0){
                        if(server_data.topicos[i].locked == 1){ // O topico está bloqueado
                            snprintf(resposta, sizeof(resposta), "O topico esta bloqueado. Aguarde um momento.");
                            write(client-> server_to_client_fd, resposta, strlen(resposta) + 1);
                        }else{
                            snprintf(resposta, sizeof(resposta), "Mensagem enviada para o topico '%s' com duracao de %d segundos.", topic_name, duracao);
                            write(client-> server_to_client_fd, resposta, strlen(resposta) + 1);
                        }
                    }
                }
                
                pthread_mutex_unlock(&server_data.mutex);       
            }else if(strncmp(buffer, "subscribe", 9) == 0){
                pthread_mutex_lock(&server_data.mutex);
                char topic[50];
                printf("%s\n", buffer);
                sscanf(buffer + 9, "%s", topic);

                int index_topico = -1;
                int ja_subscrito = 0;

                for (int i = 0; i < server_data.num_topics; i++) {
                    if (strcmp(server_data.topicos[i].nome_topico, topic) == 0) {
                        index_topico = i;
                        
                        // Verificar se o cliente já está inscrito neste tópico
                        for (int j = 0; j < server_data.topicos[i].num_clientes; j++) {
                            if (strcmp(server_data.topicos[i].clientes_nomes[j], client->username) == 0) {
                                ja_subscrito = 1;
                                break;
                            }
                        }
                        break;
                    }
                }

                // Se o cliente já está inscrito no tópico, retornar mensagem de aviso
                if (ja_subscrito) {
                    snprintf(resposta, sizeof(resposta), "Ja esta subscrito ao topico '%s'", topic);
                    write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                }
                else {
                    // Se o tópico não existe, cria-o se o limite não foi atingido
                    if (index_topico == -1 && server_data.num_topics < MAX_TOPICS) {
                        index_topico = server_data.num_topics;
                        strncpy(server_data.topicos[index_topico].nome_topico, topic, sizeof(server_data.topicos[index_topico].nome_topico) - 1);
                        server_data.topicos[index_topico].num_clientes = 0;
                        server_data.topicos[index_topico].num_mensagens = 0;
                        server_data.num_topics++;
                    }

                    // Se o tópico existe e não está cheio, inscrever o cliente
                    if (index_topico != -1 && server_data.topicos[index_topico].num_clientes < MAX_CLIENTS) {
                        topico_t *topico = &server_data.topicos[index_topico];

                        strncpy(topico->clientes_nomes[topico->num_clientes], client->username, sizeof(topico->clientes_nomes[topico->num_clientes]) - 1);
                        topico->num_clientes++;

                        snprintf(resposta, sizeof(resposta), "Subscreveu-se ao topico '%s'", topic);
                        write(client->server_to_client_fd, resposta, strlen(resposta) + 1);

                        // Enviar mensagens persistentes do tópico para o cliente
                        for (int m = 0; m < topico->num_mensagens; m++) {
                            write(client->server_to_client_fd, topico->mensagens[m].conteudo, strlen(topico->mensagens[m].conteudo) + 1);
                        }
                    } else if (index_topico != -1) {
                        snprintf(resposta, sizeof(resposta), "O topico '%s' ja esta cheio, aguarde um momento", topic);
                        write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                    } else {
                        snprintf(resposta, sizeof(resposta), "Limite maximo de topicos atingido. Nao e possível criar o topico '%s'", topic);
                        write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                    }
                }
                pthread_mutex_unlock(&server_data.mutex);
            }else if (strncmp(buffer, "unsubscribe ", 11) == 0) {
                pthread_mutex_lock(&server_data.mutex);
                char topic[50];
                printf("%s\n", buffer);
                sscanf(buffer + 11, "%s", topic);
                //Remover o cliente da lista de subscrições do tópico
                snprintf(resposta, sizeof(resposta), "Dessubscreveu-se do topico '%s'", topic);
                write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                pthread_mutex_unlock(&server_data.mutex);
            } else if (strcmp(buffer, "exit") == 0) {
                pthread_mutex_lock(&server_data.mutex);
                printf("Cliente %s desconectou-se.\n", client->username);
                snprintf(resposta, sizeof(resposta), "Desconexao confirmada. Adeus!");
                write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                client->desconectar = 1;
                pthread_mutex_unlock(&server_data.mutex);
            } else {
                snprintf(resposta, sizeof(resposta), "Comando desconhecido: %s", buffer);
                write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
            }
        }
    }

    close(client->client_to_server_fd);
    close(client->server_to_client_fd);
    unlink(client->client_to_server);
    unlink(client->server_to_client);

    pthread_mutex_lock(&server_data.mutex);
    for(int i = 0; i < server_data.num_clients; i++){
        if(strcmp(server_data.clients[i].username, client->username) == 0){
            for(int j = i; j <server_data.num_clients - 1; j++){
                server_data.clients[j] = server_data.clients[j + 1];
            }
            server_data.num_clients--;
            break;
        }
    }
    pthread_mutex_unlock(&server_data.mutex);

    pthread_exit(NULL);
    return NULL;
}

void *executaComandos(void *arg){
    server_data_t *server_data = (server_data_t *) arg;

    char comando[100];

    while(1){
        printf("\nDigite o comando > ");
        fgets(comando, sizeof(comando), stdin);
        
        comando[strcspn(comando, "\n")] = 0;

        if (strcmp(comando, "users") == 0) {
            // Comando para obter a listagem de todos os tópicos
            pthread_mutex_lock(&server_data->mutex);
            printf("\nUtilizador Ativos: \n");
            for(int i = 0; i < server_data->num_clients; i++){
                printf("Cliente %d: %s\n", i + 1, server_data->clients[i].username);
            }
            pthread_mutex_unlock(&server_data->mutex);
        } else if (strncmp(comando, "remove ", 6) == 0) { 
            pthread_mutex_lock(&server_data->mutex);
            char username[50];
            int cliente_encontrado = 0;

            sscanf(comando + 6, "%s", username); 

            for (int i = 0; i < server_data->num_clients; i++) {
                if (strcmp(server_data->clients[i].username, username) == 0) {
                    cliente_encontrado = 1;

                    // Avisar o cliente que está a ser removido
                    char resposta[200];
                    snprintf(resposta, sizeof(resposta), "Voce foi removido. Obrigado por participar.\n");
                    write(server_data->clients[i].server_to_client_fd, resposta, strlen(resposta) + 1);

                    // Fechar pipes do cliente
                    close(server_data->clients[i].client_to_server_fd);
                    close(server_data->clients[i].server_to_client_fd);

                    unlink(server_data->clients[i].client_to_server);
                    unlink(server_data->clients[i].server_to_client);
                    server_data->clients[i].desconectar = 1;

                    // Remover o cliente da lista
                    for (int j = i; j < server_data->num_clients - 1; j++) {
                        server_data->clients[j] = server_data->clients[j + 1];
                    }
                    server_data->num_clients--;

                    printf("Cliente %s removido com sucesso\n", username);
                    break; 
                }
            }

            if (cliente_encontrado) {
                char aviso[200];
                snprintf(aviso, sizeof(aviso), "O cliente %s foi removido.\n", username);
                for (int i = 0; i < server_data->num_clients; i++) {
                    write(server_data->clients[i].server_to_client_fd, aviso, strlen(aviso) + 1);
                }
            } else {
                printf("Cliente nao encontrado.\n");
            }
            pthread_mutex_unlock(&server_data->mutex);
        } else if (strcmp(comando, "topics") == 0) {
            pthread_mutex_lock(&server_data->mutex);
            printf("Lista de topics:\n");

            for(int i = 0; i < server_data->num_topics; i++){
                printf("%s\n", server_data->topicos[i].nome_topico);
            }
            pthread_mutex_unlock(&server_data->mutex);
        } else if (strncmp(comando, "show", 4) == 0) {
            char topic_name[50];
            int topic_found = 0;

            sscanf(comando + 5, "%s", topic_name);  

            pthread_mutex_lock(&server_data->mutex); 

            for (int i = 0; i < server_data->num_topics; i++) {
                if (strcmp(server_data->topicos[i].nome_topico, topic_name) == 0) {
                    topic_found = 1;
                    printf("Mensagens no topico '%s':\n", topic_name);

                    for (int j = 0; j < server_data->topicos[i].num_mensagens; j++) {
                        printf("Mensagem %d: %s\n", j + 1, server_data->topicos[i].mensagens[j].conteudo);
                    }

                    if (server_data->topicos[i].num_mensagens == 0) {
                        printf("O topico '%s' ainda nao possui mensagens.\n", topic_name);
                    }
                    break;
                }
            }

            if (!topic_found) {
                printf("Topico '%s' nao encontrado.\n", topic_name);
            }

            pthread_mutex_unlock(&server_data->mutex); 
        } else if (strncmp(comando, "lock", 4) == 0) {
            char topic_name[50];
            int topic_found = 0;

            sscanf(comando + 5, "%s", topic_name);  

            pthread_mutex_lock(&server_data->mutex); 

            for (int i = 0; i < server_data->num_topics; i++) {
                if (strcmp(server_data->topicos[i].nome_topico, topic_name) == 0) {
                    topic_found = 1;
                    server_data->topicos[i].locked = 1; // Bloquear o topico
                    printf("Topico '%s' foi bloqueado.\n", topic_name);
                    break;
                }
            }

            if (!topic_found) {
                printf("Topico '%s' nao encontrado.\n", topic_name);
            }

            pthread_mutex_unlock(&server_data->mutex); 
        } else if(strncmp(comando, "unlock", 6) == 0){
            char topic_name[50];
            int topic_found = 0;

            sscanf(comando + 7
            , "%s", topic_name);  

            pthread_mutex_lock(&server_data->mutex); 

            for (int i = 0; i < server_data->num_topics; i++) {
                if (strcmp(server_data->topicos[i].nome_topico, topic_name) == 0) {
                    topic_found = 1;
                    server_data->topicos[i].locked = 0; // Desbloquear o topico
                    printf("Topico '%s' foi desbloqueado.\n", topic_name);
                    break;
                }
            }

            if (!topic_found) {
                printf("Topico '%s' nao encontrado.\n", topic_name);
            }

            pthread_mutex_unlock(&server_data->mutex); 
        } else if(strcmp(comando, "close") == 0){
            for(int i = 0; i < server_data->num_clients; i++){
                char resposta[200];
                snprintf(resposta, sizeof(resposta), "O servidor terminou. Obrigado por participar.\n");
                write(server_data->clients[i].server_to_client_fd, resposta, strlen(resposta) + 1);

                server_data->clients[i].desconectar = 1; //Desconectar clientes
                //pthread_exit[server_data->clients[i].thread_cliente];

                close(server_data->clients[i].client_to_server_fd);
                close(server_data->clients[i].server_to_client_fd);

                unlink(server_data->clients[i].client_to_server);
                unlink(server_data->clients[i].server_to_client);
            }

            server_data->num_clients = 0; 
            pthread_mutex_unlock(&server_data->mutex);
            printf("Comando 'close' executado: servidor encerrado e clientes notificados.\n");

            exit(0);    
        } else {
            printf("Comando invalido.\n");
        }
        
    }
    return NULL;
}

int main_2() {

    server_data.num_clients = 0;
    server_data.num_topics = 0;
    for(int i = 0; i < MAX_TOPICS; i++){
        server_data.topicos->num_clientes = 0;
    }

    //Pipe global que espera por conexões dos clientes
    if(access(PIPE_NAME, F_OK) != 0){
        if (mkfifo(PIPE_NAME, 0666) == -1) {
            perror("Erro ao criar o FIFO");
            return 1;
        }
    }
    

    printf("Aguardando Clientes...\n");

    int fifo_fd = open(PIPE_NAME, O_RDONLY, O_NONBLOCK);
    if (fifo_fd == -1) {
        perror("Erro ao abrir o FIFO para leitura");
        return 1;
    }

    pthread_t thread_comandos;
    pthread_create(&thread_comandos, NULL, executaComandos, &server_data);

    char message[MAX_MSG_LEN];

    while (1) {
        int n = read(fifo_fd, message, sizeof(message) - 1);
        if (n > 0) 
            message[n] = '\0';

        if(strncmp(message, "CONNECT:", 8) == 0){
            char username[50];
            strncpy(username, message + 8, sizeof(username) - 1);  
            username[sizeof(username) - 1] = '\0';

            pthread_mutex_lock(&mutex); 
            int exists = 0;
            for (int i = 0; i < server_data.num_clients; i++) {
                if (strcmp(server_data.clients[i].username, username) == 0) {
                    exists = 1;
                    break;
                }
            }

            if(!exists && server_data.num_clients < 10){
                client_info_t new_client;
                strncpy(new_client.username, username, sizeof(new_client.username) - 1);
                new_client.desconectar = 0;

                snprintf(new_client.client_to_server, sizeof(new_client.client_to_server), "client_to_server_%s", new_client.username);
                snprintf(new_client.server_to_client, sizeof(new_client.server_to_client), "server_to_client_%s", new_client.username);

                if (mkfifo(new_client.client_to_server, 0666) == -1) {
                    perror("Erro ao criar o pipe client_to_server");
                    pthread_mutex_unlock(&mutex);
                    exit(1);
                }

                if (mkfifo(new_client.server_to_client, 0666) == -1) {
                    perror("Erro ao criar o pipe server_to_client");
                    unlink(new_client.client_to_server); 
                    pthread_mutex_unlock(&mutex);
                    exit(1);
                }

                new_client.client_to_server_fd = open(new_client.client_to_server, O_RDONLY, O_NONBLOCK);
                if (new_client.client_to_server_fd == -1) {
                    perror("Erro ao abrir pipe do cliente para leitura");
                    pthread_mutex_unlock(&mutex);
                    exit(1);
                }

                while (access(new_client.server_to_client, F_OK) == -1) {
                    usleep(50000); 
                }

                new_client.server_to_client_fd = open(new_client.server_to_client, O_WRONLY, O_NONBLOCK);
                if (new_client.server_to_client_fd == -1) {
                    perror("Erro ao abrir pipe do servidor para escrita");
                    close(new_client.client_to_server_fd);
                    pthread_mutex_unlock(&mutex);
                    exit(1);
                }

                // Adicionar o novo cliente à lista
                server_data.clients[server_data.num_clients] = new_client;
                server_data.num_clients++;
                pthread_mutex_unlock(&mutex); 

                // Criar uma nova thread para o cliente
                //pthread_t client_thread;
                //pthread_create(&new_client.thread_cliente, NULL, handle_client, &new_client);
                pthread_create(&server_data.clients[server_data.num_clients - 1].thread_cliente, NULL, handle_client, (void *)&server_data.clients[server_data.num_clients - 1]);

            }
        }     
    }

    for (int i = 0; i < server_data.num_clients; i++) {
        pthread_join(server_data.clients[i].thread_cliente, NULL);
    }

    close(fifo_fd);
    unlink(PIPE_NAME);

    return 0;
}

int main() {

    server_data.num_clients = 0;
    server_data.num_topics = 0;
    for(int i = 0; i < MAX_TOPICS; i++){
        server_data.topicos->num_clientes = 0;
    }

    //Pipe global que espera por conexões dos clientes
    if(access(PIPE_NAME, F_OK) != 0){
        if (mkfifo(PIPE_NAME, 0666) == -1) {
            perror("Erro ao criar o FIFO");
            return 1;
        }
    }
    

    printf("Aguardando Clientes...\n");

    int fifo_fd = open(PIPE_NAME, O_RDONLY, O_NONBLOCK);
    if (fifo_fd == -1) {
        perror("Erro ao abrir o FIFO para leitura");
        return 1;
    }

    pthread_t thread_comandos;
    pthread_create(&thread_comandos, NULL, executaComandos, &server_data);

    char message[MAX_MSG_LEN];

         
    while (1) {
    int n = read(fifo_fd, message, sizeof(message) - 1);
        if (n > 0) {
            message[n] = '\0';

            if (strncmp(message, "CONNECT:", 8) == 0) {
                char username[50];
                strncpy(username, message + 8, sizeof(username) - 1);
                username[sizeof(username) - 1] = '\0';

                pthread_mutex_lock(&mutex);
                if (server_data.num_clients < MAX_CLIENTS) {
                    client_info_t *new_client = malloc(sizeof(client_info_t));
                    if (new_client == NULL) {
                        perror("Erro ao alocar memória para o cliente");
                        pthread_mutex_unlock(&mutex);
                        continue;
                    }

                    strncpy(new_client->username, username, sizeof(new_client->username) - 1);
                    new_client->desconectar = 0;

                    snprintf(new_client->client_to_server, sizeof(new_client->client_to_server), "client_to_server_%s", new_client->username);
                    snprintf(new_client->server_to_client, sizeof(new_client->server_to_client), "server_to_client_%s", new_client->username);

                    if (mkfifo(new_client->client_to_server, 0666) == -1 || mkfifo(new_client->server_to_client, 0666) == -1) {
                        perror("Erro ao criar os pipes do cliente");
                        free(new_client);
                        pthread_mutex_unlock(&mutex);
                        continue;
                    }

                    //new_client->client_to_server_fd = open(new_client->client_to_server, O_RDONLY | O_NONBLOCK);
                    new_client->client_to_server_fd = open(new_client->client_to_server, O_RDWR);
                    //new_client->server_to_client_fd = open(new_client->server_to_client, O_WRONLY);
                    new_client->server_to_client_fd = open(new_client->server_to_client, O_RDWR);

                    if (new_client->client_to_server_fd == -1 || new_client->server_to_client_fd == -1) {
                        perror("Erro ao abrir os pipes do cliente");
                        close(new_client->client_to_server_fd);
                        close(new_client->server_to_client_fd);
                        free(new_client);
                        pthread_mutex_unlock(&mutex);
                        continue;
                    }

                    pthread_create(&new_client->thread_cliente, NULL, handle_client, (void *) new_client);
                    pthread_create(&server_data.clients[server_data.num_clients].thread_cliente, NULL, handle_client, (void *) new_client);
                    server_data.clients[server_data.num_clients++] = *new_client;
                }
                pthread_mutex_unlock(&mutex);
            }
        }
    }

    for (int i = 0; i < server_data.num_clients; i++) {
        pthread_join(server_data.clients[i].thread_cliente, NULL);
    }

    close(fifo_fd);
    unlink(PIPE_NAME);

    return 0;
}
