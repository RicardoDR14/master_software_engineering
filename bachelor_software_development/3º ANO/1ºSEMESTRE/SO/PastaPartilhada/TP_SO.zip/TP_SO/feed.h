#ifndef TP_SO_FEED_H
#define TP_SO_FEED_H

#include "comunication.h"

/*typedef struct{
    int client_to_server_fd;        
    int server_to_client_fd;  
} Cliente;*/

#endif  
