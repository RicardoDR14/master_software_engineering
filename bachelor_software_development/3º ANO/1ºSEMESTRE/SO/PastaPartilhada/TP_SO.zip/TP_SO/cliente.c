#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <string.h>
#include <unistd.h>
#include "comunication.h"
#include <ncurses.h>

#include "feed.h"
#define PIPE_NAME "pipe"


typedef struct{
    int client_to_server_fd;
    int server_to_client_fd;
    int continua;
    char client_to_server[100];
    char server_to_client[100];
    pthread_mutex_t mutex;
}Cliente;

// Janelas NCurses
WINDOW *win_server;
WINDOW *win_command;

void setup_windows() {
    initscr();
    cbreak();
    noecho();

    int screen_width, screen_height;
    getmaxyx(stdscr, screen_height, screen_width);

    win_server = newwin(screen_height - 4, screen_width - 2, 1, 1);
    win_command = newwin(3, screen_width - 2, screen_height - 3, 1);

    box(win_server, 0, 0);
    box(win_command, 0, 0);

    mvwprintw(win_server, 0, 1, "Mensagens do Servidor");
    mvwprintw(win_command, 1, 1, "Digite o comando > ");

    wrefresh(win_server);
    wrefresh(win_command);
}

// Função para fechar as janelas NCurses
void close_windows() {
    delwin(win_server);
    delwin(win_command);
    endwin();
}

// Função para exibir mensagens do servidor na janela
void display_message(const char *message) {
    static int current_y = 1;

    int max_y, max_x;
    getmaxyx(win_server, max_y, max_x);

    if (current_y >= max_y - 1) { // Limpa e reseta a janela ao encher
        wclear(win_server);
        box(win_server, 0, 0);
        mvwprintw(win_server, 0, 1, "Mensagens do Servidor");
        current_y = 1;
    }

    mvwprintw(win_server, current_y++, 1, "%s", message);
    wrefresh(win_server);
}

void *monitorServidor(void *arg) {
    Cliente *cliente = (Cliente *) arg;
    char mensagem_para_cliente[MAX_MSG_LEN];

    while (cliente->continua == 1) {
        int n = read(cliente->server_to_client_fd, mensagem_para_cliente, sizeof(mensagem_para_cliente) - 1);

        if (n > 0) {
            mensagem_para_cliente[n] = '\0';

            if (strcmp(mensagem_para_cliente, "Voce foi removido. Obrigado por participar.") == 0 ||
                strcmp(mensagem_para_cliente, "Desconexão confirmada. Adeus!") == 0 ||
                strcmp(mensagem_para_cliente, "O servidor terminou. Obrigado por participar.") == 0) {
                display_message(mensagem_para_cliente);
                pthread_mutex_lock(&cliente->mutex);
                cliente->continua = 0;
                pthread_mutex_unlock(&cliente->mutex);
            } else {
                display_message(mensagem_para_cliente);
            }
        } else {
            display_message("Conexão com o servidor encerrada.");
            pthread_mutex_lock(&cliente->mutex);
            cliente->continua = 0;
            pthread_mutex_unlock(&cliente->mutex);
        }
    }

    return NULL;
}

void *executaComandos(void *arg) {
    Cliente *cliente = (Cliente *) arg;
    char comando[100];
    char mensagem_para_servidor[MAX_MSG_LEN];


    while (cliente->continua == 1) {
        wclear(win_command);
        box(win_command, 0, 0);
        mvwprintw(win_command, 1, 1, "Digite o comando > ");
        wrefresh(win_command);

        echo();
        wgetnstr(win_command, comando, sizeof(comando) - 1);
        noecho();

        if (strcmp(comando, "topics") == 0) {
            snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "topics");
            write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);

        } else if (strncmp(comando, "msg ", 4) == 0) {
            char topic_name[50];
            int duracao;
            char message[200];

            if (sscanf(comando + 4, "%49s %d %199[^\n]", topic_name, &duracao, message) == 3) {
                if (duracao > 0) {
                    snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "msg %s %d %s", topic_name, duracao, message);
                    write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
                } else {
                    display_message("ERRO: A duração deve ser um número positivo.\n");
                    continue;
                }
            } else {
                display_message("Erro: Formato incorreto. Use 'msg <topico> <duracao> <mensagem>'.\n");
                continue;
            }

        } else if (strncmp(comando, "subscribe ", 10) == 0) {
            char topic_name[50];
            if (sscanf(comando + 10, "%49s", topic_name) == 1) {
                snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "subscribe %s", topic_name);
                write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
            } else {
                display_message("Erro: Formato incorreto. Use 'subscribe <topico>'.\n");
                continue;
            }

        } else if (strncmp(comando, "unsubscribe ", 12) == 0) {
            char topic_name[50];
            if (sscanf(comando + 12, "%49s", topic_name) == 1) {
                snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "unsubscribe %s", topic_name);
                write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
            } else {
                display_message("Erro: Formato incorreto. Use 'unsubscribe <topico>'.\n");
                continue;
            }

        } else if (strcmp(comando, "exit") == 0) {
            display_message("Desconectando...\n");
            sleep(2);
            snprintf(mensagem_para_servidor, sizeof(mensagem_para_servidor), "exit");
            write(cliente->client_to_server_fd, mensagem_para_servidor, strlen(mensagem_para_servidor) + 1);
            pthread_mutex_lock(&cliente->mutex);
            cliente->continua = 0;
            pthread_mutex_unlock(&cliente->mutex);
            //break;
            //close_windows();
        } else {
            display_message("Comando invalido.\n");
        }
    }

    //pthread_cancel(thread_monitor); 
    return NULL;
}

int main(int argc, char * argv[]) {

    if(argc < 2){
        perror("Uso: /feed nome_client\n");
        exit(0);
    }

    if(access(PIPE_NAME, F_OK) != 0){
        printf("O manager nao esta em execucao.\n");
        exit(0);
    }

    //Cliente *cliente = malloc(sizeof(Cliente));
    Cliente cliente;
    cliente.continua = 1;
    pthread_mutex_init(&cliente.mutex, NULL);

    char username[50];
    strcpy(username, argv[1]);

    int fifo_fd = open(PIPE_NAME, O_WRONLY);
    if (fifo_fd == -1) {
        perror("Erro ao abrir o FIFO para escrita");
        return 1;
    }

    char connect_message[MAX_MSG_LEN];
    snprintf(connect_message,sizeof(connect_message),"CONNECT:%s", username);
    write(fifo_fd,connect_message,strlen(connect_message)+1);
    close(fifo_fd);

    //char client_to_server[100], server_to_client[100];
    snprintf(cliente.client_to_server, sizeof(cliente.client_to_server), "client_to_server_%s", username);
    snprintf(cliente.server_to_client, sizeof(cliente.server_to_client), "server_to_client_%s", username);

    sleep(1);

    while (access(cliente.client_to_server, F_OK) == -1) {
        usleep(50000);  
    }
    
    int client_to_server_fd = open(cliente.client_to_server, O_WRONLY);
    //int client_to_server_fd = open(cliente.client_to_server, O_RDWR);
    cliente.client_to_server_fd = client_to_server_fd;

    if(client_to_server_fd == -1 ){
        perror("Erro ao abrir o FIFO para escrita");
        return 1;
    }
    
    while (access(cliente.server_to_client, F_OK) == -1) {
        usleep(50000);  // 50ms
    }

    //int server_to_client_fd = open(server_to_client, O_RDONLY);
    int server_to_client_fd = open(cliente.server_to_client, O_RDWR);
    cliente.server_to_client_fd = server_to_client_fd;

    if(server_to_client_fd == -1){
        perror("Erro ao abrir o FIFO para leitura");
        close(cliente.client_to_server_fd);
        return 1;
    }

    setup_windows();


    //printf("Utilizador %s conectado\n",username);

    char message_connected[MAX_MSG_LEN];
    snprintf(message_connected, sizeof(message_connected), "Utilizador %s conectado", username);
    display_message(message_connected);

    // Criar thread para receber mensagens do servidor
    pthread_t thread_servidor;
    pthread_create(&thread_servidor, NULL, monitorServidor, (void*) &cliente);

    // Criar thread para enviar comandos
    pthread_t thread_comandos;
    pthread_create(&thread_comandos, NULL, executaComandos, (void*) &cliente);

    // Aguardar que a thread de comandos termine
    pthread_join(thread_comandos, NULL);
    pthread_join(thread_servidor, NULL);

    pthread_mutex_destroy(&cliente.mutex);
    close_windows();
    
    return 0;
}

