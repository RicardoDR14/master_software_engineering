
#include <sys/types.h>
#include <sys/stat.h>
#include <stdio.h>
#include <fcntl.h>
#include <unistd.h>
#include <string.h>
#include <pthread.h>
#include <ncurses.h>
#include "comunication.h"
#define PIPE_NAME "pipe"

#define MAX_CLIENTS 10
#define MAX_TOPICS 20 //Numero maximo de topicos
#define MAX_TOPIC_LEN 20 //Tamanho maximo de cada topico
#define MAX_PERSISTENT_MESSAGES 5 //Numero maximo de menssagens persistentes por cada topico
#define MAX_CLIENTES 1
#define MAX_MSG_LEN 300

//Estrutura para cada mensagem
typedef struct mensagem{
    char conteudo[MAX_MSG_LEN];
    int tempo_mensagem; // tempo para expirar
}mensagem_t;

//Estrutura para cada topico
typedef struct topico{
    char nome_topico[50];
    char clientes_nomes[MAX_CLIENTES][20];
    int num_clientes;
    mensagem_t mensagens[10];
    int num_mensagens;
    int locked;
}topico_t;

// Estrutura para cada cliente
typedef struct cliente{
    char username[50];
    int client_to_server_fd;
    int server_to_client_fd;
    char client_to_server[256];
    char server_to_client[256];
    int desconectar;
    pthread_t thread_cliente;
} client_info_t;

//Estrutura do servidor
typedef struct server{
    client_info_t clients[MAX_CLIENTS];
    topico_t topicos[MAX_TOPICS];
    int num_clients;
    int num_topics;
    int fifo_fd;
    pthread_mutex_t mutex;
} server_data_t;

server_data_t server_data;
pthread_mutex_t mutex = PTHREAD_MUTEX_INITIALIZER;

// Janelas NCurses
WINDOW *win_received;  // Mensagens recebidas dos clientes
WINDOW *win_command;   // Entrada de comandos do servidor
WINDOW *win_server;    // Resultados dos comandos do servidor

// Função para configurar as janelas NCurses
void setup_windows() {
    initscr();
    cbreak();
    noecho();

    int screen_width, screen_height;
    getmaxyx(stdscr, screen_height, screen_width);

    // Configurar cada janela com dimensões e títulos
    win_received = newwin(10, screen_width - 2, 1, 1);
    win_server = newwin(10, screen_width - 2, 12, 1);
    win_command = newwin(3, screen_width - 2, 23, 1);

    box(win_received, 0, 0);
    box(win_server, 0, 0);
    box(win_command, 0, 0);

    mvwprintw(win_received, 0, 1, "Mensagens Recebidas dos Clientes");
    mvwprintw(win_server, 0, 1, "Respostas dos Comandos do Servidor");
    mvwprintw(win_command, 1, 1, "Digite o comando > ");

    wrefresh(win_received);
    wrefresh(win_server);
    wrefresh(win_command);
}

// Função para fechar as janelas NCurses
void close_windows() {
    delwin(win_received);
    delwin(win_command);
    delwin(win_server);
    endwin();
}

// Função para exibir mensagens dos clientes na janela win_received
void display_message(const char *message) {
    wclear(win_received);
    box(win_received, 0, 0);
    mvwprintw(win_received, 1, 1, "%s", message);
    mvwprintw(win_received, 0, 1, "Mensagens Recebidas dos Clientes");
    wrefresh(win_received);
}

// Função para exibir os resultados dos comandos do servidor na janela win_server
void display_server_output(const char *output) {
    wclear(win_server);
    box(win_server, 0, 0);
    mvwprintw(win_server, 1, 1, "%s", output);
    mvwprintw(win_server, 0, 1, "Respostas dos Comandos do Servidor");
    wrefresh(win_server);
}

// Função para gerenciar cada cliente conectado
void *handle_client(void *arg) {
    client_info_t *client = (client_info_t *) arg;
    char buffer[MAX_MSG_LEN];
    char resposta[MAX_MSG_LEN + MAX_MSG_LEN];

    // Definir a posição inicial para impressão dentro da janela
    const int start_y = 1; // Primeira linha imprimível dentro da borda
    const int start_x = 1; // Primeira coluna imprimível dentro da borda
    static int current_y = 1; // Inicialização com valor constante; será ajustado após a primeira execução

    while (!client->desconectar) {
        int n = read(client->client_to_server_fd, buffer, sizeof(buffer) - 1);

        if (n > 0) {
            buffer[n] = '\0';

            // Formatar a string com o nome do cliente e a mensagem recebida
            char formatted_message[512];
            snprintf(formatted_message, sizeof(formatted_message), "Cliente %s: %s", client->username, buffer);

            // Limpar a linha atual para evitar qualquer sobreposição de conteúdo antigo
            wmove(win_received, current_y, start_x);
            wclrtoeol(win_received);

            // Exibir a mensagem formatada na janela `win_received`
            mvwprintw(win_received, current_y, start_x, "%s", formatted_message);
            wrefresh(win_received);

            // Incrementar a linha atual para a próxima mensagem
            current_y++;

            // Verificar se atingimos o final da janela e, em caso positivo, rolar o conteúdo para cima
            int max_y, max_x;
            getmaxyx(win_received, max_y, max_x);

            if (current_y >= max_y - 1) { // Deixar uma linha de margem na parte inferior
                // Rolar a janela para cima
                //scroll(win_received);
                //current_y = max_y - 2;
                wclear(win_received);
                box(win_received, 0, 0);
                mvwprintw(win_received, 0, 1, "Mensagens Recebidas dos Clientes");

                current_y =1;
                wrefresh(win_received);
            }

            // Processar o comando recebido
            if (strcmp(buffer, "topics") == 0) {
                pthread_mutex_lock(&server_data.mutex);

                snprintf(resposta, sizeof(resposta), "Lista de topicos:\n");
                write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                for (int i = 0; i < MAX_TOPICS; i++) {
                    snprintf(resposta, sizeof(resposta), "%s\n", server_data.topicos[i].nome_topico);
                    write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                }

                pthread_mutex_unlock(&server_data.mutex);
            } else if (strncmp(buffer, "msg", 3) == 0) {
                pthread_mutex_lock(&server_data.mutex);

                char topic_name[50];
                char message[200];
                int duracao;
                sscanf(buffer + 3, "%s %d %[^\n]", topic_name, &duracao, message);

                for (int i = 0; i < server_data.num_topics; i++) {
                    if (strcmp(topic_name, server_data.topicos[i].nome_topico) == 0) {
                        if (server_data.topicos[i].locked == 1) {
                            snprintf(resposta, sizeof(resposta), "O topico esta bloqueado. Aguarde um momento.");
                            write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                        } else {
                            snprintf(resposta, sizeof(resposta), "Mensagem enviada para o topico '%s' com duracao de %d segundos.", topic_name, duracao);
                            write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                        }
                    }
                }

                pthread_mutex_unlock(&server_data.mutex);
            }  else if (strncmp(buffer, "subscribe", 9) == 0) {
                pthread_mutex_lock(&server_data.mutex);

                char topic[50];
                sscanf(buffer + 9, "%s", topic);

                int index_topico = -1;
                int ja_subscrito = 0;

                for (int i = 0; i < server_data.num_topics; i++) {
                    if (strcmp(server_data.topicos[i].nome_topico, topic) == 0) {
                        index_topico = i;

                        // Verificar se o cliente já está inscrito neste tópico
                        for (int j = 0; j < server_data.topicos[i].num_clientes; j++) {
                            if (strcmp(server_data.topicos[i].clientes_nomes[j], client->username) == 0) {
                                ja_subscrito = 1;
                                break;
                            }
                        }
                        break;
                    }
                }

                // Se o cliente já está inscrito no tópico, retornar mensagem de aviso
                if (ja_subscrito) {
                    snprintf(resposta, sizeof(resposta), "Ja esta subscrito ao topico '%s'", topic);
                    write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                }
                else {
                    // Se o tópico não existe, cria-o se o limite não foi atingido
                    if (index_topico == -1 && server_data.num_topics < MAX_TOPICS) {
                        index_topico = server_data.num_topics;
                        strncpy(server_data.topicos[index_topico].nome_topico, topic, sizeof(server_data.topicos[index_topico].nome_topico) - 1);
                        server_data.topicos[index_topico].num_clientes = 0;
                        server_data.topicos[index_topico].num_mensagens = 0;
                        server_data.num_topics++;
                    }

                    // Se o tópico existe e não está cheio, inscrever o cliente
                    if (index_topico != -1 && server_data.topicos[index_topico].num_clientes < MAX_CLIENTS) {
                        topico_t *topico = &server_data.topicos[index_topico];

                        strncpy(topico->clientes_nomes[topico->num_clientes], client->username, sizeof(topico->clientes_nomes[topico->num_clientes]) - 1);
                        topico->num_clientes++;

                        snprintf(resposta, sizeof(resposta), "Subscreveu-se ao topico '%s'", topic);
                        write(client->server_to_client_fd, resposta, strlen(resposta) + 1);

                        // Enviar mensagens persistentes do tópico para o cliente
                        for (int m = 0; m < topico->num_mensagens; m++) {
                            write(client->server_to_client_fd, topico->mensagens[m].conteudo, strlen(topico->mensagens[m].conteudo) + 1);
                        }
                    } else if (index_topico != -1) {
                        snprintf(resposta, sizeof(resposta), "O topico '%s' ja esta cheio, aguarde um momento", topic);
                        write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                    } else {
                        snprintf(resposta, sizeof(resposta), "Limite maximo de topicos atingido. Nao e possível criar o topico '%s'", topic);
                        write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                    }
                }
                pthread_mutex_unlock(&server_data.mutex);
            } else if (strncmp(buffer, "unsubscribe ", 11) == 0) {
                pthread_mutex_lock(&server_data.mutex);
                char topic[50];
                sscanf(buffer + 11, "%s", topic);

                snprintf(resposta, sizeof(resposta), "Dessubscreveu-se do topico '%s'", topic);
                write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                pthread_mutex_unlock(&server_data.mutex);
            } else if (strcmp(buffer, "exit") == 0) {
                pthread_mutex_lock(&server_data.mutex);
                snprintf(resposta, sizeof(resposta), "Cliente %s desconectou-se.", client->username);
                write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
                client->desconectar = 1;
                pthread_mutex_unlock(&server_data.mutex);
                //break;
            } else {
                snprintf(resposta, sizeof(resposta), "Comando desconhecido: %s", buffer);
                write(client->server_to_client_fd, resposta, strlen(resposta) + 1);
            }
        }
    }

    close(client->client_to_server_fd);
    close(client->server_to_client_fd);
    unlink(client->client_to_server);
    unlink(client->server_to_client);

    pthread_mutex_lock(&server_data.mutex);
    for(int i = 0; i < server_data.num_clients; i++){
        if(strcmp(server_data.clients[i].username, client->username) == 0){
            for(int j = i; j <server_data.num_clients - 1; j++){
                server_data.clients[j] = server_data.clients[j + 1];
            }
            server_data.num_clients--;
            break;
        }
    }
    pthread_mutex_unlock(&server_data.mutex);
    free(client);
    pthread_exit(NULL);
    return NULL;
}



void *executaComandos(void *arg) {
    server_data_t *server_data = (server_data_t *) arg;
    char comando[100];

    while (1) {
        wclear(win_command);
        box(win_command, 0, 0);
        mvwprintw(win_command, 1, 1, "Digite o comando > ");
        wmove(win_command, 1, 20);
        wrefresh(win_command);

        echo();
        wgetnstr(win_command, comando, sizeof(comando) - 1);
        comando[strcspn(comando, "\n")] = 0;
        noecho();

        // Processar os diferentes comandos
        if (strcmp(comando, "users") == 0) {
            pthread_mutex_lock(&server_data->mutex);
            wclear(win_server);
            box(win_server, 0, 0);
            mvwprintw(win_server, 1, 1, "Utilizadores Ativos:");
            for (int i = 0; i < server_data->num_clients; i++) {
                mvwprintw(win_server, i + 2, 1, "Cliente %d: %s", i + 1, server_data->clients[i].username);
            }
            wrefresh(win_server);
            pthread_mutex_unlock(&server_data->mutex);

        } else if (strncmp(comando, "remove ", 6) == 0) {
            pthread_mutex_lock(&server_data->mutex);
            char username[50];
            int cliente_encontrado = 0;

            sscanf(comando + 6, "%s", username);

            for (int i = 0; i < server_data->num_clients; i++) {
                if (strcmp(server_data->clients[i].username, username) == 0) {
                    cliente_encontrado = 1;

                    // Avisar o cliente que está a ser removido
                    char resposta[200];
                    snprintf(resposta, sizeof(resposta), "Voce foi removido. Obrigado por participar.\n");
                    write(server_data->clients[i].server_to_client_fd, resposta, strlen(resposta) + 1);

                    // Fechar pipes do cliente
                    close(server_data->clients[i].client_to_server_fd);
                    close(server_data->clients[i].server_to_client_fd);

                    unlink(server_data->clients[i].client_to_server);
                    unlink(server_data->clients[i].server_to_client);
                    server_data->clients[i].desconectar = 1;

                    // Remover o cliente da lista
                    for (int j = i; j < server_data->num_clients - 1; j++) {
                        server_data->clients[j] = server_data->clients[j + 1];
                    }
                    server_data->num_clients--;

                    char cliente_remov_form[512];
                    snprintf(cliente_remov_form, sizeof(cliente_remov_form),"Cliente %s removido com sucesso\n", username);
                    display_server_output(cliente_remov_form);
                    wclear(win_server);
                    wrefresh(win_server);
                    break;
                }
            }

            if (cliente_encontrado) {
                char aviso[200];
                snprintf(aviso, sizeof(aviso), "O cliente %s foi removido.\n", username);
                for (int i = 0; i < server_data->num_clients; i++) {
                    write(server_data->clients[i].server_to_client_fd, aviso, strlen(aviso) + 1);
                }
            } else {
                char cliente_nao_encontrado_form[512];
                snprintf(cliente_nao_encontrado_form, sizeof(cliente_nao_encontrado_form),"Cliente nao encontrado.\n");
                display_server_output(cliente_nao_encontrado_form);
            }
            pthread_mutex_unlock(&server_data->mutex);

        } else if (strcmp(comando, "topics") == 0) {
            pthread_mutex_lock(&server_data->mutex);
            wclear(win_server);
            box(win_server, 0, 0);
            mvwprintw(win_server, 1, 1, "Lista de topics:");


            for(int i = 0; i < server_data->num_topics; i++){
                mvwprintw(win_server, i + 2, 1, "Topico %d: %s", i + 1, server_data->topicos[i].nome_topico);
            }
            wrefresh(win_server);
            pthread_mutex_unlock(&server_data->mutex);

        } else if (strncmp(comando, "show", 4) == 0) {
            char topic_name[50];
            int topic_found = 0;

            sscanf(comando + 5, "%s", topic_name);

            pthread_mutex_lock(&server_data->mutex);

            for (int i = 0; i < server_data->num_topics; i++) {
                if (strcmp(server_data->topicos[i].nome_topico, topic_name) == 0) {
                    topic_found = 1;
                    char msg_for[1024];
                    snprintf(msg_for, sizeof(msg_for),"Mensagens no topico '%s':\n", topic_name);
                    display_server_output(msg_for);

                    for (int j = 0; j < server_data->topicos[i].num_mensagens; j++) {
                        mvwprintw(win_server, i + 2, 1, "%d: %s", i + 1,server_data->topicos[i].mensagens[j].conteudo);

                    }

                    if (server_data->topicos[i].num_mensagens == 0) {
                        char topic_sem_msg_for[1024];
                        snprintf(topic_sem_msg_for, sizeof(topic_sem_msg_for),"O topico '%s' ainda nao possui mensagens.\n", topic_name);
                        display_server_output(topic_sem_msg_for);
                    }
                    break;
                }
            }

            if (!topic_found) {
                char topic_nao_enc_for[1024];
                snprintf(topic_nao_enc_for, sizeof(topic_nao_enc_for),"Topico '%s' nao encontrado.\n", topic_name);
                display_server_output(topic_nao_enc_for);
            }

            pthread_mutex_unlock(&server_data->mutex);

        } else if (strncmp(comando, "lock", 4) == 0) {
            char topic_name[50];
            int topic_found = 0;

            sscanf(comando + 5, "%s", topic_name);

            pthread_mutex_lock(&server_data->mutex);

            for (int i = 0; i < server_data->num_topics; i++) {
                if (strcmp(server_data->topicos[i].nome_topico, topic_name) == 0) {
                    topic_found = 1;
                    server_data->topicos[i].locked = 1; // Bloquear o topico
                    char topic_bloq_form[1024];
                    snprintf(topic_bloq_form, sizeof(topic_bloq_form),"Topico '%s' foi bloqueado.\n", topic_name);
                    display_server_output(topic_bloq_form);
                    break;
                }
            }

            if (!topic_found) {
                char topic_nao_enc_for[1024];
                snprintf(topic_nao_enc_for, sizeof(topic_nao_enc_for),"Topico '%s' nao encontrado.\n", topic_name);
                display_server_output(topic_nao_enc_for);            }

            pthread_mutex_unlock(&server_data->mutex);

        } else if(strncmp(comando, "unlock", 6) == 0){
            char topic_name[50];
            int topic_found = 0;

            sscanf(comando + 7
                    , "%s", topic_name);

            pthread_mutex_lock(&server_data->mutex);

            for (int i = 0; i < server_data->num_topics; i++) {
                if (strcmp(server_data->topicos[i].nome_topico, topic_name) == 0) {
                    topic_found = 1;
                    server_data->topicos[i].locked = 0; // Desbloquear o topico
                    char topic_desbloq_form[1024];
                    snprintf(topic_desbloq_form, sizeof(topic_desbloq_form),"Topico '%s' foi desbloqueado.\n", topic_name);
                    display_server_output(topic_desbloq_form);
                    break;
                }
            }

            if (!topic_found) {
                char topic_nao_enc_for[1024];
                snprintf(topic_nao_enc_for, sizeof(topic_nao_enc_for),"Topico '%s' nao encontrado.\n", topic_name);
                display_server_output(topic_nao_enc_for);
            }

            pthread_mutex_unlock(&server_data->mutex);

        } else if(strcmp(comando, "close") == 0){
            pthread_mutex_lock(&server_data->mutex);
            for(int i = 0; i < server_data->num_clients; i++){
                char resposta[200];
                snprintf(resposta, sizeof(resposta), "O servidor terminou. Obrigado por participar.\n");
                write(server_data->clients[i].server_to_client_fd, resposta, strlen(resposta) + 1);

                server_data->clients[i].desconectar = 1; //Desconectar clientes
                //pthread_exit[server_data->clients[i].thread_cliente];

                close(server_data->clients[i].client_to_server_fd);
                close(server_data->clients[i].server_to_client_fd);

                unlink(server_data->clients[i].client_to_server);
                unlink(server_data->clients[i].server_to_client);
            }

            server_data->num_clients = 0;
            pthread_mutex_unlock(&server_data->mutex);
            char close_form[1024];
            snprintf(close_form, sizeof(close_form),"Comando 'close' executado: servidor encerrado e clientes notificados.\n");
            display_server_output(close_form);

            exit(0);
        } else {
            char cmd_inva_form[1024];
            snprintf(cmd_inva_form, sizeof(cmd_inva_form),"Comando invalido.\n");
            display_server_output(cmd_inva_form);
        }

    }
    return NULL;
}

int main() {

    server_data.num_clients = 0;
    server_data.num_topics = 0;
    pthread_mutex_init(&server_data.mutex, NULL);
    
    for(int i = 0; i < MAX_TOPICS; i++){
        server_data.topicos->num_clientes = 0;
    }

    //Pipe global que espera por conexões dos clientes
    if(access(PIPE_NAME, F_OK) != 0){
        if (mkfifo(PIPE_NAME, 0666) == -1) {
            perror("Erro ao criar o FIFO");
            return 1;
        }
    }
    
    printf("Aguardando Clientes...\n");

    setup_windows();

    int fifo_fd = open(PIPE_NAME, O_RDONLY, O_NONBLOCK);
    if (fifo_fd == -1) {
        perror("Erro ao abrir o FIFO para leitura");
        return 1;
    }

    pthread_t thread_comandos;
    pthread_create(&thread_comandos, NULL, executaComandos, &server_data);

    char message[MAX_MSG_LEN];

         
    while (1) {
    int n = read(fifo_fd, message, sizeof(message) - 1);
        if (n > 0) {
            message[n] = '\0';

            if (strncmp(message, "CONNECT:", 8) == 0) {
                char username[50];
                strncpy(username, message + 8, sizeof(username) - 1);
                username[sizeof(username) - 1] = '\0';

                pthread_mutex_lock(&server_data.mutex);
                if (server_data.num_clients < 1) {
                    client_info_t *new_client = malloc(sizeof(client_info_t));
                    if (new_client == NULL) {
                        perror("Erro ao alocar memória para o cliente");
                        pthread_mutex_unlock(&mutex);
                        continue;
                    }

                    strncpy(new_client->username, username, sizeof(new_client->username) - 1);
                    new_client->desconectar = 0;

                    snprintf(new_client->client_to_server, sizeof(new_client->client_to_server), "client_to_server_%s", new_client->username);
                    snprintf(new_client->server_to_client, sizeof(new_client->server_to_client), "server_to_client_%s", new_client->username);

                    if (mkfifo(new_client->client_to_server, 0666) == -1 || mkfifo(new_client->server_to_client, 0666) == -1) {
                        perror("Erro ao criar os pipes do cliente");
                        free(new_client);
                        pthread_mutex_unlock(&mutex);
                        continue;
                    }

                    //new_client->client_to_server_fd = open(new_client->client_to_server, O_RDONLY | O_NONBLOCK);
                    new_client->client_to_server_fd = open(new_client->client_to_server, O_RDWR);
                    //new_client->server_to_client_fd = open(new_client->server_to_client, O_WRONLY);
                    new_client->server_to_client_fd = open(new_client->server_to_client, O_RDWR);

                    if (new_client->client_to_server_fd == -1 || new_client->server_to_client_fd == -1) {
                        perror("Erro ao abrir os pipes do cliente");
                        close(new_client->client_to_server_fd);
                        close(new_client->server_to_client_fd);
                        free(new_client);
                        pthread_mutex_unlock(&mutex);
                        continue;
                    }

                    pthread_create(&new_client->thread_cliente, NULL, handle_client, (void *) new_client);
                    //pthread_create(&server_data.clients[server_data.num_clients].thread_cliente, NULL, handle_client, (void *) new_client);
                    pthread_create(&server_data.clients[server_data.num_clients].thread_cliente, NULL, handle_client, (void *) &server_data.clients[server_data.num_clients]);
                    server_data.clients[server_data.num_clients++] = *new_client;
                }
                pthread_mutex_unlock(&server_data.mutex);
            }
        }
    }

    for (int i = 0; i < server_data.num_clients; i++) {
        pthread_join(server_data.clients[i].thread_cliente, NULL);
    }

    pthread_join(thread_comandos, NULL);
    pthread_mutex_destroy(&server_data.mutex);
    close(fifo_fd);
    close_windows();
    unlink(PIPE_NAME);

    return 0;
}
