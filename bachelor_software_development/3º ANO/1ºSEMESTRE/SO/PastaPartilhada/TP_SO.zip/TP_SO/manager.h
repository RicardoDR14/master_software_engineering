#ifndef TP_SO_MANAGER_H
#define TP_SO_MANAGER_H

#include "comunication.h"


#endif //TP_SO_MANAGER_H
