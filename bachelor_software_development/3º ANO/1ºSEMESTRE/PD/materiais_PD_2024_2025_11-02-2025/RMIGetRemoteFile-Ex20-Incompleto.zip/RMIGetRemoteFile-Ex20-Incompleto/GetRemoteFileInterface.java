package pt.isec.pd.ex20;

/**
 *
 * @author Jose'
 */

public interface GetRemoteFileInterface {
    byte[] getFileChunk(String fileName, long offset);
}
