ClientGetFileTCP localhost 5001 SerraEstrela.jpg foto.jpg
pause
