package pt.isec.ans.teofragments

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

const val TAG = "TeoFragmentsAMOV"

class MyViewModel : ViewModel() {
    private var _counter = MutableLiveData(0)
    val counter : LiveData<Int>
        get() = _counter

    fun resetCounter(value : Int = 0) {
        _counter.value = value
    }
    fun incCounter() {
        _counter.value = _counter.value!! + 1
    }
}

class MainActivity : AppCompatActivity() {

    val viewModel : MyViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        Log.i(TAG, "onCreateAa: ")
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i(TAG, "onCreateAz: ")

        this.lifecycle.addObserver(object : LifecycleEventObserver {
            override fun onStateChanged(source: LifecycleOwner, event: Lifecycle.Event) {
                Log.i(TAG, "onStateChanged: ${event.targetState.name}")
            }

        })
    }

    override fun onStart() {
        Log.i(TAG, "onStartAa: ")
        super.onStart()
        Log.i(TAG, "onStartAz: ")
    }

    override fun onResume() {
        Log.i(TAG, "onResumeAa: ")
        super.onResume()
        Log.i(TAG, "onResumeAz: ")
    }

    override fun onPause() {
        Log.i(TAG, "onPauseAa: ")
        super.onPause()
        Log.i(TAG, "onPauseAz: ")
    }

    override fun onStop() {
        Log.i(TAG, "onStopAa: ")
        super.onStop()
        Log.i(TAG, "onStopAz: ")
    }

    override fun onDestroy() {
        Log.i(TAG, "onDestroyAa: ")
        super.onDestroy()
        Log.i(TAG, "onDestroyAz: ")
    }

}