package pt.isec.ans.teofragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner

class Fragment1 : Fragment() {

    private val viewModel : MyViewModel by activityViewModels()

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.i(TAG, "onAttach1: ")

        activity?.lifecycle?.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                super.onCreate(owner)
                Log.i(TAG, "onCreateA_F1_Observer: ")
            }
            override fun onStart(owner: LifecycleOwner) {
                super.onResume(owner)
                Log.i(TAG, "onStartA_F1_Observer: ")
                activity?.lifecycle?.removeObserver(this)
            }
            override fun onResume(owner: LifecycleOwner) {
                super.onResume(owner)
                Log.i(TAG, "onResumeA_F1_Observer: ")
            }
        })
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "onCreate1: ")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        Log.i(TAG, "onCreateView1: ")
        val view = inflater.inflate(R.layout.fragment_1, container, false)
        view.findViewById<Button>(R.id.btnPress).setOnClickListener {
            viewModel.incCounter()
        }
        return view
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState) //deprecated API28
        Log.i(TAG, "onActivityCreated1: ")
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart1: ")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume1: ")
    }

    override fun onPause() {
        super.onPause()
        Log.i(TAG, "onPause1: ")
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "onStop1: ")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.i(TAG, "onDestroyView1: ")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy1: ")
    }
    override fun onDetach() {
        super.onDetach()
        Log.i(TAG, "onDetach1: ")
    }
}