package pt.isec.ans.teofragments

import android.content.Context
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import pt.isec.ans.teofragments.databinding.Fragment2Binding


class Fragment2 : Fragment() {

    private lateinit var binding: Fragment2Binding

    private val viewModel : MyViewModel by activityViewModels()

    override fun onAttach(context: Context) {
        super.onAttach(context)
        Log.i(TAG, "onAttach2: ")
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Log.i(TAG, "onCreate2: ")
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        Log.i(TAG, "onCreateView2: ")
        binding = Fragment2Binding.inflate(inflater)
        viewModel.counter.observe(requireActivity()) { value ->
            binding.tvValue.text = "Value: $value"
        }
        return binding.root
    }


    @Deprecated("Deprecated in Java")
    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)
        Log.i(TAG, "onActivityCreated2: ")
    }

    override fun onStart() {
        super.onStart()
        Log.i(TAG, "onStart2: ")
    }

    override fun onResume() {
        super.onResume()
        Log.i(TAG, "onResume2: ")
    }

    override fun onPause() {
        super.onPause()
        Log.i(TAG, "onPause2: ")
    }

    override fun onStop() {
        super.onStop()
        Log.i(TAG, "onStop2: ")
    }

    override fun onDestroyView() {
        super.onDestroyView()
        Log.i(TAG, "onDestroyView2: ")
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.i(TAG, "onDestroy2: ")
    }
    override fun onDetach() {
        super.onDetach()
        Log.i(TAG, "onDetach2: ")
    }
}
