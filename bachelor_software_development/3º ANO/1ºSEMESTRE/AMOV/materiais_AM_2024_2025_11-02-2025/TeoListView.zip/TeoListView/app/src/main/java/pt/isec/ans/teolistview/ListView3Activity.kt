package pt.isec.ans.teolistview

import android.os.Bundle
import android.util.Log
import android.widget.SimpleAdapter
import androidx.appcompat.app.AppCompatActivity
import kotlinx.android.synthetic.main.activity_list_view.lvList
import kotlin.random.Random

class ListView3Activity : AppCompatActivity() {
    companion object {
        val icons = arrayOf(
            android.R.drawable.ic_menu_compass,
            android.R.drawable.ic_menu_call,
            android.R.drawable.ic_menu_camera,
        )
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.subtitle = getString(R.string.example_3)

        val countries = resources.getStringArray(R.array.countries)
        countries.sort()
        /*
        val data1 = mapOf("valor1" to 10, "valor2" to 20)
        val data2 = mapOf("valor1" to 11, "valor2" to 21)
        val data = mutableListOf(data1,data2)
        */

        val data = mutableListOf<Map<String,Any>>()

        //val i = Random.nextInt(10,20)
        for(p in countries) {
            val item = mapOf<String,Any>(
                "name" to p,
                "population" to Random.nextInt(100000,99000000),
                "image" to icons.random())
            data.add(item)
        }
        val adapter = SimpleAdapter(this,
            data,R.layout.listview_item,
            arrayOf("name","population","image"),
            intArrayOf(R.id.tv1,R.id.tv2,R.id.ivImg) )
        lvList.adapter = adapter

        lvList.setOnItemClickListener {
            parent, view, pos, id ->

            Log.i(TAG, "Item: $pos $id")

        }
    }
}