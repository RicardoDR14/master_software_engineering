package pt.isec.ans.teolistview

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import kotlinx.android.synthetic.main.activity_list_view.*
import kotlin.random.Random

class ListView4Activity : AppCompatActivity() {
    companion object {
        val icons = arrayOf(
            android.R.drawable.ic_menu_compass,
            android.R.drawable.ic_menu_call,
            android.R.drawable.ic_menu_camera,
        )
    }

    data class Country(val nome : String, var population:Int, val image : Int)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.subtitle = getString(R.string.example_4)

        val countries = resources.getStringArray(R.array.countries)
        countries.sort()
        val data = arrayListOf<Country>()
        for(p in countries) {
            val item = Country(p,
                Random.nextInt(100000,99000000),
                icons.random()
            )
            data.add(item)
        }

        val adapter = MyAdapter(data)
        lvList.adapter = adapter

        lvList.setOnItemClickListener {
            parent, view, pos, id ->
            Log.i(TAG, "Item: $pos $id")

        }
    }

    class MyAdapter(private val data : ArrayList<Country>) : BaseAdapter() {
        override fun getCount(): Int = data.size

        override fun getItem(position: Int): Any {
            return data[position]
        }

        override fun getItemId(position: Int): Long = position.toLong()+1000

        @SuppressLint("ViewHolder")
        override fun getView(
            position: Int,
            convertView: View?,
            parent: ViewGroup?
        ): View {
            val view = LayoutInflater
                .from(parent!!.context)
                .inflate(R.layout.listview_item,parent,false)
            view.findViewById<TextView>(R.id.tv1).text =
                data[position].nome
            view.findViewById<TextView>(R.id.tv2).apply {
                text = "${data[position].population}"
                if (data[position].population > 80000000) {
                    setBackgroundColor(Color.rgb(128,0,0))
                    setTextColor(Color.WHITE)

                }
                setOnClickListener {
                    data[position].population = (data[position].population * 0.5).toInt()
                    this@MyAdapter.notifyDataSetChanged()
                }
                setOnLongClickListener {
                    data[position].population = 99_000_000
                    this@MyAdapter.notifyDataSetChanged()
                    true
                }
            }
            view.findViewById<ImageView>(R.id.ivImg).setImageResource(data[position].image)
            return view
        }

    }
}