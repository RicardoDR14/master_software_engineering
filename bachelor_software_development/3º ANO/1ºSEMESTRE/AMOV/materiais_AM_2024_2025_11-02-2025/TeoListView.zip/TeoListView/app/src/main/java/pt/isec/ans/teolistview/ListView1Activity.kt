package pt.isec.ans.teolistview

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import kotlinx.android.synthetic.main.activity_list_view.*

class ListView1Activity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_list_view)

        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.subtitle = getString(R.string.example_1)

        val countries = resources.getStringArray(R.array.countries)
        countries.sort()

        val adapter = ArrayAdapter(this,
            android.R.layout.simple_list_item_1,countries)
        lvList.adapter = adapter

        lvList.setOnItemClickListener {
            parent, view, pos, id ->
            Log.i(TAG, "Item: $pos $id")
        }
    }
}