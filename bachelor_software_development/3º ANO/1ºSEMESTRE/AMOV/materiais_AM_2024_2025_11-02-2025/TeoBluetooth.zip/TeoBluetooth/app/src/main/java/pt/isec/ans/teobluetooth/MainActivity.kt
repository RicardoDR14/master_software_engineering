package pt.isec.ans.teobluetooth

import android.annotation.SuppressLint
import android.bluetooth.*
import android.os.Bundle
import android.util.Log
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import pt.isec.ans.teobluetooth.databinding.ActivityMainBinding


// P20: F4:BF:80:00:E5:88
// N9 : D4:0B:1A:17:AA:A5
// SN4: 38:94:96:F0:E7:81
// https://developer.android.com/guide/topics/connectivity/bluetooth


class MainActivity : AppCompatActivity() {
    companion object {
        private const val TAG = "MainActivityLogs"
        private const val UUID_APP = "7db0d7c9-7cfe-471c-b986-9e0351e3a9b8" // "71b12727-9c5b-4ed2-a749-cb18f9768eb9"
    }
    lateinit var binding : ActivityMainBinding

    data class DeviceUI(val device : BluetoothDevice) {
        @SuppressLint("MissingPermission")
        override fun toString(): String {
            return "${device.name} ${device.address} ${device.toString()}"
        }
    }

    private val devicesDiscovered = mutableListOf<DeviceUI>()
    private var selectedDevice : DeviceUI? = null

    @SuppressLint("SetTextI18n", "MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        Log.i(TAG, "onCreate: ")

        BluetoothBase.uuid = UUID_APP
        BluetoothBase.initBluetooth(this)
        binding.btnSetup.setOnClickListener {
            BluetoothBase.setupBluetooth(this)
        }
        binding.btnFind.setOnClickListener {
            Log.i(TAG, "onCreate: a1")
            val devices = BluetoothBase.findDevices()?.map { DeviceUI(it) } ?: return@setOnClickListener
            Log.i(TAG, "onCreate: a2")
            binding.listDevices.adapter = ArrayAdapter(this,android.R.layout.simple_list_item_1,devices)
        }
        binding.btnDiscover.setOnClickListener {
            devicesDiscovered.clear()
            BluetoothBase.startDiscovery(this, {
                val newdev = DeviceUI(it)
                devicesDiscovered.add(newdev)
                binding.listDevices.adapter = ArrayAdapter<DeviceUI>(
                    this,
                    android.R.layout.simple_list_item_1,
                    devicesDiscovered)
            })
        }
        binding.btnConnect.setOnLongClickListener {
            Log.i(TAG, "onCreate: startServer")
            BluetoothBase.startServer(false /*true*/) { _, msg ->
                runOnUiThread { binding.tvMessages.text = msg + "\n" + binding.tvMessages.text }
            }
            Toast.makeText(this,"Server started",Toast.LENGTH_LONG).show()
            true
        }
        binding.btnConnect.setOnClickListener {
            if (selectedDevice==null) return@setOnClickListener
            Log.i(TAG, "onCreate: start connection to ${selectedDevice!!.device.name}")
            BluetoothBase.startClient(selectedDevice!!.device) { _, msg ->
                runOnUiThread { binding.tvMessages.text = msg + "\n" + binding.tvMessages.text }
            }
            Toast.makeText(this,"Connection prepared: ${selectedDevice!!.device.name}",Toast.LENGTH_LONG).show()
        }
        binding.btnDisconnect.setOnLongClickListener {
            BluetoothBase.stopServer()
            Toast.makeText(this,"Server stopped",Toast.LENGTH_LONG).show()
            true
        }
        binding.btnDisconnect.setOnClickListener {
            if (selectedDevice == null) return@setOnClickListener
            BluetoothBase.closeConnection(selectedDevice!!.device)
            Toast.makeText(this,"Connection closed",Toast.LENGTH_LONG).show()
        }

        binding.listDevices.setOnItemClickListener { parent, view, position, id ->
            selectedDevice = parent.adapter.getItem(position) as DeviceUI
            Log.i(TAG, "setOnItemClickListener: $selectedDevice")
            Toast.makeText(this,"Selected: ${selectedDevice!!.device.name}",Toast.LENGTH_LONG).show()
        }

        binding.btnSend.setOnClickListener {
            if (selectedDevice == null) return@setOnClickListener
            val message = binding.edMessage.text.toString().trim()
            Log.i(TAG, "Sending \"$message\" to ${selectedDevice!!.device.name}")
            if (message.isNotBlank())
                BluetoothBase.sendMessage(selectedDevice!!.device,message)
            binding.edMessage.text.clear()
        }
    }
}


