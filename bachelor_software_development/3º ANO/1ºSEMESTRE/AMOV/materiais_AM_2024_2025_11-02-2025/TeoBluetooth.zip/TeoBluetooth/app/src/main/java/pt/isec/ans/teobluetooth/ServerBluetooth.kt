package pt.isec.ans.teobluetooth

import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager

class ServerBluetooth {
    private var bluetoothManager: BluetoothManager? = null
    private var bluetoothAdapter: BluetoothAdapter? = null

}