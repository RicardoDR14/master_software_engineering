package pt.isec.ans.teobluetooth

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.*
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.PackageManager
import android.os.Build
import android.os.Handler
import android.util.Log
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.lifecycle.Lifecycle
import java.io.IOException
import java.io.PrintStream
import java.security.InvalidParameterException
import java.util.*
import kotlin.concurrent.thread


fun interface BluetoothMessageListener {
    fun procMessage(device:BluetoothDevice, message: String?)
}

fun interface BluetoothDeviceListener {
    fun procDevice(device: BluetoothDevice)
}

object BluetoothBase {
    private const val TAG = "Bluetooth"

    private var bluetoothManager: BluetoothManager? = null
    private var bluetoothAdapter: BluetoothAdapter? = null

    private var _hasPermissions = false
    val hasPermissions get() = _hasPermissions

    private var _uuid: UUID? = UUID.randomUUID()

    var uuid: String
        get() = _uuid.toString()
        set(value) {
            _uuid = UUID.fromString(value)
        }


    var startActivityForResult: ActivityResultLauncher<Intent>? = null

    fun initBluetooth(context: AppCompatActivity) {
        if (context.lifecycle.currentState.isAtLeast(Lifecycle.State.STARTED))
            throw IllegalAccessException("Must be called earlier")

        startActivityForResult = context.registerForActivityResult(
            ActivityResultContracts.StartActivityForResult()
        ) {
            Log.i(TAG, "startActivityForResult: ${it.resultCode}")
        }

        val requiredPermissions = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            arrayOf(
                Manifest.permission.BLUETOOTH_CONNECT,
                Manifest.permission.BLUETOOTH_SCAN,
                Manifest.permission.BLUETOOTH_ADVERTISE
            )
        } else {
            arrayOf(
                Manifest.permission.BLUETOOTH,
                Manifest.permission.ACCESS_FINE_LOCATION,
                Manifest.permission.ACCESS_COARSE_LOCATION
            )
        }
        _hasPermissions = requiredPermissions.all {
            ActivityCompat.checkSelfPermission(
                context,
                it
            ) == PackageManager.PERMISSION_GRANTED
        }
        if (!_hasPermissions) {
            context.registerForActivityResult(
                ActivityResultContracts.RequestMultiplePermissions()
            ) { results ->
                _hasPermissions = results.all { true }
                Log.i(TAG, "Permissions granted? $_hasPermissions")
            }.launch(requiredPermissions)
        } else
            Log.i(TAG, "Permissions have already been granted")
    }

    fun setupBluetooth(context: AppCompatActivity): Boolean {
        if (!_hasPermissions) return false
        bluetoothManager =
            context.getSystemService(AppCompatActivity.BLUETOOTH_SERVICE) as BluetoothManager?
        bluetoothAdapter = bluetoothManager?.adapter ?: return false
        if (!bluetoothAdapter!!.isEnabled) {
            val enableBtIntent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
            startActivityForResult?.launch(enableBtIntent)
        }
        return true
    }

    @SuppressLint("MissingPermission")
    fun findDevices(): Set<BluetoothDevice>? {
        if (!_hasPermissions)
            return null

        var pairedDevices: Set<BluetoothDevice>? = bluetoothAdapter?.bondedDevices
        Log.i(TAG, "findDevices: $pairedDevices")
        pairedDevices?.forEach { device ->
            val deviceName = device.name
            val deviceHardwareAddress = device.address // MAC address
            Log.i(TAG, "findDevices:   -> $deviceName [$deviceHardwareAddress]")
        }
        return pairedDevices
    }

    private var serverThread: AcceptThread? = null

    @SuppressLint("MissingPermission")
    private class AcceptThread(val listener: BluetoothMessageListener?) : Thread() {

        private val mmServerSocket: BluetoothServerSocket? by lazy(LazyThreadSafetyMode.NONE) {
            bluetoothAdapter?.listenUsingInsecureRfcommWithServiceRecord(
                "AMovBluetoothService",
                _uuid
            )
        }

        var _exit = false
        override fun run() {
            try {
                while (!_exit) {
                    val socket: BluetoothSocket? = try {
                        mmServerSocket?.accept()
                    } catch (e: IOException) {
                        null
                    }
                    socket?.run {
                        CommunicationThread(socket, listener).start()
                    }
                }
            } catch (_:Exception) {

            }
        }

        fun cancel() {
            try {
                _exit = true
                mmServerSocket?.close()
            } catch (e: IOException) {
            }
        }
    }

    fun startServer(makeDiscoverable: Boolean = true, listener: BluetoothMessageListener?) {
        if (makeDiscoverable) {
            val discoverableIntent: Intent =
                Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE).apply {
                    putExtra(BluetoothAdapter.EXTRA_DISCOVERABLE_DURATION, 300)
                }
            startActivityForResult?.launch(discoverableIntent)
        }
        serverThread = AcceptThread(listener).apply {
            start()
        }
    }

    fun stopServer() {
        serverThread?.cancel()
    }


    private var isDiscovering = false
    private var discoverBR: BluetoothDevicesBR? = null

    @SuppressLint("MissingPermission")
    fun startDiscovery(
        context: AppCompatActivity,
        listener: BluetoothDeviceListener,
        timelimit: Long = 180000 //ms
    ) {
        if (isDiscovering) return

        discoverBR = BluetoothDevicesBR((listener))
        context.registerReceiver(discoverBR, IntentFilter(BluetoothDevice.ACTION_FOUND))
        isDiscovering = bluetoothAdapter?.startDiscovery() ?: false
        if (isDiscovering) {
            Handler(context.mainLooper).postDelayed({
                stopDiscovery(context)
                Log.i(TAG, "startDiscovery: limit reached => stop")
            }, timelimit)
        }
    }

    @SuppressLint("MissingPermission")
    fun stopDiscovery(context: AppCompatActivity) {
        if (!isDiscovering) return
        bluetoothAdapter?.cancelDiscovery()
        context.unregisterReceiver(discoverBR)
        discoverBR = null
        isDiscovering = false
    }

    @Suppress("DEPRECATION")
    private class BluetoothDevicesBR(val listener: BluetoothDeviceListener) : BroadcastReceiver() {
        @SuppressLint("MissingPermission")
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                BluetoothDevice.ACTION_FOUND -> {
                    val device: BluetoothDevice? =
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    device?.let { listener.procDevice(device) }
                    Log.i(TAG, "onReceive: ${device?.name} ${device?.address}")
                }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private class ConnectThread(
        val device: BluetoothDevice,
        val listener: BluetoothMessageListener?
    ) : Thread() {

        private val mmSocket: BluetoothSocket? by lazy(LazyThreadSafetyMode.NONE) {
            device.createRfcommSocketToServiceRecord(_uuid)
        }

        public override fun run() {
            mmSocket?.let { socket ->
                var newsocket = socket
                try {
                    newsocket.connect()
                } catch (e: Exception) {
                    Log.i(TAG, "runC: connection plan B")
                    newsocket = device.javaClass.getMethod(
                        "createRfcommSocket", *arrayOf<Class<*>?>(
                            Int::class.javaPrimitiveType
                        )
                    ).invoke(device, 1) as BluetoothSocket
                    try {newsocket.connect() } catch (_:Exception) {
                        Log.i(TAG,"Connection failed [${device.name}]")
                        return
                    }
                }
                CommunicationThread(newsocket, listener).start()
            }
        }
    }

    private var clientThread: ConnectThread? = null

    fun startClient(device: BluetoothDevice, listener: BluetoothMessageListener?) {
        clientThread = ConnectThread(device, listener).apply {
            start()
        }
    }

    private class CommunicationThread(
        val socket: BluetoothSocket,
        val listener: BluetoothMessageListener?
    ) : Thread() {
        companion object {
            val connections = HashMap<BluetoothDevice,CommunicationThread>()
        }
        private val device = socket.remoteDevice
        private val socketInput  get() = socket.inputStream
        private val socketOutput get() = socket.outputStream

        init {
            if (connections.containsKey(socket.remoteDevice))
                throw InvalidParameterException("Device already connected")
            connections[socket.remoteDevice] = this
        }

        override fun run() {
            try {
                val br = socketInput?.bufferedReader() ?: return
                listener?.procMessage(device, null)
                while (true) {
                    Log.i(TAG, "CommunicationThread: before read")
                    val message = br.readLine()
                    Log.i(TAG, "CommunicationThread: read $message")
                    thread {
                        listener?.procMessage(device, message)
                    }
                }
            } catch (e: Exception) {
                Log.i(TAG, "CommunicationThread: Exception ${e.message}")
            } finally {
                Log.i(TAG, "CommunicationThread: close")
                connections.remove(socket.remoteDevice)
                socket.close()
            }
        }

        fun sendMessage(message : String) {
            thread {
                val ps = PrintStream(socketOutput)
                ps.println(message)
                ps.flush()
            }
        }

        fun closeConnection() {
            connections.remove(socket.remoteDevice)
            socket.close()
        }
    }

    fun sendMessage(device : BluetoothDevice, message : String) {
        CommunicationThread.connections[device]?.sendMessage(message)
    }

    fun closeConnection(device : BluetoothDevice) {
        CommunicationThread.connections[device]?.closeConnection()
    }
}