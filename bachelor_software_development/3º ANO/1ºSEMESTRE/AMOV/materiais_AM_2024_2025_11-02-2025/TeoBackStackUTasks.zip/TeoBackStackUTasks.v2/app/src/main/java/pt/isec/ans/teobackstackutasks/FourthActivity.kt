package pt.isec.ans.teobackstackutasks

import android.graphics.Color


class FourthActivity : MyBaseActivity() {
    override val activityName : String by lazy { getString(R.string.activity_4) }
    override val activityBackground : Int by lazy { Color.rgb(0xd0,0xd0,0xd0) }
}