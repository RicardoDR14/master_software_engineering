package pt.isec.ans.teobackstackutasks

import android.graphics.Color

class MainActivity : MyBaseActivity() {
    override val activityName : String by lazy { getString(R.string.activity_1) }
    override val activityBackground : Int by lazy { Color.rgb(0xff,0xd0,0xd0) }
}