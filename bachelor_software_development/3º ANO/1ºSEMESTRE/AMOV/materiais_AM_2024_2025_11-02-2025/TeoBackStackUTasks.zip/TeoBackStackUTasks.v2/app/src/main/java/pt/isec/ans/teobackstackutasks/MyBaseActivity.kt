package pt.isec.ans.teobackstackutasks

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

// para ver o back stack fazer em <sdk>/platform-tools  o seguinte comando:
// ./adb shell dumpsys activity -package pt.isec.ans.teobackstackutasks | grep 'ACTIVITY'

const val TAG = "TeoBackStack"

open class MyBaseActivity : AppCompatActivity() {

    open val activityName : String by lazy { getString(R.string.activity_base) }
    open val activityBackground : Int by lazy { Color.WHITE }

    private fun Logi(msg:String) {
        Log.i(TAG, "[${android.os.Process.myPid()},${this.taskId}] ${this.localClassName}.$msg")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Logi("onCreate:")
        setContentView(R.layout.activity_base)

        findViewById<View>(R.id.llBase).setBackgroundColor(activityBackground)

        findViewById<TextView>(R.id.tvName).text = activityName

        findViewById<Button>(R.id.button1).setOnClickListener {
            startActivity(Intent(this,MainActivity::class.java))
        }
        findViewById<Button>(R.id.button2).setOnClickListener {
            startActivity(Intent(this,SecondActivity::class.java))
        }
        findViewById<Button>(R.id.button3).setOnClickListener {
            startActivity(Intent(this,ThirdActivity::class.java))
        }
        findViewById<Button>(R.id.button4).setOnClickListener {
            startActivity(Intent(this,FourthActivity::class.java))
        }
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        Logi("onNewIntent")
    }
    override fun onRestart() {
        super.onRestart()
        Logi("onRestart")
    }
    override fun onStart() {
        super.onStart()
        Logi("onStart")
    }
    override fun onResume() {
        super.onResume()
        Logi("onResume")
    }

    override fun onBackPressed() {
        super.onBackPressed()
        Logi("onBackPressed")
        //finish()
    }
    override fun onPause() {
        super.onPause()
        Logi("onPause")
    }
    override fun onStop() {
        super.onStop()
        Logi("onStop")
    }
    override fun onDestroy() {
        super.onDestroy()
        Logi("onDestroy")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Logi("onSaveInstanceState")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Logi("onRestoreInstanceState")
    }
}