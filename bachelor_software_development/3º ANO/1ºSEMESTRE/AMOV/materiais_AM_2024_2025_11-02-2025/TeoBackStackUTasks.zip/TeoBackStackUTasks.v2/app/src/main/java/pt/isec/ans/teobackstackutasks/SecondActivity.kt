package pt.isec.ans.teobackstackutasks

import android.graphics.Color


class SecondActivity : MyBaseActivity() {
    override val activityName : String by lazy { getString(R.string.activity_2) }
    override val activityBackground : Int by lazy { Color.rgb(0xd0,0xff,0xd0) }
}