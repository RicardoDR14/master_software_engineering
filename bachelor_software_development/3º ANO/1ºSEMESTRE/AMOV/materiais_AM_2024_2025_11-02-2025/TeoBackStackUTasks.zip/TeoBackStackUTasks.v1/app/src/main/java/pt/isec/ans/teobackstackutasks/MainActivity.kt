package pt.isec.ans.teobackstackutasks

import android.app.Activity
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import pt.isec.ans.teobackstackutasks.databinding.ActivityMainBinding

// para ver o back stack fazer em <sdk>/platform-tools  o seguinte comando:
// ./adb shell dumpsys activity -package pt.isec.ans.teobackstackutasks | grep 'ACTIVITY'


class MainActivity : MyBaseActivity() {
    lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button1.setOnClickListener {
            startActivity(Intent(this,MainActivity::class.java))
        }
        binding.button2.setOnClickListener {
            startActivity(Intent(this,SecondActivity::class.java))
        }
        binding.button3.setOnClickListener {
            startActivity(Intent(this,ThirdActivity::class.java))
        }
        binding.button4.setOnClickListener {
            startActivity(Intent(this,FourthActivity::class.java))
        }
    }

}