package pt.isec.ans.teobackstackutasks

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import pt.isec.ans.teobackstackutasks.databinding.ActivityMainBinding
import pt.isec.ans.teobackstackutasks.databinding.ActivityThirdBinding

class ThirdActivity : MyBaseActivity() {
    lateinit var binding : ActivityThirdBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityThirdBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.button1.setOnClickListener {
            startActivity(Intent(this,MainActivity::class.java))
        }
        binding.button2.setOnClickListener {
            startActivity(Intent(this,SecondActivity::class.java))
        }
        binding.button3.setOnClickListener {
            startActivity(Intent(this,ThirdActivity::class.java))
        }
        binding.button4.setOnClickListener {
            startActivity(Intent(this,FourthActivity::class.java))
        }

    }
}