package pt.isec.ans.teobackstackutasks

import android.content.Intent
import android.os.Bundle
import android.util.Log
import androidx.appcompat.app.AppCompatActivity

const val TAG = "TeoBackStack"
open class MyBaseActivity : AppCompatActivity() {
    private fun Logi(msg:String) {
        Log.i(TAG, "[${android.os.Process.myPid()},${this.taskId}] ${this.localClassName}.$msg")
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Logi("onCreate:")
    }

    override fun onNewIntent(intent: Intent?) {
        super.onNewIntent(intent)
        Logi("onNewIntent")
    }
    override fun onRestart() {
        super.onRestart()
        Logi("onRestart")
    }
    override fun onStart() {
        super.onStart()
        Logi("onStart")
    }
    override fun onResume() {
        super.onResume()
        Logi("onResume")
    }
    override fun onBackPressed() {
        super.onBackPressed()
        Logi("onBackPressed")
        //finish()
    }
    override fun onPause() {
        super.onPause()
        Logi("onPause")
    }
    override fun onStop() {
        super.onStop()
        Logi("onStop")
    }
    override fun onDestroy() {
        super.onDestroy()
        Logi("onDestroy")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        Logi("onSaveInstanceState")
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle) {
        super.onRestoreInstanceState(savedInstanceState)
        Logi("onRestoreInstanceState")
    }
}