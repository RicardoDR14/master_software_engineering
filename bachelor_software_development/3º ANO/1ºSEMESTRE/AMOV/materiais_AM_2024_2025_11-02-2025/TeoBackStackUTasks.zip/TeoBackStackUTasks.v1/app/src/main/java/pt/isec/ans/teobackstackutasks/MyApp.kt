package pt.isec.ans.teobackstackutasks

import android.app.Application
import android.content.res.Configuration
import android.util.Log

class MyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Log.i(TAG, "MyApp.onCreate ${Thread.currentThread().name} " +
                "pid=${android.os.Process.myPid()} " +
                "[${this.applicationInfo.name},${this.hashCode()}]")
    }

    override fun onLowMemory() {
        super.onLowMemory()
        Log.i(TAG, "MyApp.onLowMemory ${Thread.currentThread().name} pid=${android.os.Process.myPid()}")
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        Log.i(TAG, "MyApp.onTrimMemory ${android.os.Process.myPid()} pid=${android.os.Process.myPid()}")
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        Log.i(TAG, "MyApp.onConfigurationChanged ${Thread.currentThread().name} pid=${android.os.Process.myPid()}")
    }

}