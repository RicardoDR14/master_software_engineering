package pt.isec.ans.teocontentprovider

import android.content.ContentProvider
import android.content.ContentValues
import android.content.UriMatcher
import android.database.Cursor
import android.database.MatrixCursor
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException


@Suppress("LocalVariableName", "ClassName", "SpellCheckingInspection")
class MyContentProvider : ContentProvider() {
    companion object {
        const val CP_AUTHORITY = "pt.isec.ans.teocontentprovider.cp"
        const val CP_URI = "content://$CP_AUTHORITY"

        private const val DATAFILE = "data/info.json"
        private const val DIST_ALL  = 11
        private const val DIST_ID   = 12
        private const val DIST_CODE = 13
        private const val CONC_ALL  = 21
        private const val CONC_ID   = 22
        private const val CONC_CODE = 23
        private const val FREG_ALL  = 31
        private const val FREG_ID   = 32
        private const val FREG_CODE = 33
        private const val ALL_ID    = 41
        private const val ALL_CODE  = 51
        private const val DISTRITO  = 1
        private const val CONCELHO  = 2
        private const val FREGUESIA = 3
    }

    // leitura dos dados geridos pelo Content Provider
    data class data_item(val _id : Int, val type : Int, val code: String, val name: String)

    private fun loadData() : MutableList<data_item> {
        val data = mutableListOf<data_item>()
        try {
            // leitura dos dados a partir da pasta assets
            with(context?.assets?.open(DATAFILE)) {
                val array = JSONArray(String(this?.readBytes()!!))
                for (i in 0 until array.length()) {
                    val obj = array[i] as JSONObject
                    val item = data_item(i, obj["level"] as Int,
                                    obj["code"].toString(),
                                    obj["name"] as String
                    )
                    data.add(item)
                }
            }
        } catch (_: IOException) {

        }
        return data
    }

    // implementação dos métodos essenciais do Content Provider
    private val data : MutableList<data_item> by lazy { loadData() }
    private lateinit var uriMatcher: UriMatcher

    override fun onCreate(): Boolean {
        uriMatcher = UriMatcher(UriMatcher.NO_MATCH).apply {
            addURI(CP_AUTHORITY,"distrito/id/#", DIST_ID)
            addURI(CP_AUTHORITY,"distrito/*", DIST_CODE)
            addURI(CP_AUTHORITY,"distrito",DIST_ALL) //content://pt.isec.ans.teocontentprovider.cp
            addURI(CP_AUTHORITY,"concelho/id/#", CONC_ID)
            addURI(CP_AUTHORITY,"concelho/*", CONC_CODE)
            addURI(CP_AUTHORITY,"concelho", CONC_ALL)
            addURI(CP_AUTHORITY,"freguesia/id/#", FREG_ID)
            addURI(CP_AUTHORITY,"freguesia/*", FREG_CODE)
            addURI(CP_AUTHORITY,"freguesia", FREG_ALL)
            addURI(CP_AUTHORITY,"#", ALL_ID)
            addURI(CP_AUTHORITY,"*", ALL_CODE)
        }
        /*Log.i("teste", "onCreate: yes ")
        if (data!=null) {
            for (i in 0 until data!!.size) {
                val obj = data!![i] as data_item
                Log.i("teste", "onCreate: ${obj.toString()}")
            }
        }*/
        return true
    }

    override fun getType(uri: Uri): String {
        //Deveria ser usado o uriMatcher para retornar valor adequado
        return "vnd.android.cursor.dir/vnd.$CP_AUTHORITY.table"
        //só um item
        //return "vnd.android.cursor.item/vnd.$CP_AUTHORITY.id"
    }

    override fun query( // contents://pt.isec.ans.teocontentprovider.cp/distrito/1
        uri: Uri, projection: Array<String>?, selection: String?,
        selectionArgs: Array<String>?, sortOrder: String?
    ): Cursor? {
        //println("uriMatcher: ${uriMatcher.match(uri)}")
        when(uriMatcher.match(uri)) {
            DIST_ID -> { return getItemById(DISTRITO,uri.lastPathSegment?.toInt() ?: -1) }
            DIST_CODE -> { return getItem(DISTRITO,uri.lastPathSegment ?: "$$$$") }
            DIST_ALL -> { return getItemsType(DISTRITO) }
            CONC_ID -> { return getItemById(CONCELHO,uri.lastPathSegment?.toInt() ?: -1) }
            CONC_CODE -> { return getItem(CONCELHO,uri.lastPathSegment ?: "$$$$") }
            CONC_ALL -> { return getItemsType(CONCELHO) }
            FREG_ID -> { return getItemById(FREGUESIA,uri.lastPathSegment?.toInt() ?: -1) }
            FREG_CODE -> { return getItem(FREGUESIA,uri.lastPathSegment ?: "$$$$") }
            FREG_ALL -> { return getItemsType(FREGUESIA) }
            //to complete
        }
        return null
    }

    override fun delete(uri: Uri, selection: String?, selectionArgs: Array<String>?): Int {
        when(uriMatcher.match(uri)) {
            DIST_CODE -> { return deleteItem(DISTRITO,uri.lastPathSegment ?: "$$$$") }
            CONC_CODE -> { return deleteItem(CONCELHO,uri.lastPathSegment ?: "$$$$") }
            FREG_CODE -> { return deleteItem(FREGUESIA,uri.lastPathSegment ?: "$$$$") }
            DIST_ID   -> { return deleteItemById(DISTRITO,uri.lastPathSegment?.toInt() ?: -1) }
            CONC_ID   -> { return deleteItemById(CONCELHO,uri.lastPathSegment?.toInt() ?: -1) }
            FREG_ID   -> { return deleteItemById(FREGUESIA,uri.lastPathSegment?.toInt() ?: -1) }
            // only one!? ... complete
        }
        return -1
    }

    override fun insert(uri: Uri, values: ContentValues?): Uri? {
        // Uri ignored
        if (values == null)
            return null
        if (values.containsKey("type") &&
            values.containsKey("code") &&
            values.containsKey("name")
        ) {
            val type = values.getAsInteger("type")
            if (type !in 1..3)
                return null
            val code = values.getAsString("code")
            val name = values.getAsString("name")
            val _id = data.size
            data.add(data_item(_id,type,code,name))
            when (type) { // podia ser simplificado colocando um array de strings com os tipos
                DISTRITO -> return Uri.parse("$CP_URI/distrito/id/$_id")
                CONCELHO -> return Uri.parse("$CP_URI/concelho/id/$_id")
                FREGUESIA -> return Uri.parse("$CP_URI/freguesia/id/$_id")
            }
        }

        return null
    }

    override fun update(
        uri: Uri, values: ContentValues?, selection: String?,
        selectionArgs: Array<String>?
    ): Int {
        TODO("Not implemented")
    }

    // métodos para filtrar ou atuar sobre os dados

    private fun getItemsType (type : Int) : Cursor {
        val cursor = MatrixCursor(arrayOf("_id","code","name"))
        data.filter { it.type == type }.forEach {
            cursor.addRow(arrayOf(it._id,it.code,it.name))
        }
        // ****************************
        // Este sleep foi colocado para realizar experiências no contexto da aula com o Loader
         Thread.sleep(10000)
        // ****************************

        return cursor
    }
    private fun getItem(type : Int, code: String) : Cursor {
        val cursor = MatrixCursor(arrayOf("_id","code","name"))
        data.filter { it.type == type && it.code == code }.forEach {
            cursor.addRow(arrayOf(it._id,it.code,it.name))
        }
        return cursor
    }
    private fun getItemById(type : Int, id: Int) : Cursor {
        val cursor = MatrixCursor(arrayOf("_id","code","name"))
        data.filter { it.type == type && it._id == id }.forEach {
            cursor.addRow(arrayOf(it._id,it.code,it.name))
        }
        return cursor
    }
    private fun deleteItem (type : Int, code: String) : Int {
        data.filter { it.type == type && it.code == code }.forEach {
            val ret =  it._id
            data.remove(it)
            return ret // delete only one
        }
        return -1
    }
    private fun deleteItemById(type : Int, id: Int) : Int {
        data.filter { it.type == type && it._id == id }.forEach {
            val ret =  it._id
            data.remove(it)
            return ret // delete only one
        }
        return -1
    }
}