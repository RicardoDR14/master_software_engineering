package pt.isec.ans.teocontentprovider

import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log

class MainActivity : AppCompatActivity() {
    companion object {
        private const val TAG = "CP_MainActivity"
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        Log.i(TAG, "onCreate: Begin...")

        // elimina Coimbra
        var uri = Uri.parse("${MyContentProvider.CP_URI}/distrito/6")
        //var id = contentResolver.delete(uri,null, null)

        // consultar todos os distritos => O output está a ser gerado apenas para o log
        // com o código anterior o distrito de Coimbra não deverá aparecer
        uri = Uri.parse("${MyContentProvider.CP_URI}/distrito") // content://pt.isec.ans.teocontentprovider.cp/distrito
        val cursor = contentResolver.query(uri, null,null,
                null,null,null)

        cursor?.use {
            it.moveToFirst()
            Log.i(TAG,"Column Names: ${it.columnNames.toList()}")
            while (!it.isAfterLast) {
                val _id = it.getLong(0)
                val code= it.getString(1)
                val name= it.getString(2)
                Log.i("Distritos", "Distrito: [$_id/$code] $name")
                it.moveToNext()
            }
        }
    }
}