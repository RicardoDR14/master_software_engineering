package pt.isec.ans.teobackgroundtasks

import android.annotation.SuppressLint
import android.app.job.JobParameters
import android.app.job.JobService
import kotlin.concurrent.thread

@SuppressLint("SpecifyJobSchedulerIdRange")
class MyJobService : JobService() {
    override fun onStartJob(params: JobParameters?): Boolean {
        thread {
            Utils.execute("MyJobService")
        }
        return true
    }

    override fun onStopJob(params: JobParameters?): Boolean {
        return true
    }

}