package pt.isec.ans.teostorage

import android.annotation.SuppressLint
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.os.Build
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import androidx.viewpager2.widget.ViewPager2
import pt.isec.ans.teostorage.databinding.ActivityMainBinding
import pt.isec.ans.teostorage.fragments.BaseStorageFragment
import pt.isec.ans.teostorage.fragments.CacheFragment
import pt.isec.ans.teostorage.fragments.DBFragment
import pt.isec.ans.teostorage.fragments.ExternalStorageFragment
import pt.isec.ans.teostorage.fragments.FileDirsFragment
import pt.isec.ans.teostorage.fragments.InternalStorageFragment
import pt.isec.ans.teostorage.fragments.RoomDBFragment

class StorageMainActivity : AppCompatActivity(), BaseStorageFragment.Result {
    private lateinit var b : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)
        ViewCompat.setOnApplyWindowInsetsListener(b.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        val pageAdapter = StorageFragmentAdapter(this)
        b.vpStorageFragments.adapter = pageAdapter

        b.vpStorageFragments.registerOnPageChangeCallback(object: ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                super.onPageSelected(position)

                if (position == 0 || pageAdapter.itemCount < 1 )
                    b.fbLeft.hide()
                else
                    b.fbLeft.show()
                if (position >=0 && position < pageAdapter.itemCount-1)
                    b.fbRight.show()
                else
                    b.fbRight.hide()
            }
        } )

        b.fbLeft.setOnClickListener {
            if (b.vpStorageFragments.currentItem > 0)
                b.vpStorageFragments.currentItem -= 1
        }
        b.fbRight.setOnClickListener {
            if (b.vpStorageFragments.currentItem < pageAdapter.itemCount-1)
                b.vpStorageFragments.currentItem += 1
        }

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU &&
            (
                PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this,android.Manifest.permission.READ_EXTERNAL_STORAGE) ||
                PERMISSION_GRANTED != ContextCompat.checkSelfPermission(this,android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        )
            requestPermissionProcess.launch(
                arrayOf(android.Manifest.permission.READ_EXTERNAL_STORAGE,
                    android.Manifest.permission.WRITE_EXTERNAL_STORAGE)
            )
        else
            pageAdapter.unlockExtra()
    }

    private val requestPermissionProcess = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        if ( !permissions.values.contains(false))
            (b.vpStorageFragments.adapter as? StorageFragmentAdapter)?.unlockExtra()
    }


    override fun show(string: String) {
        b.textView.text = string
    }

    inner class StorageFragmentAdapter(fa : FragmentActivity) : FragmentStateAdapter(fa) {
        private val fragsBase = arrayListOf(
            InternalStorageFragment::class.java,
            CacheFragment::class.java,
            DBFragment::class.java,
            RoomDBFragment::class.java
        )
        private val fragsExt = arrayListOf(
            InternalStorageFragment::class.java,
            CacheFragment::class.java,
            ExternalStorageFragment::class.java,
            FileDirsFragment::class.java,
            DBFragment::class.java,
            RoomDBFragment::class.java
        )
        private val frags = fragsBase

        override fun getItemCount(): Int {
            return frags.size
        }

        override fun createFragment(position: Int): Fragment {
            //return frags[position].newInstance()
            return frags[position].getConstructor().newInstance()
        }

        @SuppressLint("NotifyDataSetChanged")
        fun unlockExtra() {
            frags.clear()
            frags.addAll(fragsExt)
            this.notifyDataSetChanged()
        }

    }

}