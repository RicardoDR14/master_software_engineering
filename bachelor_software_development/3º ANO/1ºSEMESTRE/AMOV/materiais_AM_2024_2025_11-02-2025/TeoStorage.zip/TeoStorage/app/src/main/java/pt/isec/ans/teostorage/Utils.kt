package pt.isec.ans.teostorage

import kotlin.random.Random

object Utils {
    private var counter = 1
    fun getRandomStr(maxLength : Int = 20) : String {
        var str = "[%03d] ".format(counter++)
        repeat (maxLength) {
            str += Random.nextInt(65,90).toChar()
        }
        return str
    }
}