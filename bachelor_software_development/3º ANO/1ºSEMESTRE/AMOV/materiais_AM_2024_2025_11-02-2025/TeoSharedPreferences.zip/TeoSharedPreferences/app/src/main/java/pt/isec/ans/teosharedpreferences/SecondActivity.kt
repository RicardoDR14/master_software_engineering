package pt.isec.ans.teosharedpreferences

import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import pt.isec.ans.teosharedpreferences.databinding.ActivitySecondBinding

class SecondActivity : AppCompatActivity() {
    private lateinit var binding : ActivitySecondBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        binding = ActivitySecondBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        with(binding) {
            tvpMinus.setOnClickListener { updatePrefs(-1) }
            tvpPlus.setOnClickListener{ updatePrefs(1) }
            tvspMinus.setOnClickListener { updateSharedPrefs(-1) }
            tvspPlus.setOnClickListener{ updateSharedPrefs(1) }
        }

        updatePrefs(0)
        updateSharedPrefs(0)
    }
    private fun updatePrefs(param : Int) {
        val prefs = getPreferences(MODE_PRIVATE)
        val value = prefs.getInt("value",0) + param
        with(prefs.edit()) {
            putInt("value",value)
            apply()
        }
        binding.tvpValue.text = "$value"
    }
    private fun updateSharedPrefs(param : Int) {
        val sharedPrefs = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE)
        val value = sharedPrefs.getInt("value",0) + param
        with(sharedPrefs.edit()) {
            putInt("value",value)
            apply()
        }
        binding.tvspValue.text = "$value"
    }
}