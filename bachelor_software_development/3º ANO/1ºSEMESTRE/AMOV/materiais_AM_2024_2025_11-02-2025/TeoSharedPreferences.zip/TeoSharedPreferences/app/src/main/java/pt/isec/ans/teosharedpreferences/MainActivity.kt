package pt.isec.ans.teosharedpreferences

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.preference.PreferenceManager
import pt.isec.ans.teosharedpreferences.databinding.ActivityMainBinding

const val SHARED_PREFS = "MySharedPreferences"

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }
        with(binding) {
            tvpMinus.setOnClickListener { updatePrefs(-1) }
            tvpPlus.setOnClickListener{ updatePrefs(1) }
            tvspMinus.setOnClickListener { updateSharedPrefs(-1) }
            tvspPlus.setOnClickListener{ updateSharedPrefs(1) }
        }
    }

    override fun onResume() {
        super.onResume()
        updatePrefs(0)
        updateSharedPrefs(0)
    }

    private fun updatePrefs(param : Int) {
        val prefs = getPreferences(MODE_PRIVATE)
        val value = prefs.getInt("value",0) + param
        with(prefs.edit()) {
            putInt("value",value)
            apply()
        }
        binding.tvpValue.text = "$value"
    }
    private fun updateSharedPrefs(param : Int) {
        val sharedPrefs = getSharedPreferences(SHARED_PREFS,MODE_PRIVATE)
        val value = sharedPrefs.getInt("value",0) + param
        with(sharedPrefs.edit()) {
            putInt("value",value)
            apply()
        }
        binding.tvspValue.text = "$value"
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_prefs,menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menuNext -> {
                startActivity(Intent(this,SecondActivity::class.java))
                return true
            }
            R.id.menuSettings -> {
                settingsActivityResult.launch(
                    Intent(this,SettingsActivity::class.java)
                )
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private val settingsActivityResult = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) {
            val sharedPrefs = PreferenceManager.getDefaultSharedPreferences(this)
            for( (k,v) in sharedPrefs.all)
                Log.i("Settings", "$k = $v")

            /*sharedPrefs.all.forEach {
                val (k,v) = it
                    ...
            }*/
    }


}

