package pt.isec.ans.androidclientforamovserver

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import pt.isec.ans.androidclientforamovserver.ui.screens.MainScreen
import pt.isec.ans.androidclientforamovserver.ui.theme.AndroidClientForAMovServerTheme
import pt.isec.ans.androidclientforamovserver.ui.theme.IconBackground
import pt.isec.ans.androidclientforamovserver.ui.theme.IconForeground
import pt.isec.ans.androidclientforamovserver.ui.theme.TextColor

class MainActivity : ComponentActivity() {
    @OptIn(ExperimentalMaterial3Api::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            AndroidClientForAMovServerTheme {
                Scaffold(
                    topBar = {
                        TopAppBar(
                            title = { Text(stringResource(R.string.app_full_name)) },
                            colors = TopAppBarDefaults.topAppBarColors(
                                containerColor = IconBackground,
                                titleContentColor = TextColor,
                            )
                        )
                    },
                    modifier = Modifier.fillMaxSize()
                ) { innerPadding ->
                    MainScreen(
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
    }
}

