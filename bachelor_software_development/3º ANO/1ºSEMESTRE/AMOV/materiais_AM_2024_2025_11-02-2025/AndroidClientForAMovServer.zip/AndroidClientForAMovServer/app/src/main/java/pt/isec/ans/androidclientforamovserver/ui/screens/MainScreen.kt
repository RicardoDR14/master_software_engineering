package pt.isec.ans.androidclientforamovserver.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.bumptech.glide.integration.compose.ExperimentalGlideComposeApi
import com.bumptech.glide.integration.compose.GlideImage
import pt.isec.ans.androidclientforamovserver.R
import pt.isec.ans.androidclientforamovserver.ui.theme.IconBackground
import pt.isec.ans.androidclientforamovserver.ui.theme.IconForeground
import pt.isec.ans.androidclientforamovserver.ui.theme.TextColor
import pt.isec.ans.androidclientforamovserver.utils.AMovServer

@OptIn(ExperimentalGlideComposeApi::class)
@Composable
fun MainScreen(modifier: Modifier = Modifier) {
    val context = LocalContext.current
    var error by remember { mutableStateOf<String?>(null) }
    var imageUrl by remember { mutableStateOf<String?>(null) }

    val pickPicture = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia(),
        onResult = { uri ->
            if (uri != null) {
                AMovServer.asyncUploadImage(
                    inputStream = context.contentResolver.openInputStream(uri)!!,
                    extension = "jpg",
                    onResult = { result ->
                        if (result != null) {
                            imageUrl = result
                            error = null
                        } else {
                            error = context.getString(R.string.error_uploading_image)
                            imageUrl = null
                        }
                    }
                )
            }
        }
    )


    Column(
        modifier = modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        if (error != null) {
            Text(text = "Error: $error")
            Spacer(modifier = Modifier.height(16.dp))
        }
        Button(
            onClick = {
                AMovServer.asyncUploadImage(
                    inputStream = context.assets.open("panda.jpg"),
                    extension = "jpg",
                    onResult = { result ->
                        if (result != null) {
                            imageUrl = result
                            error = null
                        } else {
                            error = context.getString(R.string.error_uploading_image)
                            imageUrl = null
                        }
                    }
                )
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = IconForeground,
                contentColor = TextColor
            )
        ) {
            Text(
                text = stringResource(R.string.image_from_assets)
            )
        }
        Button(
            onClick = {
                pickPicture.launch(
                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                )
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = IconForeground,
                contentColor = TextColor
            )
        ) {
            Text(
                text = stringResource(R.string.image_from_gallery)
            )
        }
        Button(
            enabled = imageUrl != null,
            onClick = {
                imageUrl?.let { url ->
                    val trimmedUrl = url.trimEnd('/')
                    val segments = trimmedUrl.split("/")
                    val filename = segments.lastOrNull() ?: ""
                    AMovServer.asyncDeleteFileFromServer(
                        fileName = filename,
                        serverUrl = trimmedUrl,
                        onResult = { result ->
                            if (result) {
                                error = null
                                imageUrl = null
                            } else {
                                error = context.getString(R.string.error_deleting_image)
                            }
                        }
                    )
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = IconForeground,
                contentColor = TextColor
            )
        ) {
            Text(
                text = stringResource(R.string.delete_image)
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        imageUrl?.let {
            GlideImage(
                model = it,
                contentDescription = stringResource(R.string.image),
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .padding(16.dp)
                    .clip(RoundedCornerShape(10.dp)),
            )
        }

    }
}