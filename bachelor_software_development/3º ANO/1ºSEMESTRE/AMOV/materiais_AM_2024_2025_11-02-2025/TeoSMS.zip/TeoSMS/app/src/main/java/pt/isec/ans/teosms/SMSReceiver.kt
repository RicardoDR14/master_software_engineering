package pt.isec.ans.teosms

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.Telephony
import android.telephony.SmsManager
import android.util.Log
import android.widget.Toast

class SMSReceiver : BroadcastReceiver() {
    companion object {
        private const val TAG = "SMSReceiver"
        private const val SEARCH = "ISEC"
        private const val ANSWER = "Thanks"
    }
    override fun onReceive(context: Context, intent: Intent) {
        Toast.makeText(context, "$TAG: SMS received - ${intent.action}", Toast.LENGTH_LONG).show()

        val messages = Telephony.Sms.Intents.getMessagesFromIntent(intent)
        messages?.forEach { message ->
            (context.applicationContext as SMSApp).messageFlow.value = message
            val origin = message.displayOriginatingAddress
            val msg = message.displayMessageBody
            Log.i(TAG, "Origin: $origin; Msg: $msg")
            if (msg.contains(SEARCH)) {
                abortBroadcast()
                Log.i(TAG, "Contains $SEARCH")
                val smsManager: SmsManager =  if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                    context.getSystemService(SmsManager::class.java)
                } else {
                    @Suppress("DEPRECATION") SmsManager.getDefault()
                }
                smsManager.sendTextMessage(origin, null, ANSWER, null, null)
                Log.i(TAG, "Message \"$ANSWER\" sent")
            }
        }
    }
}