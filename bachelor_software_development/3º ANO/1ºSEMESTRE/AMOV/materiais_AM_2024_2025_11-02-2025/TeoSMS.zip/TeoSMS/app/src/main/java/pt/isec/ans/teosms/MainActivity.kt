package pt.isec.ans.teosms

import android.Manifest.permission.RECEIVE_SMS
import android.Manifest.permission.SEND_SMS
import android.content.pm.PackageManager.PERMISSION_GRANTED
import android.os.Bundle
import android.telephony.SmsMessage
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.app.ActivityCompat
import kotlinx.coroutines.flow.MutableStateFlow
import pt.isec.ans.teosms.ui.theme.TeoSMSTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            TeoSMSTheme {
                Scaffold(modifier = Modifier.fillMaxSize()) { innerPadding ->
                    SmsScreen(
                        smsFlow = (application as SMSApp).messageFlow,
                        modifier = Modifier.padding(innerPadding)
                    )
                }
            }
        }
        if (ActivityCompat.checkSelfPermission( this, RECEIVE_SMS)
            != PERMISSION_GRANTED ||
            ActivityCompat.checkSelfPermission( this, SEND_SMS)
            != PERMISSION_GRANTED ) {
            requestPermissionsResult.launch(
                arrayOf(RECEIVE_SMS, SEND_SMS)
            )
        }
    }

    private val requestPermissionsResult = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { permissions ->
        permissions.values.forEach { result -> if (!result) finish() }
    }

}

@Composable
fun SmsScreen(smsFlow: MutableStateFlow<SmsMessage?>, modifier: Modifier = Modifier) {
    val messageFlow = smsFlow.collectAsState()
    Column(
        modifier = modifier
    ) {
        Text(
            text = "Origin:",
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "${messageFlow.value?.displayOriginatingAddress}",
            modifier = Modifier.padding(bottom = 16.dp)
        )
        Spacer(Modifier.height(16.dp))
        Text(
            text = "Message:",
            fontWeight = FontWeight.Bold
        )
        Text(
            text = "${messageFlow.value?.displayMessageBody}",
            modifier = Modifier.padding(bottom = 16.dp)
        )
    }
}
