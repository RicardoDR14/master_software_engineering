package pt.isec.ans.teosms

import android.app.Application
import android.telephony.SmsMessage
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

class SMSApp : Application() {
    val messageFlow = MutableStateFlow<SmsMessage?>(null)

    override fun onCreate() {
        super.onCreate()
    }
}