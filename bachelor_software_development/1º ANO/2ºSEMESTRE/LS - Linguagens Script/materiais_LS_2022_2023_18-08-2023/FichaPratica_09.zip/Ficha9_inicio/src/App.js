import "./assets/styles/App.css";
import React from 'react';
import {
  ControlPanel,
  Footer,
  Header,
  GamePanel,
} from "./components";

function App() {
  return (
    <div id="container">
      <Header />
      <main className="main-content">
        <ControlPanel />
        <GamePanel />
      </main>
      <Footer />
    </div>
  );
}
export default App;
