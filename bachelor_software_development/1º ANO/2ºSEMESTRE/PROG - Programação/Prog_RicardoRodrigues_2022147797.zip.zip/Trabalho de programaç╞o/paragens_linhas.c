//paragens_linhas.c Ricardo Duarte Rodrigues a2022147797



#include <stdlib.h>
#include <stdio.h>
#include <string.h>
#include "paragens_linhas.h"

//Fun��es das paragens
void mostra_paragens(stop *p, int total)
{
    for(int i = 0; i<total; i++){
        printf("\nParagem %d:\nNome:%s\nID: %s\n",i+1, p[i].nome,p[i].id);
    }
}

stop preenche_paragem() {
    stop *p = malloc(sizeof(stop));
    if (p == NULL) {
        printf("\nErro na alocacao de memoria\n");
        return *p;
    }

    printf("\nNome da paragem a adicionar: ");
    scanf(" %99[^\n]", p->nome);

    // gerar um c�digo alfanum�rico aleat�rio de 4 d�gitos com letras mai�sculas e n�meros
    for (int i = 0; i < 4; i++) {
        int escolha = rand() % 2; // escolha aleatoriamente entre letras mai�sculas e n�meros
        if (escolha == 0) {
            p->id[i] = 'A' + rand() % 26; // letra mai�scula
        } else {
            p->id[i] = '0' + rand() % 10; // n�mero
        }
    }
    p->id[4] = '\0';
    return *p;
}


stop* adiciona_paragem(stop* p, int* total, pno linhas) {
    stop* aux;
    pno auxiliar = linhas;
    if ((*total) == 0) {
        p = malloc(sizeof(stop));
        if (p == NULL) {
            printf("\nErro na alocacao de memoria\n");
            return NULL;
        }
        *p= preenche_paragem();
        (*total)++;
    } else {
        aux = realloc(p, sizeof(stop) * (*total + 1));
        if (aux != NULL) {
            aux[*total] = preenche_paragem();

            for (int i = 0; i < *total; i++) {
                if (strcmp(aux[i].nome,aux[*total].nome) == 0) {
                    printf("\nInfelizmente, esta linha ja possui esta paragem\n");
                    return p;
                }
            }
            while(auxiliar!=NULL){
                for (int j = 0; j < *total; j++) {
                    if (strcmp(auxiliar->stops[j].nome,aux[*total].nome) == 0) {
                        strcpy(aux[*total].id, auxiliar->stops[j].id);
                        break;
                    }
                }
                auxiliar=auxiliar->prox;
            }
            p = aux;
            (*total)++;
        }
        else{
            printf("\nErro na realocacao de memoria\n");
            return p;
        }
    }
    return p;
}

stop* apagar_paragem(stop* p, int* total){
    stop* aux;
    char el_paragem[20];
    int i;
    printf("\nParagem que deseja eliminar:");
    scanf("%s", el_paragem);

    for(i = 0; i < *total && strcmp(p[i].nome, el_paragem) != 0; i++);

    if (i != *total){
        aux = p;
        for(int j = i; j < *total - 1; j++){
            aux[j] = aux[j+1];
        }
        (*total)--;
        aux = realloc(p, sizeof(stop) * (*total));
        if (aux == NULL){
            printf("\nErro na realoca��o de memoria\n");
            return p;
        }
        else{
            p = aux;
        }
    }
    else{
        printf("\nA paragem n�o foi encontrada\n");
    }
    return p;
}

//ver se existe a paragem em alguma linha
int encontrarParagem(pno linha, char* nomeParagem, char* linhaEncontrada){

    while (linha != NULL){
        stop* paragem = linha->stops;
        for (int i = 0; i < linha->total_paragens; i++){
            if (strcmp(paragem[i].nome, nomeParagem) == 0){
                strcpy(linhaEncontrada, linha->cor);
                return 1;
            }
        }
        linha = linha->prox;
    }
    return 0;
}
//ver se tem alguma paragem em comum em duas linhas, apenas verifica em linhas
int verificar_ParagemComum(pno linha1, pno linha2, char* paragemComum){

    stop* paragens1 = linha1->stops;
    stop* paragens2 = linha2->stops;

    for (int i = 0; i < linha1->total_paragens; i++){
        for (int j = 0; j < linha2->total_paragens; j++){
            if (strcmp(paragens1[i].nome, paragens2[j].nome) == 0){
                strcpy(paragemComum, paragens1[i].nome);
                return 1;
            }
        }
    }
    return 0;
}
//percorrer LINHAS e verificar as linhas t�m as paragens em comum chamando a fun��o a cima
int verificarParagensComuns(pno linhas, char* nomeLinha1, char* nomeLinha2, char* paragemComum){

    pno linha1 = NULL;
    pno linha2 = NULL;

    while (linhas != NULL){
        if (strcmp(linhas->cor, nomeLinha1) == 0){
            linha1 = linhas;
        }
        else if (strcmp(linhas->cor, nomeLinha2) == 0){
            linha2 = linhas;
        }
        linhas = linhas->prox;
    }

    if (linha1 != NULL && linha2 != NULL){
        if (verificar_ParagemComum(linha1, linha2, paragemComum)){
            return 1;
        }
    }
    return 0;
}

void calculo_percurso(pno linhas){
    char* origem[100];
    char* destino[100];
    char* linha_origem[100];
    char* linha_destino[100];
    char* paragem_comum[100];

    printf("\nQual a paragem de origem:");
    scanf("%s",&origem);
    printf("\nQual a paragem de destino:");
    scanf("%s",&destino);

    int origem_encontrada = encontrarParagem(linhas,origem,linha_origem);
    printf("\nLinha da origem: %s",linha_origem);
    int destino_encontrado = encontrarParagem(linhas,destino,linha_destino);
    printf("\nLinha de destino: %s",linha_destino);

    if(origem_encontrada &&destino_encontrado){
        if (strcmp(linha_origem,linha_destino)==0){
            printf("\nA paragem %s e a paragem %s encontram-se na mesma linha, ou seja, apenas preciso utilizar a linha %s.\n",origem,destino,linha_origem);
        }
        if (verificarParagensComuns(linhas,linha_origem,linha_destino,paragem_comum)){
            printf("\nA paragem %s e a paragem %s encontram-se em linhas diferentes. Tem que apanhar a linha %s e troca para a linha %s na paragem %s.\n",origem,destino,linha_origem,linha_destino,paragem_comum);
        }
    }
    else{
        printf("\nAs paragens nao foram encontradas ou nao o percurso nao � poss�vel.\n");
    }
}

stop* ordenar_paragens(stop *paragens, int posicao_desejada, int posicao_paragem){
    stop aux = paragens[posicao_paragem];
    for(int i = posicao_paragem;i>posicao_desejada;i--){
        paragens[i]=paragens[i-1];
    }
    paragens[posicao_desejada]=aux;
    return paragens;
}

pno alterar_ordem(pno linhas){
    char mudar_linha[100];
    char paragem_alterar[100];
    int i,j;
    pno aux;
    aux=linhas;
    printf("\nLinha em que deseja alterar a ordem das paragens:");
    scanf("%s",mudar_linha);
    while(aux != NULL &&strcmp(mudar_linha,aux->cor)!=0)aux = aux->prox;
    if (aux!=NULL){
        for (i =0; i<aux->total_paragens;i++){
            printf("\nNome da Paragem %d:",i+1);
            scanf("%s",paragem_alterar);
            for (j=0;j<aux->total_paragens&&strcmp(paragem_alterar,aux->stops[j].nome)!=0;j++);
            if (j<aux->total_paragens)
                aux->stops = ordenar_paragens(aux->stops, i, j);
            else{
                printf("\nNome da paragem incorreto. Por favor, recomece o processo.");
                return linhas;
            }
        }
    }
    else printf("\nA linha nao foi encontrada");
    return linhas;
}


//Fun��es das linhas
void preenche_linha(pno p)
{
    p->total_paragens = 0;
    printf("\nCor da Linha: ");
    scanf(" %99[^\n]", p->cor);
    printf("\nNecessario criar duas paragens");
    for (int i = 0; i < 2; i++) {
        p->stops = adiciona_paragem(p->stops, &(p->total_paragens),p);
        printf("Codigo da paragem: %s\n", p->stops[i].id);
    }
    p->prox = NULL;
}

pno criar_linha(pno p)
{
    pno novo, aux;
    novo = malloc(sizeof(no_linha));
    if(novo == NULL){
        printf("\nErro na alocacao de memoria\n");
        return p;
    }
    preenche_linha(novo);
    if(p == NULL)p = novo;//1� caso: se a lista estiver vazia
    else{ //caso geral
        aux = p;
        if(novo->cor == aux->cor){
            printf("\nCor ja atribuida - elemento nao adicionado a lista");
            return p;
        }
        while(aux->prox != NULL)//enquanto n�o chegar ao final da lista
        {
        aux = aux->prox;
           if(novo->cor == aux->cor){
                printf("\nCor ja atribuida - elemento nao adicionado a lista");
                return p;
           }
        }
        aux->prox = novo;
    }
    return p;
}

void mostra_linhas(pno p){
    if (p==NULL){printf("\nSem paragens at� ao momento.\n");return;}
    while( p!= NULL){
        printf("\n Linha Cor - %s\n", p->cor);
        mostra_paragens(p-> stops, p->total_paragens);
        p = p->prox;
    }
}

void liberta_linha(pno p)
{
    pno aux;
    while(p != NULL)
    {
        aux = p;
        p = p->prox;
        free(aux);
    }
}

pno inserir_paragem(pno p){
    char ad_linha[100];
    pno aux;
    aux=p;
    printf("\nLinha em que deseja adicionar a paragem:");
    scanf("%s",ad_linha);
    while(aux != NULL &&strcmp(ad_linha,aux->cor)!=0)aux = aux->prox;

    if (aux!=NULL){
        aux->stops = adiciona_paragem(aux->stops, &(aux->total_paragens),p);
        printf("Codigo da paragem: %s\n", aux->stops[aux->total_paragens].id);
    }
    else printf("\nA linha nao foi encontrada");
    return p;
}

pno eliminar_linha(pno p)
{
    char el_linha[100];
    pno atual, anterior = NULL;
    atual = p;

    printf("\nLinha que deseja eliminar:");
    scanf("%s",el_linha);

    while(atual != NULL && strcmp(atual->cor, el_linha)!=0)
    {
        anterior = atual;
        atual = atual->prox;
    }
    if(atual == NULL)return p;

    if(anterior == NULL)
        p = atual->prox;
    else
        anterior->prox = atual->prox;

    free(atual);
    return p;
}

pno eliminar_paragem(pno p){
    char el_linha[100];
    pno aux;

    aux=p;

    printf("\nLinha em que deseja eliminar a paragem:");
    scanf("%s",el_linha);

    while(aux != NULL &&strcmp(el_linha,aux->cor)!=0)aux = aux->prox;

    if (aux!=NULL){
        if(aux->total_paragens==2){
            printf("\nA linha so possui duas paragens. Nao pode ter menos de duas paragens!!\nNada foi alterado.");
            return p;
        }
        aux->stops = apagar_paragem(aux->stops, &(aux->total_paragens));
    }
    else printf("\nA linha nao foi encontrada.");
    return p;
}

//Fun��es de ficheiros
pno ler_fich_txt(char* nome_fich_txt) {
    FILE* f = fopen(nome_fich_txt, "r");
    if (f == NULL) {
        printf("O ficheiro '%s' nao foi encontrado.\n", nome_fich_txt);
        return NULL;
    }

    pno linhas = NULL;
    pno ultimo = NULL;
    char cor[100];
    stop* stops = NULL;
    int total_paragens = 0;

    while (fscanf(f, "%s", cor) == 1) {
        fscanf(f, "%d", &total_paragens);

        stops = (stop*) malloc(total_paragens * sizeof(stop));
        if (stops == NULL) {
            printf("Falha ao alocar memoria para as paragens.\n");
            liberta_linha(linhas);
            fclose(f);
            return NULL;
        }

        for (int i = 0; i < total_paragens; i++) {
            fscanf(f, "%s %s", stops[i].nome, stops[i].id);
        }

        pno nova_linha = criar_linha_fich(cor, stops, total_paragens);
        if (nova_linha == NULL) {
            liberta_linha(linhas);
            fclose(f);
            return NULL;
        }

        if (linhas == NULL) {
            linhas = nova_linha;
        } else {
            ultimo->prox = nova_linha;
        }

        ultimo = nova_linha;
    }

    fclose(f);
    return linhas;
}

void escrever_fich_txt(char* nome_fich_txt, pno p) {
    FILE* f = fopen(nome_fich_txt, "w");
    if (f == NULL) {
        printf("Nao foi possivel criar o ficheiro '%s'.\n", nome_fich_txt);
        return;
    }

    pno atual = p;
    while (atual != NULL) {
        fprintf(f, "%s\n", atual->cor);
        fprintf(f, "%d\n", atual->total_paragens);

        for (int i = 0; i < atual->total_paragens; i++) {
            fprintf(f, "%s %s\n", atual->stops[i].nome, atual->stops[i].id);
        }

        atual = atual->prox;
    }

    fclose(f);
}
pno criar_linha_fich(char cor[100], stop* stops, int total_paragens) {
    pno nova_linha = (pno) malloc(sizeof(no_linha));
    if (nova_linha == NULL) {
        printf("Falha ao alocar memoria para a nova linha.\n");
        return NULL;
    }

    strcpy(nova_linha->cor, cor);
    nova_linha->stops = stops;
    nova_linha->total_paragens = total_paragens;
    nova_linha->prox = NULL;

    return nova_linha;
}
