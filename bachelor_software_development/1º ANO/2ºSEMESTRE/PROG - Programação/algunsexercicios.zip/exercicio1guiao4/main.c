#include <stdio.h>
#include <stdlib.h>
#include "cp.h"

int main()
{
    char fich[20] = "cp_ex1.dat";
    char p[20] ="Coimbra";
    char origem[20] = "Lisboa";
    char destino[20] = "Braga";
    mostra_percurso(fich);
    /*if (verifica_paragem(fich,p)==1)
        printf("\nA paragem %s existe no percurso\n",p);
    else
        printf("\nA paragem %s nao existe no percurso\n",p);*/

    int minutos = verifica_percurso(fich, origem, destino);
    if (minutos!= -1)
        printf("\nDe %s a %s demora %d minutos", origem, destino ,minutos);
    else
        printf("\nO percurso nao existe");
    return 0;
}
