#ifndef CP_H_INCLUDED
#define CP_H_INCLUDED

typedef struct paragem{
    char nome[50];
    int minutos;
}Paragem;

void mostra_percurso(char *nomefich);
int verifica_paragem(char *nomefich,char *p);
int verifica_percurso(char *nomefic,char *origem, char *destino);

#endif // CP_H_INCLUDED
