#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "cp.h"

void mostra_percurso(char *nomefich){
    Paragem par;
    FILE *f = fopen(nomefich,"rb");

    if (!f){//f==NULL
        fprintf(stderr,"Erro a abrir o ficheiro %s\n",nomefich);
        return;
    }
    while (fread(&par,sizeof(Paragem),1,f)==1)
        printf("%-25s %d\n",par.nome,par.minutos);

    fclose(f);
}

int verifica_paragem(char *nomefich,char *p){
    Paragem par;
    FILE *f = fopen(nomefich,"rb");

    if (!f){//f==NULL
        fprintf(stderr,"Erro a abrir o ficheiro %s\n",nomefich);
        return;
    }
    while (fread(&par,sizeof(Paragem),1,f)==1){
        if (strcmp(par.nome,p)==0){
            fclose(f);
            return 1;
        }
    }
    fclose(f);
    return 0;
}

int verifica_percurso(char *nomefich, char *origem, char *destino){
    int possivel = 0;//marcador para ajudar no marcador
    Paragem par;
    FILE *f = fopen(nomefich,"rb");
    int minutos=0;

    if(!f) { //f==NULL
        fprintf(stderr, "Erro a abrir a ficheiro %s\n", nomefich);
        return;
    }
    while(fread(&par,sizeof(Paragem),1,f)==1){
        switch(possivel)
        {
            case 0:
                if(strcmp(origem,par.nome)==0)
                    possivel=1;
                break;
            case 1:
                minutos+=par.minutos;
                if(!strcmp(destino,par.nome))
                    possivel=2;
                break;
            case 2:
                fclose(f);
                return minutos;
                break;
        }
    }
    fclose(f);

    if(possivel==2)
        return minutos;
    else
        return -1;
}
