#include "ponto.h"
#include "retangulo.h"

void printRet(ret2D r){
    printf("Canto inferior esquerdo: %d,%d\n", r.cie.x, r.cie.y);
    printf("Canto inferior direito: %d,%d\n", r.cie.x+r.largura, r.cie.y);
    printf("Canto superior esquerdo: %d,%d\n", r.cie.x, r.cie.y+r.altura);
    printf("Canto superior direito: %d,%d\n", r.cie.x+r.largura, r.cie.y+r.largura);
}

ret2D initRet(){
    ret2D r;
    printf("digite as coordenadas do ponto do canto inferior esquerdo (x,y): ");
    scanf("%d,%d", &r.cie.x, &r.cie.y);
    printf("\ndigite a altura: ");
    scanf("%d", &r.altura);
    printf("\ndigite a largura: ");
    scanf("%d", &r.largura);
    return r;
}

int areaRet(ret2D r){
    return r.altura*r.largura;
}

int incluiPonto(ret2D r, ponto2D p){
    if (p.x>r.cie.x && p.x<r.cie.x+r.largura && p.y>r.cie.y && p.x<r.cie.y+r.altura)
        return 1;
    return 0;
}

void deslocaRet(ret2D* r, int dx, int dy){
    /*printf("\nRetangulo antes do deslocamento:\n");
    printf(*p);

    movePonto(&(*r).cie)*/
    printf("N�o acabei\n");
}

int menu(){
    int i;
    printf("\nMENU: \n");
    puts ("\t1 - Adiciona Retangulo");
    puts ("\t2 - Mostrar Retangulo");
    puts ("\t3 - Eliminar Retangulo Mais Pequeno");
    puts ("\t4 - Eliminar Retangulo com area inferior a um limite");
    puts ("\t5 - Ordena Retangulo pela ordem crescente de distancia");
    puts ("\t6 - Terminar");
    puts ("Escolha uma opcao: ");
    do{
        scanf("%d",&i);
    }while(i<1 || i>6);
    return i;
}

void adicionaRetangulo(ret2D r[], int *total){
    if(*total >= MAX)
    {
        printf("\n Tabela Completa\n\n");
    }
    r[*total] = initRet();
    (*total)++;
}

void mostraRetangulo(ret2D r[],int total){
    for(int i = 0; i<total; i++){
        printf("\nRetangulo %d",i+1);
        printRet(r[i]);
    }
}

void eliminarRetangulomenor(ret2D r[],int *total){
    int menor = 0;

    if (*total == 0)
    {
        printf("\nA Tabela esta vazia\n");
        return;
    }
    for (int i = 0; i<*total;i++)
    {
        if (areaRet(r[i])<areaRet(r[menor])) menor = i;
    }
    r[menor] = r[*total-1];
    (*total)--;
}

void eliminarRetangulosmenores(ret2D r[], int *total, int area){

    if (*total == 0)
    {
        printf("\nA Tabela esta vazia\n");
        return;
    }
    for (int i = 0; i< *total;i++)
    {
        if (areaRet(r[i]) < 4){
            r[i] = r[*total-1];
            (*total)--;
            i--;
        }
    }
}
