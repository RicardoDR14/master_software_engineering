#ifndef RETANGULO_H_INCLUDED
#define RETANGULO_H_INCLUDED

#include "ponto.h"
#define MAX 3
typedef struct ret ret2D;
struct ret{
    ponto2D cie;
    int altura;
    int largura;
};

void printRet(ret2D r);
ret2D initRet();
int areaRet(ret2D r);
int incluiPonto(ret2D r, ponto2D p);
void deslocaRet(ret2D* r, int dx, int dy);

int menu();
void adicionaRetangulo(ret2D r[], int *total);
void mostraRetangulo(ret2D r[],int total);
void eliminarRetangulomenor(ret2D r[],int *total);
void eliminarRetangulosmenores(ret2D r[], int *total, int area);

#endif // RETANGULO_H_INCLUDED
