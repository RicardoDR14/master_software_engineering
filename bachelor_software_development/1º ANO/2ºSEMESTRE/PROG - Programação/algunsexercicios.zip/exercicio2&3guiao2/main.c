
#include <stdio.h>
#include "retangulo.h"
#include "ponto.h"

int main(int argc, char** argv) {

    ret2D r = {4,5,{1,1}}, r1;
    ponto2D p = {2,2};
    ret2D r2[MAX];

    int i = 0, total = 0;

    do{
        i=menu();
        switch (i){
            case 1: adicionaRetangulo(r2,&total);break;
            case 2: mostraRetangulo(r2,total);break;
            case 3: eliminarRetangulomenor(r2,&total);break;
            case 4: //eliminarRetangulosmenores(r2,&total,4);break;
            case 5: //ordenaRetangulo(r2,total);break;
            case 6: break;
        }
    }while (i>0&&i<6);


/*
    ponto2D p1 = {1,3}, p2;

    initPonto(&p2);

    printPonto(p1);

    printPonto(p2);

    movePonto(&p1, 3, -2);
    printPonto(p1);

    ret2D r1= {{1,1},2,2}, r2;
    ponto2D p;

    //printRet(r1);
    initRet(&r2);
    printRet(r2);

    printf("area de r2: %d", areaRet(r2));

    printf("\ninsira um ponto (x,y): ");
    scanf("%d,%d", &p.x, &p.y);

    /*if(incluiPonto(r2,p))
        printf("\nO ponto esta dentro do retangulo\n");
    else
        printf("\nO ponto NAO esta dentro do retangulo\n");

    deslocaRet(&r2, p)
*/
    return 0;
}
