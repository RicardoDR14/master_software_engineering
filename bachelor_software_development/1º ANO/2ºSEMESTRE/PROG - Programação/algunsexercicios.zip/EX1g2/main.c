
#include <stdio.h>

#include "ponto.h"

int main(int argc, char** argv) {

    ponto2D p1 = {1,3}, p2, p3;

    initPonto(&p2);

    printPonto(p1);

    printPonto(p2);

    movePonto(&p1, 3, -2);
    printPonto(p1);

    p1.x=0; p1.y=0;
    p2.x=1; p2.y=1;
    p3.x=2; p3.y=2;
    verificareta(p1,p2,p3);

    if (verificareta(p1,p2,p3)) printf("O ponto x = %d y = %d est� sobre a reta\n", p3.x, p3.y);
    else printf("O ponto x = %d y = %d NAO est� sobre a reta\n", p3.x, p3.y);

    return 0;
}

