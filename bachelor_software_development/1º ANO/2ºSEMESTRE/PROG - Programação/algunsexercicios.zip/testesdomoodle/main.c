#include <stdio.h>
#include <stdlib.h>
void unicos(int v[], int tam){
    int cont,i,j;
    for(i=0;i<tam;i++){
        for(j=1;j<tam;j++){
            if (v[i]!=v[j])
            {
                cont=0;
            }else{
            cont=1;
            }
        }
    if(cont==0) printf("%d\t",v[i]);
    }
}
int main()
{
    int tab[10] = {2, 30, 4, 7, 10, 3, 12, 15, 2, 10};
    unicos(tab, 10);

}

