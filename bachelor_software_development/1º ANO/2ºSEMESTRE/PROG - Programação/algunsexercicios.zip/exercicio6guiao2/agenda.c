#include "agenda.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

char menu()
{
    char n;
    do
    {
        printf("\nMENU\n");
        printf("\nIntroduza o numero da opcao pretendida: ");
        printf("\n\t1 - Adiciona Contacto");
        printf("\n\t2 - Elimina Contacto");
        printf("\n\t3 - Lista todos Contactos");
        printf("\n\t4 - Procura Contacto");
        printf("\n\t5 - Atualiza Contacto");
        printf("\n\t6 - Ordena Contactos");
        printf("\n\t7 - Sair");
        printf("\nOPCAO: ");
        fflush(stdin);
        n=getchar();
    }while (n<'1' || n>'7');
    return n;
}

contactos obtem_info()
{
   contactos t;
    printf("\nNome: ");
    scanf(" %99[^\n]", t.nome);
    printf("N. de telemovel: ");
    scanf(" %9s", t.ntelemovel);
    return t;
}

contactos* adiciona_contacto(contactos *tab, int *total){
    contactos *aux;
    int existe_contacto=0,i;
    if((*total)==0)
    {
        tab = malloc(sizeof(contactos));
        if (tab == NULL)
        {
            printf("Erro na aloca��o de memoria");
            return NULL;
        }
        tab[*total] = obtem_info();
        (*total)++;
    }
    else{
        aux = realloc(tab, sizeof(contactos) * (*total+1));
        if(aux!=NULL){
            tab = aux;
            do{
                existe_contacto=0;
                tab[*total] = obtem_info();
                for(i=0; i<*total && strcmp(tab[*total].nome, tab[i].nome)!=0;i++);
                if(i<*total){
                    printf("Contacto ja existe\n");
                    existe_contacto=1;
                }
            }while(existe_contacto);
            (*total)++;
        }
    }
    return tab;
}

void listagem_contactos(contactos *tab,int total){
    for(int i = 0; i<total; i++){
        printf("\nContacto %d:\nNome:%s\nN.Telemovel: %s\n",i+1, tab[i].nome,tab[i].ntelemovel);
    }
}

void pesquisa_contacto(contactos *tab, int total){
    char nome[100];
    printf("\nNome a pesquisar: ");
    scanf("%99[^\n]", &nome);
    for(int i = 0; i<total; i++){
        if(strcmp(nome, tab[i].nome)==0){
            printf("N. Telemovel: %s\n", tab[i].ntelemovel);
            return;
        }
    }
    printf("Contacto nao existe\n");
}

contactos* elimina_contacto(contactos *tab, int *total, char st[100]){
    int i;
    contactos *aux, t;

        for (i = 0; i<*total && strcmp(st, tab[i].nome)!=0; i++);

        if (i==*total){
            printf("\nO Contacto nao existe\n");
            return tab;
        }
        else if (i==1){
            free(tab);
            *total=0;
            return NULL;
        }

        t = tab[i];//guardo o elemento a eliminar
        tab[i] = tab[*total-1];//copio o ultimo elemento da lista
        aux = realloc(tab, sizeof(contactos) * (*total-1));//realoca��o a tabela auxiliar
        if (aux != NULL){
            tab = aux;    //se correr bem
            (*total)--;
        }
        else
            tab[i] = t;   //se correr mal, volta ao original
        return tab;

}
