#ifndef AGENDA_H_INCLUDED
#define AGENDA_H_INCLUDED

typedef struct lista_contactos contactos;
struct lista_contactos
{
    char nome[100];
    char ntelemovel[10];
};
char menu();
contactos obtem_info();
contactos* adiciona_contacto(contactos *tab,int *total);
//contactos* elimina_contacto(contactos tab,int *total, char st[]);
void listagem_contactos(contactos *tab, int total);
void pesquisa_contacto(contactos *tab, int total);
contactos* elimina_contacto(contactos *tab, int *total, char st[100]);

#endif // AGENDA_H_INCLUDED
