//main.c Ricardo Duarte Rodrigues a2022147797


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "paragens_linhas.h"


int main()
{
    char* nome_fich_txt = "linhas.txt";
    pno todas_linhas = ler_fich_txt(nome_fich_txt);

    int op;
    do{
        printf("\t\t\t\t\t* * * * * * * * * * * * * * * * * * * * * * * * *\n");
		printf("\t\t\t\t\t*  1 - Mostrar linhas e as suas paragens        *\n");
		printf("\t\t\t\t\t*  2 - Inserir nova linha                       *\n");
		printf("\t\t\t\t\t*  3 - Adicionar uma nova paragem a uma linha   *\n");
		printf("\t\t\t\t\t*  4 - Eliminar uma linha                       *\n");
		printf("\t\t\t\t\t*  5 - Elimina uma paragem de uma linha         *\n");
		printf("\t\t\t\t\t*  6 - Alterar ordem das paragens de uma linha  *\n");
		printf("\t\t\t\t\t*  7 - Calculo de percurso                      *\n");
		printf("\t\t\t\t\t*  8 - Grava linhas em ficheiro txt             *\n");
		printf("\t\t\t\t\t*  9 - Sair                                     *\n");
        printf("\t\t\t\t\t* * * * * * * * * * * * * * * * * * * * * * * * *\n");
		printf("\tOpcao: ");
		scanf("%d", &op);
    switch(op){
        case 1: mostra_linhas(todas_linhas);
                break;
        case 2: todas_linhas = criar_linha(todas_linhas);
                break;
        case 3: todas_linhas = inserir_paragem(todas_linhas);
                break;
        case 4: todas_linhas = eliminar_linha(todas_linhas);
                break;
        case 5: todas_linhas = eliminar_paragem(todas_linhas);
                break;
        case 6: todas_linhas = alterar_ordem(todas_linhas);
                break;
        case 7: calculo_percurso(todas_linhas);
                break;
        case 8: escrever_fich_txt(nome_fich_txt, todas_linhas);
                break;
        }
    }while(op>=1 && op<9);

    liberta_linha(todas_linhas);
    return 0;
}
