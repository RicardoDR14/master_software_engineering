//paragens_linhas.h Ricardo Duarte Rodrigues a2022147797


#ifndef PARAGENS_LINHAS_H_INCLUDED
#define PARAGENS_LINHAS_H_INCLUDED
////////////////////////////////////
typedef struct paragem stop;
struct paragem
{
    char nome[100];
    char id[5];
};

////////////////////////////////////
typedef struct linha no_linha, *pno;
struct linha
{
    char cor[100];
    stop* stops;
    int total_paragens;
    pno prox;
};

//Fun��es das paragens
void mostra_paragens(stop *paragens, int total);
stop preenche_paragem();
stop* adiciona_paragem(stop *p, int *total,pno linhas);
stop* apagar_paragem(stop* p, int* total);
int encontrarParagem(pno linha, char* nomeParagem, char* linhaEncontrada);
int verificar_ParagemComum(pno linha1, pno linha2, char* paragemComum);
int verificarParagensComuns(pno linhas, char* nomeLinha1, char* nomeLinha2, char* paragemComum);
stop* ordenar_paragens(stop *paragens, int posicao_desejada, int posicao_paragem);
pno alterar_ordem(pno linhas);

//Fun��es das linhas
void preenche_linha(pno p);
pno criar_linha(pno p);
void mostra_linhas(pno p);
void liberta_linha(pno p);
pno inserir_paragem(pno p);
pno eliminar_linha(pno p);
void calculo_percurso(pno linhas);

///////////////////////////////////
pno ler_fich_txt(char* nome_fich_txt);
void escrever_fich_txt(char* nome_fich_txt, pno p);

pno criar_linha_fich(char cor[100], stop* stops, int total_paragens);

#endif // PARAGENS_LINHAS_H_INCLUDED
