#include <stdio.h>
#include "ponto.h"
#include "retangulo.h"

int main()
{
    printf("Hello world!\n");
    return 0;
}
