#ifndef PONTO_H_INCLUDED
#define PONTO_H_INCLUDED

typedef struct point ponto;
 struct point{
    int x, y;
};
#endif // PONTO_H_INCLUDED
