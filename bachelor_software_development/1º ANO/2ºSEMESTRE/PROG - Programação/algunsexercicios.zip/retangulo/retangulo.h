#ifndef RETANGULO_H
#define RETANGULO_H

#include <stdbool.h>
#include "ponto.h"

typedef struct rectangle retangulo;

struct rectangle{
    ponto c;
    int alt, larg;
    };


#endif // RETANGULO_H
