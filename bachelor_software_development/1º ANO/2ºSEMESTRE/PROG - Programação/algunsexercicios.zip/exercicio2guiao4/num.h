#ifndef NUM_H_INCLUDED
#define NUM_H_INCLUDED

typedef struct med_sum{
    float media;
    int soma;
}MedSum;

void mostra_numero(char *nomefich);
MedSum calcula_soma_media(char *nomefich);
int *criaVetor(char *nomeFich, int *tam);


#endif // NUM_H_INCLUDED
