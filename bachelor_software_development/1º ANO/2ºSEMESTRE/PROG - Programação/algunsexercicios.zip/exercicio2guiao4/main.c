#include <stdio.h>
#include <stdlib.h>
#include "num.h"

int main()
{
    MedSum t;
    int* c =NULL;
    int tam=0;
    char nomeFich[20] = "valoresEx2.bin";
    mostra_numero(nomeFich);

    t=calcula_soma_media(nomeFich);
    printf("\nSoma = %d e media = .2%f", t.soma, t.media);

    c=criaVetor(nomeFich,&tam);
    printf("\nO vetor criado tem %d valores", tam);
    for (int i=0; i<tam;i++)
        printf("\n%3d",c[i]);

    return 0;
}
