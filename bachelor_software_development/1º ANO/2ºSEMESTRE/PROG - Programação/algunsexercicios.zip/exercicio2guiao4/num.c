#include <stdio.h>
#include <stdlib.h>
#include "num.h"

void mostra_numero(char *nomefich){
    int n;
    FILE *f = fopen(nomefich,"rb");

    if (!f){//f==NULL
        fprintf(stderr,"Erro a abrir o ficheiro %s\n",nomefich);
        return;
    }
    while (fread(&n,sizeof(int),1,f)==1)
        printf("%3d\n",n);

    fclose(f);
}

MedSum calcula_soma_media(char *nomefich){
    MedSum t;
    int n, contador=0;
    t.soma = 0;
    FILE *f = fopen(nomefich,"rb");

    if(!f){ //f==NULL
        fprintf(stderr, "Erro a abrir a ficheiro %s\n", nomefich);
        return;
    }
    while(fread(&n,sizeof(int),1,f)==1)
    {
        t.soma+=n;
        contador++;
    }
    t.media=t.soma/(float)contador;
    fclose(f);
    return t;
}

int* criaVetor(char *nomeFich, int *tam)
{
    FILE *f;
    int *b = NULL,num, *aux;
    (*tam)=0;
    f = fopen(nomeFich,"rb");
    if(f == NULL)
    {
        printf("Erro a abrir o ficheiro\n");
        return b;
    }
    while (fread(&num,sizeof(int),1,f)==1)
    {
        if(num%2==0)
        {
            aux = realloc(b,sizeof(int) * (*tam+1));
            //If pointer passed to realloc is null, then it will behave exactly like malloc
            if(aux == NULL)
            {       // realoca��o falhou
                printf("Falhou realocacao. Mantem tamanho\n");
                (*tam)=0;
                return NULL;
            }
            else
            {
                b = aux;
                b[(*tam)] = num;
                (*tam)++;
            }

        }
    }
    fclose(f);
    return b;
}
