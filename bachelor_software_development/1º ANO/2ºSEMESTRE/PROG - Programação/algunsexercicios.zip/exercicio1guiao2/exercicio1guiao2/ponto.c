
#include <stdio.h>
#include "ponto.h"

// alinea b)
void printPonto(ponto2D a){
    printf("Ponto: (%d,%d)\n", a.x, a.y);
}

// alinea c)
void initPonto(ponto2D* p){
    printf("digite as coordenadas (x y): ");
    scanf("%d %d", &p->x, &p->y);
}

// alinea d)
void movePonto(ponto2D* p, int dx, int dy){
    p->x += dx;
    p->y += dy;
}

//alínea e)
int colineares(ponto2D a, ponto2D b, ponto2D c){
    if (!(a.x*b.y +a.y*c.x + b.x*c.y - b.y*c.x - a.y*b.x - c.y*a.x))
        return 1;
    return 0;
}
