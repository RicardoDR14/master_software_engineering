#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "banco.h"

void mostra_ficheiro(char* nome){
    FILE *in;
    Cliente tmp;

    if((in = fopen(nome,"rb"))!=NULL){
        while (fread(&tmp,sizeof(Cliente),1,in)==1)
            printf("Nome: %s\tConta: %d\tMontante: %d\n",tmp.nome,tmp.conta,tmp.montante);
        fclose(in);
    }else printf("Erro ao abrir o ficheiro %s para escrita\n", nome);
}

void conta_bytes_clientes(char *nome){
    int n;
    FILE *in;

     if((in = fopen(nome,"rb"))==NULL){
        printf("ficheiro nao existe");
        exit(1);
     }
     fseek(in,0,SEEK_END);
     n = ftell(in);
     printf("Bytes: %d\tMontante: %d\n", n, n/sizeof(Cliente));
     fclose(in);
}
void elimina_cliente(char* nomeF, char* nomeC){
    FILE*in, *out;
    Cliente tmp;

    if((in = fopen(nomeF, "rb")) != NULL)
    {
        if((out =fopen("temporario","wb")) != NULL)
        {
            while(fread(&tmp, sizeof(Cliente),1,in))
            {
                if(strcmp(tmp.nome, nomeC) != 0)
                    fwrite(&tmp, sizeof(Cliente), 1, out);
            }

            fclose(in);
            fclose(out);
            remove(nomeF);
            rename("temporario", nomeF);
        }
        else
        {
            fclose(in);
            printf("Erro ao abrir o ficheiro temporario para a escrita\n");
        }
    }
    else printf("Erro ao abrir o ficheiro %s para a leitura\n", nomeF);
}
