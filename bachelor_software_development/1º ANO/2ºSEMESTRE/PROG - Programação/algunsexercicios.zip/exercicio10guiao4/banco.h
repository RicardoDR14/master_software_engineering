#ifndef BANCO_H_INCLUDED
#define BANCO_H_INCLUDED

#define TAM 200
typedef struct cliente Cliente;
struct cliente{
    char nome[TAM];
    char morada[TAM];
    int conta;
    int montante;
};

void mostra_ficheiro(char *nome);
void conta_bytes_clientes(char *nome);
void elimina_cliente(char* nomeF, char* nomeC);
#endif // BANCO_H_INCLUDED
