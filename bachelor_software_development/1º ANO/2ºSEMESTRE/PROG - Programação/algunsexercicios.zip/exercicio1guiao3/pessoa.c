#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "pessoa.h"

void preenche(pno p)
{
    printf("Nome: ");
    scanf(" %99[^\n]", p->nome);
    printf("Id: ");
    scanf("%d", &p->id);
    printf("Peso: ");
    scanf("%f", &p->peso);
    printf("Altura: ");
    scanf("%f", &p->altura);
    p->prox = NULL;
}


int lista_vazia(pno p)
{
    if(p == NULL)
        return 1;
    else
        return 0;
}


pno insere_final(pno p)
{
    pno novo, aux;
    novo = malloc(sizeof(no));
    if(novo == NULL)
    {   printf("Erro na alocacao de memoria\n");
        return p;}
    preenche(novo);
    if(p == NULL)//1� caso: se a lista estiver vazia
        p = novo;
    else  { //caso geral
         aux = p;
        if(novo->id == aux->id)
        {   printf("\n Id ja atribuido - elemento nao adicionado a lista");
            return p;}
        while(aux->prox != NULL)//enquanto n�o chegar ao final da lista
        {
            aux = aux->prox;
           //printf("%d\t%d\n", novo->id, aux->id);
           if(novo->id == aux->id)
            {   printf("\n Id ja atribuido - elemento nao adicionado a lista");
            return p;}
        }
        aux->prox = novo;
    }
    return p;
}

void liberta_lista(pno p)
{
    pno aux;
    while(p != NULL)
    {
        aux = p;
        p = p->prox;
        free(aux);
    }
}

void mostra_info(pno p){
    while(p != NULL){
        printf("\nNome: %s\n",p->nome);
        printf("ID: %d\n",p->id);
        printf("Altura: %.2f\n",p->altura);
        printf("Peso: %.2f\n",p->peso);
        printf("IMC: %f\n",p->peso/pow(p->altura,2));
        p = p->prox;
    }
}

void atualiza_peso(pno p, int id, int novo_peso){
    while(p != NULL){
        if (p->id == id){
            p->peso = novo_peso;
            return;
        }
        p=p->prox;
    }
    printf("\nPessoa n�o encontrada!!");
}

pno elimina(pno p, int id){
    pno atual, anterior = NULL;
    atual = p;
    while(atual != NULL && atual->id != id){
        anterior = atual;
        atual = atual->prox;
    }
    if(atual == NULL)
        return p;
    if(anterior == NULL)
        p = atual->prox;
    else
        anterior->prox = atual->prox;
    free(atual);
    return p;
}

pno elimina_lista_imc_superior(pno p, float imc){
    pno atual, anterior = NULL;
    atual = p;
    float imc_atual;
    while(atual != NULL){
        imc_atual = atual->peso/pow(atual->altura,2);
        if (imc_atual > imc){
            if(atual == NULL)
                return p;
            if(anterior == NULL)
                p = atual->prox;
            else
                anterior->prox = atual->prox;
        }
        anterior = atual;
        atual = atual->prox;
    }
    free(atual);
    return p;
}
