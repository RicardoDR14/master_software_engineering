/*
 * File:   TstG3E09.c
 * Author: ans
 *
 * Created on April 1, 2017, 6:07 PM
 */

#include <stdio.h>
#include <stdlib.h>
typedef struct aluno no, *pno;
struct aluno{
    int id; // Id num�rico do aluno
    int nota; // Nota final obtida em percentagem
    pno prox;
};

void processa(char *nomefich,char *novofich)
{
    int pesos[6],nralunos,nrprovas,i,nota,nraluno;
    float media;
    FILE *f,*g;

    f = fopen(nomefich,"rt");
    if (!f) {
        fprintf(stderr,"Erro a abrir o ficheiro: %s\n",nomefich);
        return;
    }

    g = fopen(novofich,"wt");
    if (!g) {
        fclose(f);
        fprintf(stderr,"Erro a criar o ficheiro: %s\n",novofich);
        return;
    }

    if (fscanf(f," Numero de alunos: %d",&nralunos) != 1 ||
        fscanf(f," Numero de provas: %d",&nrprovas) != 1 ||
        fscanf(f," Peso das provas: %d",&pesos[0]) != 1) {
        fprintf(stderr,"Erro de formato do ficheiro\n");
        fclose(f);fclose(g);
        return;
    }
    fprintf(g,"Numero de alunos: %d\n",nralunos);
    //fprintf(g,"Numero de provas: %d\n",nrprovas);
    //fprintf(g,"Peso das provas: %d",pesos[0]);
    for(i=1;i<nrprovas;i++) {
        if (fscanf(f," %d",&pesos[i]) != 1) {
            fprintf(stderr,"Erro de formato do ficheiro\n");
            fclose(f);fclose(g);
            return;
        }
        //fprintf(g," %d",pesos[i]);
    }

//    fprintf(g,"\n\n");
    fprintf(g,"\n");

    while (nralunos--) {
        if (fscanf(f," Aluno %d: %d",&nraluno,&nota) != 2) {
            fprintf(stderr,"Erro de formato do ficheiro\n");
            fclose(f);fclose(g);
            return;
        }
        media = nota * pesos[0] / 100.0;
        for(i=1;i<nrprovas;i++) {
            if (fscanf(f," %d",&nota) != 1) {
                fprintf(stderr,"Erro de formato do ficheiro\n");
                fclose(f);fclose(g);
                return;
            }
            media += nota * pesos[i] / 100.0;
        }

        fprintf(g,"Aluno %d: %.0f%%\n",nraluno,media);
    }

    fclose(f);
    fclose(g);
}

void processa1(char *nomefich,char *novofich)
{
    int pesos[6],nralunos,nrprovas,i,nota,nraluno;
    float media,total;
    FILE *f,*g;

    f = fopen(nomefich,"rt");
    if (!f) {
        fprintf(stderr,"Erro a abrir o ficheiro: %s\n",nomefich);
        return;
    }

    g = fopen(novofich,"wt");
    if (!g) {
        fclose(f);
        fprintf(stderr,"Erro a criar o ficheiro: %s\n",novofich);
        return;
    }

    if (fscanf(f," Numero de alunos: %d",&nralunos) != 1 ||
        fscanf(f," Numero de provas: %d",&nrprovas) != 1 ||
        fscanf(f," Peso das provas: %d",&pesos[0]) != 1) {
        fprintf(stderr,"Erro de formato do ficheiro\n");
        fclose(f);fclose(g);
        return;
    }
    fprintf(g,"Numero de alunos: %d\n",nralunos);
    //fprintf(g,"Numero de provas: %d\n",nrprovas);
    //fprintf(g,"Peso das provas: %d",pesos[0]);
    total = pesos[0];
    for(i=1;i<nrprovas;i++) {
        if (fscanf(f," %d",&pesos[i]) != 1) {
            fprintf(stderr,"Erro de formato do ficheiro\n");
            fclose(f);fclose(g);
            return;
        }
        total += pesos[i];
        //fprintf(g," %d",pesos[i]);
    }

//    fprintf(g,"\n\n");
    fprintf(g,"\n");

    while (nralunos--) {
        if (fscanf(f," Aluno %d: %d",&nraluno,&nota) != 2) {
            fprintf(stderr,"Erro de formato do ficheiro\n");
            fclose(f);fclose(g);
            return;
        }
        media = nota * pesos[0] / total;
        for(i=1;i<nrprovas;i++) {
            if (fscanf(f," %d",&nota) != 1) {
                fprintf(stderr,"Erro de formato do ficheiro\n");
                fclose(f);fclose(g);
                return;
            }
            media += nota * pesos[i] / total;
        }

        fprintf(g,"Aluno %d: %d\n",nraluno,(int)media);
    }

    fclose(f);
    fclose(g);
}

pno cria_lista(pno p,char *nomefich)
{
    pno novo, aux;
    int nralunos,nota,nraluno;
    FILE *g;

    g = fopen(nomefich,"rt");
    if (!g)
    {
        fprintf(stderr,"Erro a abrir o ficheiro: %s\n",nomefich);
        return;
    }
    if (fscanf(g," Numero de alunos: %d\n",&nralunos) != 1 )
    {
        fprintf(stderr,"Erro de formato do ficheiro");
        fclose(g);
        return;
    }
    printf("\nNumero alunos: %d\n",nralunos);

    while (nralunos--)
    {
        if (fscanf(g," Aluno %d: %d",&nraluno,&nota)!=2){
            fprintf(stderr,"Erro de formato do ficheiro\n");
            fclose(g);
            return p;
        }

        novo = malloc(sizeof(no));
        if(novo == NULL)
        {
            printf("Erro na alocacao de memoria\n");
            return p;
        }
        novo->id=nraluno;
        novo->nota=nota;
        novo->prox=NULL;
        if(p == NULL)//1� caso: se a lista estiver vazia
            p = novo;
        else //caso geral
        {
            aux = p;

            while(aux->prox != NULL) //enquanto n�o chegar ao final da lista
                aux = aux->prox;
            aux->prox = novo;
        }

    }
    fclose(g);
    return p;
}

void mostra_lista(pno p)
{
    while(p != NULL)
    {
        printf("\nid: %d\tnota: %d\n",p->id, p->nota);
        p = p->prox;
    }
}


int main(int argc, char** argv) {

pno lista=NULL;
//    processa("notas_ex9.txt","res_ex9.txt");
    processa1("notas_ex9.txt","res_ex9.txt");
    lista=cria_lista(lista,"res_ex9.txt");

    mostra_lista(lista);

    return (EXIT_SUCCESS);
}

