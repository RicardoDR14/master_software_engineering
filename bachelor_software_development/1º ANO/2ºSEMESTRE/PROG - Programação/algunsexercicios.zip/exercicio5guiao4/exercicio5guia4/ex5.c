#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 100

void mostra_ficheiro(char *nome) {
    char linha[TAM];
    FILE *f=fopen(nome,"rt");
    if (!f){
        fprintf(stderr,"Erro a abrir o ficheiro: %s\n", nome);
        return;
    }

    while (fgets(linha,TAM ,f)){
        fputs(linha,stdout);
    }
    fclose(f);
}

void duplicaConteudo(char *origem,char *destino){
    char c;
    FILE *f = fopen(origem,"rt");
    if (!f){
        printf("n�o foi possivel abrir o ficheiro origem");
        return;
    }
    FILE *g=open(destino,"wt");
    if (!g){
        printf("n�o foi possivel abrir o ficheiro origem");
        return;
    }
    while((c=fgetc(f))!=EOF)
        fputc(c,g);

    fclose(f);
    fclose(g);
}



int main()
{
    printf("conteudo\n");
    duplicaConteudo("ex4.txt","ex5.txt");
    printf("conteudo duplicado\n");
    mostra_ficheiro("ex5.txt");
    return 0;
}
