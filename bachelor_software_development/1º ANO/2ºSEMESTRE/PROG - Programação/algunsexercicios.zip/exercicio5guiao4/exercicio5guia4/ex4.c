#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define TAM 100

void mostra_fich(char *nome) {
    char linha[TAM];
    FILE *f=fopen(nome,"rt");
    if (!f){
        fprintf(stderr,"Erro a abrir o ficheiro: %s\n", nome);
        return;
    }

    while (fgets(linha,TAM ,f)){
        fputs(linha,stdout);
    }
    fclose(f);
}

int main()
{
    printf("teste\n");
    mostra_fich("ficheiro.txt");
    return 0;
}
