var botao = document.getElementById(botao);

var onclick: ((this: botao, ev:function escrever(event))) =>
    console.log("qualquer coisa");